"""15 editable arrangements inspired by the user's supplied wedding references."""
def reference_templates():
    out=[]
    def add(title,slots,*,mono=(),effects=None,mats=(),panels=(),wide=False,frame=False):
        out.append(dict(name=f'{61+len(out):02d} · Mẫu tham khảo · {title}',slots=slots,background='blur',mono=list(mono),effects=dict(dict(blur=0,wash=0,brightness=100),**(effects or {})),mats=list(mats),background_panels=list(panels),native_orientation='landscape' if wide else 'portrait',outer_frame=frame))
    add('Forever · cụm ba ảnh góc trái',[[.055,.40,.31,.34],[.055,.75,.145,.18],[.215,.75,.16,.18]],mats=[([.03,.38,.36,.60],'#ffffff',100)])
    add('Lễ ăn hỏi · chân dung trung tâm',[[.15,.067,.70,.755]],effects=dict(blur=28,wash=8,corner=2,border=.5,shadow=35))
    add('Open Door · đôi ảnh và ảnh nhóm',[[.21,.144,.29,.35],[.50,.144,.29,.35],[.21,.494,.58,.31]],mono=[1],frame=True,effects=dict(vignette=22))
    add('Romantic Diary · bốn ảnh lệch',[[.105,.294,.24,.235],[.36,.34,.18,.18],[.13,.54,.195,.20],[.345,.53,.235,.235]],effects=dict(tone='mono',tone_strength=100,wash=12),mats=[([.095,.28,.50,.515],'#ffffff',30)])
    add('Love Season · bốn ảnh kể chuyện',[[.14,.078,.185,.185],[.313,.27,.375,.375],[.313,.645,.375,.165],[.15,.72,.16,.16]],effects=dict(tone='mono',tone_strength=100,brightness=75,vignette=30))
    add('Forever · lưới bốn trên nền lớn',[[.073,.32,.175,.175],[.264,.32,.175,.175],[.073,.51,.175,.175],[.264,.51,.175,.175]],mono=[1],mats=[([.052,.295,.41,.41],'#ffffff',35)])
    add('Wedding Day · ba ảnh cân đối',[[.02,.356,.29,.29],[.33,.33,.34,.34],[.69,.356,.29,.29]],mats=[([0,.294,1,.412],'#ffffff',38)],effects=dict(wash=5))
    add('Sunflower · bốn khung xếp lớp',[[.28,.075,.505,.538],[.035,.268,.285,.305],[.115,.59,.245,.26],[.40,.632,.57,.27]],effects=dict(blur=12,shadow=28))
    add('The Future · ảnh đơn bên phải',[[.558,.08,.37,.81]],wide=True,effects=dict(tone='mono',tone_strength=100,grain=12,brightness=90))
    add('Wherever · bốn khung bất đối xứng',[[.32,.045,.36,.435],[.11,.555,.37,.19],[.525,.50,.25,.30],[.35,.76,.16,.19]],effects=dict(tone='warm',tone_strength=65,blur=12,wash=14))
    add('First Sight · chân dung lệch dưới',[[.23,.39,.54,.54]],effects=dict(blur=8,wash=10),mats=[([.208,.95,.585,.02],'#ffffff',55)])
    add('Every Day · nền đôi và ảnh giữa',[[.317,.125,.367,.735]],wide=True,frame=True,panels=[([0,0,.46,1],0,'mono'),([.54,0,.46,1],-1,'natural')],effects=dict(blur=6),mats=[([.456,0,.086,1],'#786361',100)])
    add('Soft Portrait · một khung phía dưới',[[.317,.50,.426,.426]],effects=dict(wash=30,blur=5,tone='warm',tone_strength=25),mats=[([0,.80,1,.20],'#ffffff',15)])
    add('After You · ba ảnh nền film',[[.292,.075,.358,.358],[0,.416,.25,.25],[.38,.455,.35,.35]],effects=dict(tone='mono',tone_strength=100,blur=18,grain=20,scratches=20,vignette=10))
    add('Magazine · dải ba ảnh bên trái',[[.035,.146,.497,.225],[.17,.41,.225,.225],[.035,.68,.497,.22]],effects=dict(wash=12),mats=[([.019,.095,.528,.846],'#ffffff',35)])
    return out
