"""Editable multi-layer typography with offline fonts and embedded custom fonts."""
import base64,io,unicodedata
from functools import lru_cache
from pathlib import Path
from PIL import Image,ImageFont,ImageDraw,ImageColor
from typography import get_font

@lru_cache(maxsize=32)
def embedded_font(data,size):return ImageFont.truetype(io.BytesIO(base64.b64decode(data)),size)

def import_font(path):
    path=Path(path)
    if path.stat().st_size>20*1024*1024:raise ValueError('Chọn font TTF/OTF dưới 20 MB.')
    data=path.read_bytes();ImageFont.truetype(io.BytesIO(data),24)
    return base64.b64encode(data).decode('ascii')

def layer_font(layer,size):
    size=max(1,int(size))
    font=(embedded_font(layer['font_data'],size) if layer.get('font_data') else get_font(layer.get('font','Montserrat'),size)).font_variant(size=size)
    try:
        axes=font.get_variation_axes();values=[a['default'] for a in axes]
        for i,a in enumerate(axes):
            if a['name'].decode().lower()=='weight':values[i]=max(a['minimum'],min(a['maximum'],layer.get('weight',400)))
        font.set_variation_by_axes(values)
    except (OSError,ValueError,AttributeError):pass
    return font

def measured(draw,text,font,tracking):
    return draw.textlength(text,font=font)+max(0,len(text)-1)*tracking

def wrap_lines(text,font,width,draw,tracking):
    result=[]
    for paragraph in unicodedata.normalize('NFC',text).split('\n'):
        if not paragraph:result.append('');continue
        line=''
        for word in paragraph.split():
            candidate=(line+' '+word).strip()
            if line and measured(draw,candidate,font,tracking)>width:result.append(line);line=''
            for char in ((' ' if line else '')+word):
                if line and measured(draw,line+char,font,tracking)>width:result.append(line.rstrip());line=''
                line+=char
        if line:result.append(line.rstrip())
    return result

def text_plate(layer,canvas_size):
    w,h=canvas_size;short=min(w,h)
    # Canvas-relative sizes keep text geometry consistent in preview and export.
    size=max(1,round(short*max(2,min(300,float(layer.get('size',30))))/1000));font=layer_font(layer,size)
    spacing=size*float(layer.get('tracking',0))/100
    maxwidth=max(1,round(w*max(1,min(100,float(layer.get('width',80))))/100))
    scratch=ImageDraw.Draw(Image.new('L',(1,1)));lines=wrap_lines(str(layer.get('text','')),font,maxwidth,scratch,spacing)
    boxes=[scratch.textbbox((0,0),line or 'Ag',font=font) for line in lines]
    # Respect accents, descenders and script flourishes on every line.
    pad=max(2,round(size*.3));lineheight=max(size*float(layer.get('leading',115))/100,max((b[3]-b[1] for b in boxes),default=size))
    widths=[measured(scratch,line,font,spacing) for line in lines]
    platewidth=max(1,round(max(widths,default=0)+pad*2));plateheight=max(1,round(lineheight*max(1,len(lines))+pad*2))
    plate=Image.new('RGBA',(platewidth,plateheight));d=ImageDraw.Draw(plate)
    rgb=ImageColor.getrgb(layer.get('color','#ffffff'));fill=tuple(rgb[:3])+(round(max(0,min(100,float(layer.get('opacity',100))))*2.55),)
    for i,(line,bbox,tw) in enumerate(zip(lines,boxes,widths)):
        align=layer.get('align','center');x=pad if align=='left' else platewidth-pad-tw if align=='right' else (platewidth-tw)/2
        y=pad+i*lineheight-bbox[1]
        if abs(spacing)<.001:d.text((x,y),line,font=font,fill=fill)
        else:
            for j,char in enumerate(line):
                # Prefix widths retain the font's kerning with custom tracking.
                offset=d.textlength(line[:j],font=font)+j*spacing
                d.text((x+offset,y),char,font=font,fill=fill)
    angle=float(layer.get('angle',0))
    return plate.rotate(angle,resample=Image.Resampling.BICUBIC,expand=True) if angle else plate

def apply_text_layers(image,config):
    if not config.get('text_enabled',False):return image
    out=image.convert('RGBA');w,h=out.size
    for layer in config.get('text_layers',[]):
        if not layer.get('visible',True) or not str(layer.get('text','')).strip():continue
        plate=text_plate(layer,(w,h));x=round(w*float(layer.get('x',50))/100-plate.width/2);y=round(h*float(layer.get('y',50))/100-plate.height/2)
        out.alpha_composite(plate,(x,y))
    return out.convert('RGB')
