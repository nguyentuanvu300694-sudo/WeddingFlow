"""Read-only Drive import: metadata + thumbnails; originals only on export.
No gdown, no original-file fallback during import. OAuth tokens stay in Keychain.
"""
from __future__ import annotations
import hashlib,io,json,os,re,sys,time
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
from core import Photo,inspect_photo,load_image

SCOPES=['https://www.googleapis.com/auth/drive.readonly']
FOLDER='application/vnd.google-apps.folder'
FIELDS='id,name,mimeType,modifiedTime,version,md5Checksum,sha256Checksum,size,thumbnailLink,resourceKey,capabilities(canDownload),imageMediaMetadata(width,height,rotation)'
SERVICE='WeddingFlow.GoogleDrive'
class DriveError(Exception):pass

def app_dir():
    if sys.platform=='win32':base=Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'AppData'/'Local')))
    elif sys.platform=='darwin':base=Path.home()/'Library'/'Application Support'
    else:base=Path.home()/'.local'/'share'
    p=base/'WeddingFlow';p.mkdir(parents=True,exist_ok=True);p.chmod(0o700);return p

def parse_folder_url(url):
    u=urlsplit(url.strip())
    if u.scheme!='https' or u.hostname!='drive.google.com':raise DriveError('Hãy nhập link HTTPS thư mục Google Drive.')
    m=re.search(r'/folders/([A-Za-z0-9_-]+)',u.path)
    if not m:raise DriveError('Link cần có dạng drive.google.com/drive/folders/…')
    return m.group(1),parse_qs(u.query).get('resourcekey',[''])[0]

def install_client(path):
    data=json.loads(Path(path).read_text(encoding='utf-8'));cfg=data.get('installed',{})
    if not cfg.get('client_id') or not cfg.get('client_secret'):raise DriveError('Cần tệp OAuth JSON loại Desktop app; không dùng service account hoặc Web application.')
    # Do not accept custom authorization or token endpoints from imported config.
    if cfg.get('auth_uri')!='https://accounts.google.com/o/oauth2/auth' or cfg.get('token_uri')!='https://oauth2.googleapis.com/token':
        raise DriveError('Endpoint OAuth trong tệp không đúng cấu hình Google Desktop app.')
    dest=app_dir()/'oauth_client.json';dest.write_text(json.dumps({'installed':cfg}));dest.chmod(0o600)
    return dest

def client_config():
    p=app_dir()/'oauth_client.json'
    if not p.exists():raise DriveError('Chưa cấu hình Google. Bấm Google Drive → Thiết lập OAuth JSON và làm theo hướng dẫn.')
    return p

class DriveClient:
    def __init__(self,session,credentials=None,key=None,progress=lambda s:None):
        self.session=session;self.credentials=credentials;self.key=key;self.progress=progress
    @classmethod
    def connect(cls,progress=lambda s:None):
        from google.oauth2.credentials import Credentials
        from google.auth.transport.requests import Request,AuthorizedSession
        from google_auth_oauthlib.flow import InstalledAppFlow
        import keyring
        path=client_config();cfg=json.loads(path.read_text())['installed'];key=cfg['client_id'];creds=None
        try:
            token=keyring.get_password(SERVICE,key)
            if token:creds=Credentials.from_authorized_user_info(json.loads(token),SCOPES)
        except Exception:progress('Không đọc được Keychain; có thể cần đăng nhập lại.')
        if creds and not creds.valid and creds.refresh_token:
            try:creds.refresh(Request())
            except Exception:creds=None
        if not creds or not creds.valid:
            progress('Trình duyệt mở để đăng nhập Google. Quyền chỉ đọc Drive; đợi tối đa 3 phút…')
            flow=InstalledAppFlow.from_client_secrets_file(str(path),SCOPES)
            try:
                creds=flow.run_local_server(port=0,timeout_seconds=180,access_type='offline',prompt='consent',success_message='Da ket noi WeddingFlow. Ban co the dong tab nay.')
            except Exception as e:raise DriveError('Chưa đăng nhập được Google. Kiểm tra Desktop client, Drive API và email Test user; xem GOOGLE_DRIVE_SETUP_VI.txt.') from e
        client=cls(AuthorizedSession(creds),creds,key,progress);client.save_credentials();return client
    def save_credentials(self):
        if self.credentials and self.key:
            import keyring
            try:keyring.set_password(SERVICE,self.key,self.credentials.to_json())
            except Exception:self.progress('Không lưu được vào Keychain. Kết nối chỉ dùng trong phiên hiện tại.')
    @staticmethod
    def disconnect():
        import keyring
        cfg=json.loads(client_config().read_text())['installed']
        try:keyring.delete_password(SERVICE,cfg['client_id'])
        except keyring.errors.PasswordDeleteError:pass
    def get(self,url,**kwargs):
        # Authorization is never sent to a host taken from a project file.
        u=urlsplit(url);host=u.hostname or ''
        trusted=host=='www.googleapis.com' or host.endswith('.googleusercontent.com') or host.endswith('.ggpht.com')
        if u.scheme!='https' or not trusted:raise DriveError('Địa chỉ ảnh xem trước không thuộc máy chủ Google được hỗ trợ.')
        for attempt in range(3):
            try:response=self.session.get(url,timeout=(15,90),**kwargs)
            except Exception as e:
                if attempt==2:raise DriveError('Không kết nối được Google. Kiểm tra mạng rồi thử lại.') from e
                time.sleep(attempt+1);continue
            if response.status_code in (429,500,502,503,504) and attempt<2:
                response.close();time.sleep(2**attempt);continue
            if response.status_code>=400:
                code=response.status_code;response.close()
                raise DriveError(f'Google trả lỗi {code}. Kiểm tra tài khoản, quyền xem/tải và giới hạn truy cập.')
            return response
        raise DriveError('Google đang bận; hãy thử lại sau.')
    def metadata(self,file_id,resource_key=''):
        if not re.fullmatch(r'[A-Za-z0-9_-]+',file_id):raise DriveError('ID Google Drive không hợp lệ.')
        headers={'X-Goog-Drive-Resource-Keys':f'{file_id}/{resource_key}'} if resource_key else {}
        r=self.get('https://www.googleapis.com/drive/v3/files/'+file_id,params={'fields':FIELDS,'supportsAllDrives':'true'},headers=headers)
        try:return r.json()
        finally:r.close()
    def iter_images(self,folder_id,resource_key='',recursive=True):
        todo=[(folder_id,resource_key)];seen=set()
        while todo:
            fid,rkey=todo.pop(0)
            if fid in seen:continue
            seen.add(fid);page=None
            while True:
                params={'q':f"'{fid}' in parents and trashed = false",'fields':f'nextPageToken,incompleteSearch,files({FIELDS})','pageSize':1000,'supportsAllDrives':'true','includeItemsFromAllDrives':'true'}
                if page:params['pageToken']=page
                headers={'X-Goog-Drive-Resource-Keys':f'{fid}/{rkey}'} if rkey else {}
                r=self.get('https://www.googleapis.com/drive/v3/files',params=params,headers=headers)
                try:data=r.json()
                finally:r.close()
                if data.get('incompleteSearch'):raise DriveError('Google báo danh sách chưa đầy đủ. Chọn thư mục nhỏ hơn rồi thử lại.')
                for f in data.get('files',[]):
                    if f['mimeType']==FOLDER and recursive:todo.append((f['id'],f.get('resourceKey','')))
                    elif f['mimeType'].startswith('image/'):yield f
                page=data.get('nextPageToken')
                if not page:break
    def preview(self,meta,dest):
        for attempt in range(2):
            link=meta.get('thumbnailLink')
            if not link:raise DriveError('Google chưa cung cấp ảnh xem trước; bỏ qua, không tự tải ảnh gốc.')
            try:
                r=self.get(link,stream=True)
                try:
                    # Bounded preview response, not an unbounded original-file read.
                    chunks=[];total=0
                    for chunk in r.iter_content(64*1024):
                        total+=len(chunk)
                        if total>25*1024*1024:raise DriveError('Ảnh xem trước vượt giới hạn 25 MB.')
                        chunks.append(chunk)
                    data=b''.join(chunks)
                finally:r.close()
                from PIL import Image,ImageOps
                with Image.open(io.BytesIO(data)) as im:
                    im=ImageOps.exif_transpose(im).convert('RGB');im.thumbnail((1600,1600));im.save(dest,'JPEG',quality=94)
                return
            except DriveError:
                if attempt:raise
                meta=self.metadata(meta['id'],meta.get('resourceKey',''))
    def original(self,photo,dest):
        meta=self.metadata(photo.remote_id,photo.remote_key)
        if not meta.get('capabilities',{}).get('canDownload',False):raise DriveError(f'Không có quyền tải ảnh gốc: {photo.remote_name}')
        if remote_version(meta)!=photo.remote_version:raise DriveError(f'Ảnh {photo.remote_name} đã thay đổi trên Drive. Nhập lại album trước khi xuất để tránh dùng nhầm phiên bản.')
        headers={'X-Goog-Drive-Resource-Keys':f'{photo.remote_id}/{photo.remote_key}'} if photo.remote_key else {}
        tmp=dest.with_suffix('.part');digest=hashlib.md5()
        r=self.get('https://www.googleapis.com/drive/v3/files/'+photo.remote_id,params={'alt':'media','supportsAllDrives':'true'},headers=headers,stream=True)
        size=0
        try:
            with tmp.open('wb') as out:
                for chunk in r.iter_content(1024*1024):
                    if chunk:out.write(chunk);digest.update(chunk);size+=len(chunk)
            if meta.get('size') and size!=int(meta['size']):raise DriveError('Ảnh gốc tải chưa đủ dữ liệu; hãy thử xuất lại.')
            if meta.get('md5Checksum') and digest.hexdigest()!=meta['md5Checksum']:raise DriveError('Kiểm tra toàn vẹn ảnh gốc không đạt; hãy thử xuất lại.')
            with ImageCheck(tmp):pass
            tmp.replace(dest)
        finally:r.close();tmp.unlink(missing_ok=True)

class ImageCheck:
    def __init__(self,path):self.path=path
    def __enter__(self):
        # Fully decode once so a truncated JPEG cannot be silently exported.
        im=load_image(self.path);im.close()
    def __exit__(self,*args):return False

def remote_version(meta):return str(meta.get('version') or meta.get('modifiedTime') or 'unknown')
def cache_path(photo,kind='originals',root=None):
    folder=Path(root or app_dir()/'drive_cache')/kind;folder.mkdir(parents=True,exist_ok=True)
    key=hashlib.sha256((photo.remote_id+'@'+photo.remote_version).encode()).hexdigest()
    return folder/(key+'.jpg')

def import_album(client,url,progress=lambda s:None,recursive=True,root=None):
    folder,rkey=parse_folder_url(url);meta=client.metadata(folder,rkey)
    if meta['mimeType']!=FOLDER:raise DriveError('Liên kết không trỏ đến thư mục.')
    photos=[];errors=[]
    for i,m in enumerate(client.iter_images(folder,rkey,recursive)):
        name=m.get('name',m['id']);progress(f'Ảnh xem trước {i+1} · {name}')
        try:
            p=Photo('',0,0,'','0',0,remote_id=m['id'],remote_name=name,remote_version=remote_version(m),remote_key=m.get('resourceKey',''),remote_md5=m.get('md5Checksum',''),remote_size=int(m.get('size',0)))
            path=cache_path(p,'previews',root)
            if path.exists():
                try:load_image(path,64).close()
                except Exception:path.unlink()
            if not path.exists():client.preview(m,path)
            local=inspect_photo(path);p.path=str(path);p.phash=local.phash;p.quality=local.quality
            # A thumbnail checksum is NOT evidence of identical original files.
            p.sha=m.get('sha256Checksum') or ('md5:'+m['md5Checksum'] if m.get('md5Checksum') else 'drive:'+p.remote_id+'@'+p.remote_version)
            dims=m.get('imageMediaMetadata',{});p.width=int(dims.get('width',local.width));p.height=int(dims.get('height',local.height))
            photos.append(p)
        except Exception as e:errors.append(f'{name}: {e}')
    client.save_credentials();return photos,errors

def resolve_export_sources(photos,paths,background=None,progress=lambda s:None,client_factory=None,root=None):
    by_path={str(Path(p.path).resolve()):p for p in photos if p.remote_id}
    chosen=list(dict.fromkeys(list(paths)+([background] if background else [])));resolved={};clients={}
    for path in chosen:
        p=by_path.get(str(Path(path).resolve()))
        if not p:resolved[path]=path;continue
        dest=cache_path(p,'originals',root)
        if dest.exists():
            valid=True
            if p.remote_size and dest.stat().st_size!=p.remote_size:valid=False
            if valid and p.remote_md5:
                d=hashlib.md5()
                with dest.open('rb') as f:
                    for block in iter(lambda:f.read(1024*1024),b''):d.update(block)
                valid=d.hexdigest()==p.remote_md5
            if not valid:dest.unlink()
        if p.remote_mode=='public' and dest.exists():
            # Public mode lacks provider version metadata: refresh selected originals
            # on each export instead of trusting a potentially stale original cache.
            dest.unlink()
        if not dest.exists():
            mode=p.remote_mode
            if mode not in clients:
                if client_factory:clients[mode]=client_factory()
                elif mode=='public':
                    from public_drive import PublicDriveClient
                    clients[mode]=PublicDriveClient()
                else:clients[mode]=DriveClient.connect(progress)
            progress('Tải ảnh gốc được chọn · '+p.remote_name);clients[mode].original(p,dest)
        resolved[path]=str(dest)
    for client in clients.values():client.save_credentials()
    return [resolved[p] for p in paths],resolved.get(background) if background else None


def restore_previews(photos,progress=lambda s:None,client_factory=None,root=None):
    client=None;mapping={};errors=[]
    for p in photos:
        if not p.remote_id or Path(p.path).is_file():continue
        try:
            if p.remote_mode=='public':
                from public_drive import PublicDriveClient,restore_public_preview
                old=p.path;restore_public_preview(p,PublicDriveClient(),root);mapping[old]=p.path;continue
            if client is None:client=client_factory() if client_factory else DriveClient.connect(progress)
            progress('Khôi phục ảnh xem trước · '+p.remote_name)
            meta=client.metadata(p.remote_id,p.remote_key)
            if remote_version(meta)!=p.remote_version:raise DriveError('Ảnh đã đổi phiên bản; cần nhập lại album.')
            path=cache_path(p,'previews',root)
            if not path.exists():client.preview(meta,path)
            # Validate preview before changing any paths in the project.
            load_image(path,64).close();mapping[p.path]=str(path);p.path=str(path)
        except Exception as e:errors.append(p.remote_name+': '+str(e))
    if client:client.save_credentials()
    return mapping,errors
