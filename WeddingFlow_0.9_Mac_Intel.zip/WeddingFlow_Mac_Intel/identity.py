"""Local YuNet/SFace identity matching. No photographs are uploaded.
Weights download once from OpenCV Zoo. Reference photos must contain exactly one face.
"""
from pathlib import Path
import base64,io,os
import numpy as np
from PIL import Image,ImageOps
MODELS={
 'face_detection_yunet_2023mar.onnx':('face_detection_yunet',200000),
 'face_recognition_sface_2021dec.onnx':('face_recognition_sface',30000000),
}
def model_file(name,progress):
    import requests
    root=Path.home()/'.weddingflow'/'models';root.mkdir(parents=True,exist_ok=True);path=root/name
    folder,minimum=MODELS[name]
    if path.exists() and path.stat().st_size>=minimum:return str(path)
    progress('Tải mô hình nhận diện khuôn mặt OpenCV · '+name)
    url=f'https://media.githubusercontent.com/media/opencv/opencv_zoo/main/models/{folder}/{name}'
    temp=path.with_suffix('.download')
    try:
        with requests.get(url,stream=True,timeout=(20,120)) as response:
            response.raise_for_status()
            with temp.open('wb') as f:
                for chunk in response.iter_content(1024*1024):
                    if chunk:f.write(chunk)
        if temp.stat().st_size<minimum:raise ValueError('Tệp mô hình tải về không đầy đủ.')
        os.replace(temp,path)
    finally:
        if temp.exists():temp.unlink()
    return str(path)
class Faces:
    def __init__(self,progress,recognize=True):
        import cv2
        self.cv=cv2;self.detector=cv2.FaceDetectorYN.create(model_file('face_detection_yunet_2023mar.onnx',progress),'',(320,320),.8,.3,5000)
        self.recognizer=cv2.FaceRecognizerSF.create(model_file('face_recognition_sface_2021dec.onnx',progress),'') if recognize else None
    def extract(self,image):
        image=ImageOps.exif_transpose(image).convert('RGB');image.thumbnail((1600,1600))
        arr=np.ascontiguousarray(np.asarray(image)[:,:,::-1]);self.detector.setInputSize((arr.shape[1],arr.shape[0]))
        _,faces=self.detector.detect(arr)
        if faces is None:return [],0
        features=[]
        if self.recognizer:
            for face in faces:
                if min(face[2:4])<32:continue
                feature=self.recognizer.feature(self.recognizer.alignCrop(arr,face)).flatten()
                features.append(feature/max(float(np.linalg.norm(feature)),1e-9))
        return features,len(faces)

def match_identities(features,refs,threshold=.45,margin=.08):
    scores={key:max((float(np.dot(face,ref)) for face in features for ref in entries),default=-1) for key,entries in refs.items()}
    matched=set()
    # A single detected face cannot establish both identities.
    for face in features:
        ranked=sorted(((max(float(np.dot(face,r)) for r in entries),key) for key,entries in refs.items() if entries),reverse=True)
        if ranked and ranked[0][0]>=threshold and (len(ranked)==1 or ranked[0][0]-ranked[1][0]>=margin):matched.add(ranked[0][1])
    return scores,matched

def analyze_people(photos,references,progress):
    from core import load_image
    engine=Faces(progress,bool(references));refs={}
    for key,entries in references.items():
        refs[key]=[]
        for entry in entries:
            with Image.open(io.BytesIO(base64.b64decode(entry['data']))) as image:features,count=engine.extract(image)
            if count!=1 or len(features)!=1:raise ValueError(f'Ảnh tham chiếu {entry["name"]}: cần đúng một khuôn mặt rõ, đủ lớn. Hãy thay ảnh rồi chạy lại.')
            refs[key].append(features[0])
    # SSD person detector covers backs/obscured faces as well; conservative decor filter.
    from ai_check import load_ai_libraries
    torch,tv=load_ai_libraries()
    detector=tv.models.detection.ssdlite320_mobilenet_v3_large(weights=tv.models.detection.SSDLite320_MobileNet_V3_Large_Weights.DEFAULT).eval()
    transform=tv.transforms.ToTensor()
    results=[]
    for i,p in enumerate(photos):
        progress(f'Kiểm tra người / decor {i+1}/{len(photos)}')
        image=load_image(p.path,1600);features,count=engine.extract(image)
        labels=[label for label in p.labels if label not in ('Có cô dâu','Có chú rể','Có cả hai','Cần kiểm tra')]
        state='people' if count else 'unchecked'
        if 'Decor / setup' in labels:
            with torch.inference_mode():prediction=detector([transform(image)])[0]
            person=bool(((prediction['labels']==1)&(prediction['scores']>=.35)).any().item())
            state='people' if person or count else 'no_people'
            if state=='people':labels.remove('Decor / setup');labels.append('Cần kiểm tra')
        scores,matched=match_identities(features,refs)
        if 'bride' in matched:labels.append('Có cô dâu')
        if 'groom' in matched:labels.append('Có chú rể')
        if len(matched)==2:labels.append('Có cả hai')
        if refs:
            labels=[label for label in labels if label not in ('Cô dâu riêng','Chú rể riêng','Cặp đôi')]
            if matched=={'bride','groom'}:labels.append('Cặp đôi')
            elif matched=={'bride'} and count==1:labels.append('Cô dâu riêng')
            elif matched=={'groom'} and count==1:labels.append('Chú rể riêng')
            if not matched and state!='no_people':labels.append('Cần kiểm tra')
        results.append((p,labels,state,scores))
    for p,labels,state,scores in results:p.labels=list(dict.fromkeys(labels));p.people_state=state;p.identity_scores=scores
    return photos

from PySide6.QtGui import QIcon,QPixmap
from PySide6.QtWidgets import QDialog,QHBoxLayout,QVBoxLayout,QLabel,QListWidget,QListWidgetItem,QPushButton,QFileDialog,QDialogButtonBox
from PySide6.QtCore import QSize,Qt
class ReferenceDialog(QDialog):
    def __init__(self,refs,parent=None):
        super().__init__(parent);self.setWindowTitle('Ảnh tham chiếu cô dâu & chú rể');self.resize(650,450);outer=QVBoxLayout(self);outer.addWidget(QLabel('Mỗi ảnh chỉ có một người, rõ mặt. Có thể thêm nhiều góc chụp.\nẢnh tham chiếu được lưu trong dự án và xử lý trên máy.'))
        row=QHBoxLayout();outer.addLayout(row);self.lists={}
        for key,title in [('bride','Cô dâu'),('groom','Chú rể')]:
            col=QVBoxLayout();row.addLayout(col);col.addWidget(QLabel(title));lst=QListWidget();lst.setIconSize(QSize(90,90));self.lists[key]=lst;col.addWidget(lst)
            for entry in refs.get(key,[]):self.add_item(key,entry)
            b=QPushButton('Thêm ảnh');b.clicked.connect(lambda checked=False,k=key:self.add_files(k));col.addWidget(b)
            b=QPushButton('Bỏ ảnh đã chọn');b.clicked.connect(lambda checked=False,l=lst:l.takeItem(l.currentRow()));col.addWidget(b)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel);buttons.accepted.connect(self.accept);buttons.rejected.connect(self.reject);outer.addWidget(buttons)
    def add_item(self,key,entry):
        pix=QPixmap();pix.loadFromData(base64.b64decode(entry['data']));item=QListWidgetItem(QIcon(pix),entry['name']);item.setData(Qt.ItemDataRole.UserRole,entry);self.lists[key].addItem(item)
    def add_files(self,key):
        files,_=QFileDialog.getOpenFileNames(self,'Chọn ảnh tham chiếu','','Images (*.jpg *.jpeg *.png *.webp)')
        for path in files:
            with Image.open(path) as im:
                im=ImageOps.exif_transpose(im).convert('RGB');im.thumbnail((1600,1600));buffer=io.BytesIO();im.save(buffer,format='JPEG',quality=92)
            self.add_item(key,dict(name=Path(path).name,data=base64.b64encode(buffer.getvalue()).decode('ascii')))
    def values(self):
        return {key:[lst.item(i).data(Qt.ItemDataRole.UserRole) for i in range(lst.count())] for key,lst in self.lists.items() if lst.count()}
