"""Fifteen layouts transcribed from the user's October 30 reference images."""
from editorial_layouts import text

def additions09():
    out=[]
    quote='There is never a time\nor place for true love.'
    def add(name,ref,slots,mono=(),wide=False,texts=(),effects=None,bgslots=(),mats=(),calendar=None,curves=False):
        n=len(out)+1
        t=dict(id=f'user-latest-{n:02d}',name=f'{35+n:02d} · Mẫu thêm · {name}',reference_file=f'image(20261030-{ref}).png',slots=slots,mono=list(mono),background='blur',native_orientation='landscape' if wide else 'portrait',text_layers=list(texts),effects=dict(dict(blur=0,wash=0,brightness=65),**(effects or {})),background_slots=list(bgslots),mats=list(mats),curves=curves,slot_roles=['Nền' if i in bgslots else 'Ảnh '+str(i+1) for i in range(len(slots))])
        if calendar is not None:t['calendar']=dict(dict(enabled=True,date='2025-07-26',x=19,y=56,size=65),**calendar)
        out.append(t)
    footer=[text('HELA WEDDING FILM',50,97,12,tracking=25)]
    add('True Love · mười khoảnh khắc','132930',[[.158,.176,.202,.226],[.418,.237,.205,.087],[.71,.268,.186,.218],[.077,.432,.293,.148],[.386,.333,.284,.317],[.691,.502,.19,.212],[.158,.618,.218,.227],[.418,.669,.127,.145],[.563,.749,.118,.13],[.728,.733,.178,.076]],mono=[2],texts=[text(quote,68,22,65,'Allura','#d5a6b9',80,angle=-22,z_order='below')]+footer,effects={'brightness':35},curves=True)
    add('Crimson Details · ba ảnh','132941',[[.486,.378,.416,.37],[.068,.563,.377,.31],[.548,.719,.268,.233]],texts=[text('HELA',84,32,65,'Cormorant Garamond',width=30),text('Wedding Film',85,35,16,width=28),text('Our wedding story\nA day to remember\nTogether, always',31,36,21,'Cormorant Garamond','#ddc274',35)]+footer)
    add('Red Editorial · bốn khung','132944',[[.247,.054,.447,.445],[.72,.403,.28,.393],[.217,.67,.267,.266],[.083,.713,.267,.268]],texts=[text('HELA',40,53,34,'Cormorant Garamond'),text('A day to remember\nOur wedding story',46,59,13,width=30)]+footer,effects={'brightness':75,'blur':20})
    add('Mono Portrait · ảnh đơn','132959',[[.225,.195,.55,.611]],mono=[0],texts=[text(quote,78,13,60,'Allura','#d5a6b9',58,angle=-20,z_order='below')]+footer)
    add('Wedding Calendar · đỏ','133000',[[.31,.132,.456,.506],[.31,.638,.456,.216],[.121,.676,.253,.284],[.146,.04,.227,.183]],mono=[2],texts=[text('HELA',37,53,50,width=20),text('Wedding Film',38,55,10,width=20)]+footer,calendar={})
    add('Two Portraits · màu & mono','133001',[[.22,.234,.487,.481],[.374,.35,.396,.394]],mono=[0],texts=[text('WISH YOU / A HAPPY / WEDDING',50,7,18,'Cormorant Garamond')]+footer)
    add('Celebration · một ảnh lớn','133010',[[.18,.231,.64,.655]],texts=[text('Forever',50,17,60,'Allura'),text('Together, always',50,20,12)]+footer)
    add('Green Editorial · ba ảnh','133025',[[.323,.195,.4,.45],[.131,.298,.218,.275],[.636,.488,.242,.307]],mono=[0],texts=[text(quote,46,12,65,'Allura','#e7da13',85,angle=-20,z_order='below'),text('HELA',50,59,180,'Cormorant Garamond','#ead600'),text('From Soc Son',50,72,45,'Dancing Script','#ead600'),text('Our wedding story',50,77,15,'Cormorant Garamond','#ead600')]+footer,effects={'brightness':55})
    add('Sage Memories · ba ảnh','133027',[[.168,.268,.439,.18],[.202,.29,.16,.118],[.168,.483,.574,.279]],texts=footer,effects={'brightness':105,'wash':35,'tone':'warm'},mats=[([.168,.066,.208,.87],'#e6ecd5',25)])
    add('Calendar Cover · toàn ảnh','133038',[[0,0,1,1]],texts=[text('HELA',72,10,90,width=40),text('Wedding Film',76,14,18,width=35)],bgslots=(),calendar={'x':33,'y':15,'size':100},effects={'brightness':100})
    # Screenshot controls (Like/Love/back) are excluded from the layout.
    add('Journey · hai tầng','133047',[[0,0,1,.512],[0,.512,1,.488],[.15,.649,.7,.291]],mono=[1,2],bgslots=[1],texts=[text("Love’s journey",50,60,80,'Allura','#e6bb34')]+footer,effects={'brightness':100})
    add('Save the Date · ngang','133055',[[.126,.206,.748,.516]],wide=True,texts=[text('Save The\nDate',86,15,70,'Allura','#73574b',30),text('Our wedding day · A new chapter begins',50,76,18,'Cormorant Garamond','#73574b'),text('HELA WEDDING FILM',50,82,12,'Montserrat','#73574b',tracking=20)],effects={'brightness':110,'wash':60})
    add('Journey · hai trang mono & màu','133100',[[.5,0,.5,1],[.168,.077,.4,.797]],wide=True,mono=[1],bgslots=[0],texts=[text("Love’s journey",37,79,60,'Allura',width=35),text('HELA WEDDING FILM',38,5,12,tracking=20,width=40)],effects={'brightness':100})
    add('White Story · ba chân dung','133102',[[.058,.096,.518,.488],[.599,.308,.298,.278],[.21,.646,.323,.304]],mono=[2],texts=[text('FLOWERS AND TIE / MULBERRY KNOT / AND MUSIC',50,6,13,'Cormorant Garamond','#222222'),text('WISH YOU / A HAPPY / WEDDING',50,61,16,'Cormorant Garamond','#222222'),text('Forever',76,84,60,'Allura','#222222',35),text('HELA WEDDING FILM',73,92,11,'Montserrat','#222222',40)],effects={'brightness':110,'wash':50})
    add('Pink Details · ba khung','133109',[[.202,.088,.42,.473],[.102,.44,.208,.237],[.418,.612,.29,.313]],mono=[1],texts=[text('19 July / Our wedding day',58,58,20,'Cormorant Garamond',width=40)]+footer,effects={'brightness':95,'blur':10,'wash':15})
    return out
