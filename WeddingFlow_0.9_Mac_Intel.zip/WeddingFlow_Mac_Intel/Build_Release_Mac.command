#!/bin/bash
set -e
cd -- "$(dirname -- "$0")"
task_python=""
for candidate in /opt/homebrew/bin/python3.12 /opt/homebrew/bin/python3.11 /usr/local/bin/python3.12 /usr/local/bin/python3.11; do
  if [ -x "$candidate" ]; then task_python="$candidate"; break; fi
done
if [ -z "$task_python" ]; then task_python="$(command -v python3 || true)"; fi
if [ -z "$task_python" ]; then echo 'Install Python 3.11 or 3.12 to build.'; exit 1; fi
"$task_python" mac_release.py
