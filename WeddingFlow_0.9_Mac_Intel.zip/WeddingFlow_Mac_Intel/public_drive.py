"""Convenience mode for deliberately public Drive links; no OAuth or cookies.
Uses public web endpoints which Google may change or rate-limit.
"""
from __future__ import annotations
import hashlib,io
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from core import Photo,inspect_photo,load_image,EXTS
from drive_source import DriveError,cache_path,parse_folder_url

class PublicDriveClient:
    def save_credentials(self):pass
    def preview(self,file_id,dest):
        import requests
        from PIL import Image,ImageOps
        try:
            with requests.get('https://drive.google.com/thumbnail',params={'id':file_id,'sz':'w1200'},timeout=(15,45),stream=True) as r:
                if r.status_code!=200 or not r.headers.get('content-type','').startswith('image/'):
                    raise DriveError('Không lấy được preview công khai. Kiểm tra quyền chia sẻ hoặc thử lại sau.')
                blocks=[];size=0
                for block in r.iter_content(65536):
                    size+=len(block)
                    if size>25*1024*1024:raise DriveError('Preview vượt giới hạn dung lượng.')
                    blocks.append(block)
            with Image.open(io.BytesIO(b''.join(blocks))) as src:
                im=ImageOps.exif_transpose(src).convert('RGB');im.thumbnail((1600,1600));im.save(dest,'JPEG',quality=94)
        except DriveError:raise
        except Exception as e:raise DriveError('Không đọc được preview. Google có thể đang giới hạn truy cập; thử lại sau.') from e
    def original(self,photo,dest):
        import gdown
        tmp=dest.with_suffix('.part')
        try:
            result=gdown.download(id=photo.remote_id,output=str(tmp),quiet=True,use_cookies=False,timeout=(15,60),retries=1)
            if not result or not tmp.is_file():raise DriveError('Chưa tải được ảnh gốc.')
            im=load_image(tmp);im.close();tmp.replace(dest)
        except Exception as e:
            raise DriveError('Google chưa cho tải ảnh gốc '+photo.remote_name+'. Bạn có thể tải riêng ảnh này bằng trình duyệt rồi dùng Thay ảnh từ máy; hoặc dùng Drive riêng tư để đăng nhập.') from e
        finally:tmp.unlink(missing_ok=True)

def public_records(url):
    import gdown
    parse_folder_url(url)
    # skip_download prevents any original photo downloads during enumeration.
    try:records=gdown.download_folder(url=url,skip_download=True,quiet=True,use_cookies=False,timeout=(15,45))
    except Exception as e:raise DriveError('Chưa đọc được danh sách công khai. Đặt thư mục và ảnh ở quyền Người xem qua liên kết, kiểm tra mở được trong cửa sổ ẩn danh rồi thử lại. Nếu Google giới hạn truy cập, có thể cần đợi hoặc dùng Drive riêng tư.') from e
    return [r for r in records if Path(r.path).suffix.lower() in EXTS]

def import_public_album(url,progress=lambda s:None,root=None,records=None,client=None):
    parse_folder_url(url);client=client or PublicDriveClient()
    progress('Đọc danh sách công khai · không tải ảnh gốc…')
    records=public_records(url) if records is None else records
    # De-duplicate IDs before parallel fetching; never trust remote filenames as paths.
    records=list({r.id:r for r in records}.values())
    photos=[];errors=[]
    def fetch(record):
        getattr(getattr(progress,'__self__',None),'checkpoint',lambda:None)()
        p=Photo('',0,0,'public:'+record.id,'0',0,remote_id=record.id,remote_name=Path(record.path).name,remote_version='public',remote_mode='public')
        pending=cache_path(p,'previews',root);pending=pending.with_suffix('.pending.jpg')
        try:
            # Refresh preview on import. Public listing has no reliable version/checksum.
            client.preview(p.remote_id,pending);local=inspect_photo(pending)
            p.remote_version='public-preview-'+local.sha
            target=cache_path(p,'previews',root);pending.replace(target)
            p.path=str(target);p.width=local.width;p.height=local.height;p.phash=local.phash;p.quality=local.quality
            return p
        finally:pending.unlink(missing_ok=True)
    with ThreadPoolExecutor(max_workers=4) as executor:
        tasks={executor.submit(fetch,r):r for r in records}
        for i,future in enumerate(as_completed(tasks)):
            r=tasks[future];progress(f'Ảnh xem trước {i+1}/{len(records)} · {Path(r.path).name}')
            try:photos.append(future.result())
            except Exception as e:errors.append(Path(r.path).name+': '+str(e))
    photos.sort(key=lambda p:p.remote_name)
    return photos,errors

def restore_public_preview(photo,client,root=None):
    from types import SimpleNamespace
    photos,errors=import_public_album('https://drive.google.com/drive/folders/restore',root=root,records=[SimpleNamespace(id=photo.remote_id,path=photo.remote_name)],client=client)
    if errors or not photos:raise DriveError(errors[0] if errors else 'Không khôi phục được preview.')
    new=photos[0]
    # Keep existing labels and manual selections; refresh only source/preview data.
    for key in ['path','remote_version','width','height','phash','quality']:setattr(photo,key,getattr(new,key))
    photo.embedding=[]
    return photo.path
