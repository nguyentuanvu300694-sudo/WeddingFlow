"""Editable wedding-date strip; dates are actual calendar dates across month boundaries."""
from datetime import date,timedelta
from PIL import Image,ImageDraw,ImageColor

def calendar_dates(value):
    selected=date.fromisoformat(value)
    return [selected+timedelta(days=i) for i in range(-4,1)]

def apply_calendar(image,c):
    if not c.get('enabled'):return image
    from typography import get_font
    days=calendar_dates(c.get('date',date.today().isoformat()));chosen=days[-1]
    w,h=image.size;scale=min(w,h)*float(c.get('size',100))/100
    pw,ph=max(1,round(scale*.58)),max(1,round(scale*.25))
    plate=Image.new('RGBA',(pw,ph));d=ImageDraw.Draw(plate)
    color=c.get('color','#ffffff');accent=c.get('accent','#eb182b');font=c.get('font','Montserrat')
    small=get_font(font,max(6,scale*.019));big=get_font(font,max(8,scale*.032))
    months=['January','February','March','April','May','June','July','August','September','October','November','December']
    d.text((pw*.03,0),f'{months[chosen.month-1]}\n{chosen.year}',font=small,fill=color)
    for i,day in enumerate(days):
        x=pw*(.07+i*.18);y=ph*.64;r=scale*.027
        if day==chosen:d.ellipse((x-r,y-r,x+r,y+r),fill=accent)
        d.text((x,y),str(day.day),font=big,fill=color,anchor='mm')
    d.line((pw*.96,0,pw*.96,ph),fill=color,width=max(1,round(scale*.0015)))
    plate.putalpha(plate.getchannel('A').point(lambda v:round(v*max(0,min(100,c.get('opacity',100)))/100)))
    out=image.convert('RGBA');out.alpha_composite(plate,(round(w*c.get('x',25)/100-pw/2),round(h*c.get('y',20)/100-ph/2)))
    return out.convert('RGB')

from PySide6.QtCore import QDate
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QDialog,QFormLayout,QCheckBox,QDateEdit,QComboBox,QSpinBox,QPushButton,QColorDialog,QDialogButtonBox
class CalendarDialog(QDialog):
    def __init__(self,config,parent=None):
        super().__init__(parent);self.setWindowTitle('Typo lịch ngày cưới');self.config=dict(config);f=QFormLayout(self)
        self.enabled=QCheckBox('Hiện lịch');self.enabled.setChecked(config.get('enabled',True));f.addRow(self.enabled)
        self.day=QDateEdit();self.day.setCalendarPopup(True);self.day.setDisplayFormat('dd/MM/yyyy');self.day.setDate(QDate.fromString(config.get('date',''),'yyyy-MM-dd') if config.get('date') else QDate.currentDate());f.addRow('Ngày cưới',self.day)
        from typography import font_catalog
        self.font=QComboBox();self.font.addItems([x['name'] for x in font_catalog()]);self.font.setCurrentText(config.get('font','Montserrat'));f.addRow('Font',self.font)
        self.controls={}
        for key,label,low,high,default in [('x','Vị trí ngang %',0,100,25),('y','Vị trí dọc %',0,100,20),('size','Kích thước %',20,200,100),('opacity','Độ rõ %',0,100,100)]:
            spin=QSpinBox();spin.setRange(low,high);spin.setValue(config.get(key,default));self.controls[key]=spin;f.addRow(label,spin)
        self.order=QComboBox();self.order.addItems(['Trên ảnh','Dưới ảnh']);self.order.setCurrentIndex(1 if config.get('z_order')=='below' else 0);f.addRow('Thứ tự lớp',self.order)
        for key,label,default in [('color','Màu chữ','#ffffff'),('accent','Màu khoanh ngày','#eb182b')]:
            b=QPushButton(label);b.clicked.connect(lambda checked=False,k=key,d=default:self.choose_color(k,d));f.addRow(b)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel);buttons.accepted.connect(self.accept);buttons.rejected.connect(self.reject);f.addRow(buttons)
    def choose_color(self,key,default):
        color=QColorDialog.getColor(QColor(self.config.get(key,default)),self)
        if color.isValid():self.config[key]=color.name()
    def values(self):
        return dict(self.config,enabled=self.enabled.isChecked(),date=self.day.date().toString('yyyy-MM-dd'),font=self.font.currentText(),z_order='below' if self.order.currentIndex() else 'above',**{k:v.value() for k,v in self.controls.items()})
