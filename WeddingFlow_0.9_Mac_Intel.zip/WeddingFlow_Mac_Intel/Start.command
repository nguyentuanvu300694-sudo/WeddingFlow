#!/bin/bash
set -e
cd -- "$(dirname -- "$0")"
export PYTORCH_ENABLE_MPS_FALLBACK=1
if [ ! -x .venv/bin/python ]; then
  task_python=""
  for candidate in /opt/homebrew/bin/python3.12 /opt/homebrew/bin/python3.11 /opt/homebrew/bin/python3 /usr/local/bin/python3.12 /usr/local/bin/python3.11; do
    if [ -x "$candidate" ] && "$candidate" -c 'import sys; assert (3,10)<=sys.version_info[:2]<=(3,13)' 2>/dev/null; then
      task_python="$candidate"
      break
    fi
  done
  if [ -z "$task_python" ] && command -v python3 >/dev/null && python3 -c 'import sys; assert (3,10)<=sys.version_info[:2]<=(3,13)' 2>/dev/null; then task_python="$(command -v python3)"; fi
  if [ -z "$task_python" ]; then
    echo 'Can cai Python 3.11 hoac 3.12 tu https://www.python.org/downloads/macos/ truoc.'
    read -r -p 'Nhan Enter de dong…';exit 1
  fi
  "$task_python" -m venv .venv
fi
task_deps=$(.venv/bin/python -c 'import hashlib; print(hashlib.sha256(open("requirements.txt","rb").read()).hexdigest())')
if [ ! -f .venv/.requirements.sha256 ] || [ "$(cat .venv/.requirements.sha256)" != "$task_deps" ]; then
  echo 'Dang cai thu vien cho lan dau. Can Internet va dung luong trong.'
  if .venv/bin/python -m pip install --upgrade pip && .venv/bin/python -m pip install -r requirements.txt; then
    printf "%s" "$task_deps" > .venv/.requirements.sha256
  else
    echo 'Cai dat chua thanh cong. Kiem tra mang va thu lai.'
    read -r -p 'Nhan Enter de dong…';exit 1
  fi
fi
.venv/bin/python app.py
