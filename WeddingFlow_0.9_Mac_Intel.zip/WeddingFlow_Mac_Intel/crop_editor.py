"""Per-slot crop editor with draggable preview and independent zoom."""
from PySide6.QtCore import Qt,Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QDialog,QLabel,QVBoxLayout,QHBoxLayout,QSlider,QPushButton,QDialogButtonBox
from PIL.ImageQt import ImageQt
from core import normalize_crop,crop_geometry,crop_to_slot,load_image

class DragPreview(QLabel):
    moved=Signal(float,float)
    def __init__(self):
        super().__init__();self.anchor=None;self.setAlignment(Qt.AlignmentFlag.AlignCenter);self.setCursor(Qt.CursorShape.OpenHandCursor)
    def mousePressEvent(self,event):
        if event.button()==Qt.MouseButton.LeftButton:self.anchor=event.position();self.setCursor(Qt.CursorShape.ClosedHandCursor)
    def mouseMoveEvent(self,event):
        if self.anchor is not None:
            delta=event.position()-self.anchor;self.anchor=event.position();self.moved.emit(delta.x(),delta.y())
    def mouseReleaseEvent(self,event):self.anchor=None;self.setCursor(Qt.CursorShape.OpenHandCursor)

class CropEditor(QDialog):
    def __init__(self,path,aspect,crop,parent=None):
        super().__init__(parent);self.setWindowTitle('Crop & zoom · ảnh trong ô layout');self.resize(640,700)
        self.source=load_image(path,2000);self.original=normalize_crop(crop);self.aspect=aspect
        layout=QVBoxLayout(self);layout.addWidget(QLabel('Kéo ảnh để chọn vùng hiển thị. Zoom để phóng to.'))
        self.preview=DragPreview();self.preview.setMinimumSize(200,240);layout.addWidget(self.preview,1)
        self.controls=[];self.labels=[];self._pan_position=None
        for title,low,high,value in [('Ngang',0,100,round(self.original[0]*100)),('Dọc',0,100,round(self.original[1]*100)),('Zoom',100,400,round(self.original[2]*100))]:
            row=QHBoxLayout();label=QLabel(title);label.setMinimumWidth(95);row.addWidget(label);slider=QSlider(Qt.Orientation.Horizontal);slider.setRange(low,high);slider.setValue(value);row.addWidget(slider);layout.addLayout(row);self.controls.append(slider);self.labels.append(label);slider.valueChanged.connect(self.control_changed)
        reset=QPushButton('Đặt lại · vừa khung');reset.clicked.connect(self.reset);layout.addWidget(reset)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel);buttons.accepted.connect(self.accept);buttons.rejected.connect(self.reject);layout.addWidget(buttons)
        self.preview.moved.connect(self.pan);self.redraw()
    def values(self):return [self.controls[0].value()/100,self.controls[1].value()/100,self.controls[2].value()/100]
    def control_changed(self,*args):
        self._pan_position=None;self.redraw()
    def reset(self):
        self._pan_position=None
        for c,v in zip(self.controls,[50,50,100]):c.blockSignals(True);c.setValue(v);c.blockSignals(False)
        self.redraw()
    def pan(self,dx,dy):
        crop=list(self._pan_position or self.values());rect=crop_geometry(self.source.size,(self.aspect,1),crop);vw,vh=rect[2]-rect[0],rect[3]-rect[1];pix=self.preview.pixmap()
        if pix is None:return
        for i,delta,visible,total,pixels in [(0,dx,vw,self.source.width,pix.width()),(1,dy,vh,self.source.height,pix.height())]:
            if total-visible>1e-6:
                crop[i]=max(0,min(1,crop[i]-delta/max(1,pixels)*visible/(total-visible)))
                self.controls[i].blockSignals(True);self.controls[i].setValue(round(crop[i]*100));self.controls[i].blockSignals(False)
        self._pan_position=crop;self.redraw()
    def redraw(self,*args):
        if len(self.controls)!=3:return
        w=max(1,min(540,round(440*self.aspect)));h=max(1,round(w/self.aspect))
        if h>440:h=440;w=max(1,round(h*self.aspect))
        im=crop_to_slot(self.source,(w,h),self.values());self.preview.setPixmap(QPixmap.fromImage(ImageQt(im)))
        for label,title,c in zip(self.labels,['Ngang','Dọc','Zoom'],self.controls):label.setText(title+' '+str(c.value())+'%')
    def done(self,result):
        self.source.close();super().done(result)
