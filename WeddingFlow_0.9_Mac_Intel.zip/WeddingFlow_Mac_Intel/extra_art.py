"""48 additional original English compositions in four distinct design families."""
from PIL import Image,ImageDraw,ImageColor

def extra_artworks():
 groups={
 'Signature':[
 ('Every little thing','Every little thing','LEADS ME BACK TO YOU'),('My heart is yours','My heart is yours','TODAY AND ALL OUR TOMORROWS'),('Once and for all','Once and for all','I CHOOSE YOU'),('Wonderful us','Wonderful us','A LITTLE LOVE · A LIFETIME OF JOY'),('The sweetest yes','The sweetest yes','OUR NEW CHAPTER'),('Dreaming of you','Dreaming of you','AND THE DAYS STILL TO COME'),('All our tomorrows','All our tomorrows','BEGIN WITH THIS MOMENT'),('You, my forever','You, my forever','WITH AN OPEN HEART'),('Stay close to me','Stay close to me','THROUGH EVERY SEASON'),('Love lives here','Love lives here','IN THE LITTLE THINGS'),('My favorite person','My favorite person','MY FAVORITE PLACE TO BE'),('A promise in bloom','A promise in bloom','GROWING TOGETHER')],
 'Modern Editorial':[
 ('The best day','BEST DAY','A celebration of us'),('Groom & bride','GROOM & BRIDE','A new chapter together'),('This heart is yours','THIS HEART','is yours'),('The wedding journal','WEDDING','our little journal'),('A day for us','A DAY FOR US','One beautiful beginning'),('Love is an adventure','LOVE IS','an adventure'),('Beautifully together','TOGETHER','beautifully, always'),('Twenty four hours of love','24 HOURS','one lifetime of love'),('The forever edition','FOREVER','the love edition'),('Hold my hand','HOLD MY HAND','wherever we may go'),('A story called us','A STORY','called us'),('The art of loving','THE ART','of loving you')],
 'Romantic Flourish':[
 ('Romantic story','Romantic story','OUR BEAUTIFUL BEGINNING'),('Love in autumn','Love in autumn','A SEASON TO REMEMBER'),('Blooming hearts','Blooming hearts','GENTLE DAYS · ENDLESS LOVE'),('Golden romance','Golden romance','A LITTLE MAGIC IN EVERY DAY'),('A garden of promises','Garden of promises','ROOTED IN LOVE'),('The love journey','The love journey','BEAUTY IN EVERY CHAPTER'),('Tender moments','Tender moments','THE MOMENTS WE KEEP'),('Forever in bloom','Forever in bloom','TWO HEARTS GROWING TOGETHER'),('Whispers of love','Whispers of love','SOFT WORDS · LASTING PROMISES'),('Our enchanted day','Our enchanted day','THE BEGINNING OF SOMETHING BEAUTIFUL'),('A graceful love','A graceful love','WRITTEN IN OUR EVERYDAY'),('Sweet devotion','Sweet devotion','ONE HEART · ONE PROMISE')],
 'Magazine Collage':[
 ('Our kind of magic','Our kind','of magic'),('Love, in detail','Love','in detail'),('You & me','You & me','A LITTLE WORLD OF OUR OWN'),('The way we love','The way','we love'),('Forever begins today','Forever','begins today'),('Something beautiful','Something','beautiful'),('A thousand little joys','A thousand','little joys'),('We belong together','We belong','together'),('A moment, a lifetime','A moment','a lifetime'),('The joy of us','The joy','of us'),('Dear tomorrow','Dear','tomorrow'),('Our next chapter','Our next','chapter')]
 }
 return [dict(title=title,top=top,bottom=bottom,group=group,design=group) for group,items in groups.items() for title,top,bottom in items]

def draw_extra(a,index,color,bezier):
 from typography import get_font
 im=Image.new('RGBA',(2400,1300));d=ImageDraw.Draw(im);fill=ImageColor.getrgb(color)+(255,)
 def text(s,font,size,top,left=None,limit=2120):
  f=get_font(font,size)
  while d.textlength(s,font=f)>limit and f.size>8:f=get_font(font,f.size-3)
  box=d.textbbox((0,0),s,font=f);x=(2400-d.textlength(s,font=f))/2 if left is None else left
  d.text((x,top-box[1]),s,font=f,fill=fill)
  return top+box[3]-box[1]
 design=a['design'];top=a['top'];bottom=a['bottom']
 if design=='Signature':
  y=text(top,['Allura','Dancing Script','Great Vibes'][index%3],295,150)
  bezier(d,[(240,y+75),(850,y-15),(1450,y+145),(2170,y+35)],fill,3)
  text(bottom,'Montserrat',45,y+160)
 elif design=='Modern Editorial':
  # A monumental script initial sits beside a restrained editorial wordmark.
  initial=top[0];text(initial,'Great Vibes',670,65,left=95,limit=650)
  main=top[1:] if len(top)>1 else top
  y=text(main,'Playfair Display',184,260,left=730,limit=1500)
  d.line((760,y+70,2170,y+70),fill=fill,width=5)
  text(bottom,'Allura',150,y+125,left=730,limit=1500)
  text('THE WEDDING COLLECTION','Montserrat',36,920)
 elif design=='Romantic Flourish':
  y=text(top,'Great Vibes',275,220)
  text(bottom,'Cormorant Garamond',58,y+135)
  # Mirrored pen curves, with small leaf-shaped ornaments.
  for flip in [False,True]:
   pts=[(200,190),(300,-20),(1030,250),(1150,110)]
   if flip:pts=[(2400-x,y) for x,y in pts]
   bezier(d,pts,fill,4)
  by=y+290
  bezier(d,[(250,by),(570,by+190),(1550,by-90),(2170,by+20)],fill,4)
  for x,sgn in [(430,1),(1970,-1)]:
   bezier(d,[(x,by+15),(x+sgn*100,by-110),(x+sgn*155,by-60),(x,by+15)],fill,3)
 else:
  text('LOVE / LIFE / TOGETHER','Montserrat',37,80)
  y=text(top,'Playfair Display Italic',195,220,left=220,limit=1900)
  d.line((220,y+75,570,y+75),fill=fill,width=17)
  y=text(bottom,'Allura',230,y+130,left=540,limit=1650)
  text('We find beauty in the days we share.','Cormorant Garamond',55,y+100)
  text('A quiet promise, a brighter tomorrow.','Cormorant Garamond Italic',49,y+175)
 box=im.getbbox()
 if not box:return im
 x0,y0,x1,y1=box;pad=45
 return im.crop((max(0,x0-pad),max(0,y0-pad),min(im.width,x1+pad),min(im.height,y1+pad)))
