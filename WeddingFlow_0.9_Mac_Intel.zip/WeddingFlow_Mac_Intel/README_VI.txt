ĐỌC README_0.9_VI.txt để xem tính năng mới và hướng dẫn build 0.9.

WeddingFlow 0.9 — CHỈ CÁC LAYOUT TỪ ẢNH THAM KHẢO
Catalog: 15 ảnh bộ trước + 20 ảnh bộ mới = 35 layout. Bộ trước nhận được 15 tệp, chưa có tệp thứ 16; không tự thêm bố cục.
Đã bỏ 60 layout tự tạo khỏi danh sách. Mỗi mẫu có id và tên tệp tham khảo để đối chiếu.
TEXT & FONT: nhiều lớp chữ, nhập nội dung, font, cỡ chữ, màu, giãn chữ/dòng, độ đậm, xoay, căn dòng, vị trí và độ rõ. Có nhập TTF/OTF, font lưu kèm dự án. Chọn Chữ theo mẫu hiện tại để khôi phục bố cục chữ tham khảo.
Font có sẵn được phối gần phong cách mẫu; chưa có font gốc để bảo đảm khớp 100%. Nội dung chữ và tên studio đều sửa được.
Crop/zoom từng ô, nền mờ/film, viền/bo góc, PNG typography, tạm dừng import được giữ nguyên. Ảnh gốc không bị sửa.
Dự án cũ có layout được giữ lại sẽ chuyển theo id/legacy; nếu layout bị loại hoặc số ô khác sẽ yêu cầu tạo bố cục lại, không ghép sai ô.
Ba gói native riêng: Windows x64, Mac Intel x86_64, Mac chip M arm64. Tệp ZIP là mã nguồn/script build. GitHub Actions tạo và kiểm tra EXE/DMG trên từng hệ điều hành tương ứng.
