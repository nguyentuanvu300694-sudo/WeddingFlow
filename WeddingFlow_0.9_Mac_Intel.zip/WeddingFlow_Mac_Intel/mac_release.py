"""Build a real .app/.dmg on macOS; refuses to simulate output on Linux."""
from pathlib import Path
import os,sys,platform,subprocess,tempfile,shutil
ROOT=Path(__file__).resolve().parent

def command(args,env=None):
 print('Running:', ' '.join(str(a) for a in args),flush=True)
 subprocess.run([str(a) for a in args],cwd=ROOT,env=env,check=True)

def check_platform():
 if sys.platform!='darwin':raise RuntimeError('A real Mac/macOS build runner is required to create .app and .dmg.')
 if sys.version_info[:2] not in [(3,11),(3,12)]:raise RuntimeError('Use Python 3.11 or 3.12.')
 if platform.machine()!='x86_64':raise RuntimeError('This package requires Mac Intel / x86_64. Use the matching GitHub runner.')

def main():
 check_platform();python=ROOT/'.venv-mac-build'/'bin'/'python'
 if not python.exists():command([sys.executable,'-m','venv',ROOT/'.venv-mac-build'])
 command([python,'-m','pip','install','--upgrade','pip'])
 command([python,'-m','pip','install','--upgrade','-r',ROOT/'requirements.txt','-r',ROOT/'requirements-mac-x86_64.txt','PyInstaller>=6.16,<7','pyinstaller-hooks-contrib'])
 command([python,'-m','pip','check'])
 command([python,ROOT/'ai_check.py'])
 command([python,ROOT/'native_vision_check.py'])
 command([python,'-m','unittest','discover','-s','tests'])
 env=os.environ.copy();env.setdefault('MACOSX_DEPLOYMENT_TARGET','14.0')
 command([python,'-m','PyInstaller','--clean','--noconfirm','WeddingFlow_Mac.spec'],env)
 bundle=ROOT/'dist'/'WeddingFlow.app';binary=bundle/'Contents'/'MacOS'/'WeddingFlow'
 if not binary.exists():raise RuntimeError('No macOS app was produced.')
 test_env=env.copy();test_env['QT_QPA_PLATFORM']='offscreen'
 subprocess.run([str(binary),'--self-test'],cwd=ROOT,env=test_env,check=True,timeout=600)
 command(['codesign','--verify','--deep','--strict',bundle])
 dmg=ROOT/'dist'/('WeddingFlow_0.9_Mac_Intel_'+platform.machine()+'.dmg')
 with tempfile.TemporaryDirectory(prefix='weddingflow-dmg-') as folder:
  stage=Path(folder);command(['ditto',bundle,stage/'WeddingFlow.app'])
  (stage/'Applications').symlink_to('/Applications')
  command(['hdiutil','create','-volname','WeddingFlow','-srcfolder',stage,'-ov','-format','UDZO',dmg])
 command(['hdiutil','verify',dmg])
 profile=os.environ.get('WEDDING_NOTARY_PROFILE')
 if profile:
  if not os.environ.get('WEDDING_CODESIGN_IDENTITY'):raise RuntimeError('Notarization requires a Developer ID signing identity, not ad-hoc signing.')
  command(['xcrun','notarytool','submit',dmg,'--keychain-profile',profile,'--wait'])
  command(['xcrun','stapler','staple',dmg]);command(['xcrun','stapler','validate',dmg])
 print('DMG:',dmg,flush=True)
 print('Developer ID notarized.' if profile else 'Ad-hoc signed, not notarized. macOS may require first-open approval.',flush=True)

if __name__=='__main__':
 try:main()
 except Exception as e:print('FAILED:',e,flush=True);sys.exit(1)
