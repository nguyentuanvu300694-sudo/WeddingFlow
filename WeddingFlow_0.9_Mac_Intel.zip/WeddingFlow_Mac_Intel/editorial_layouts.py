"""Only user-supplied references: 15 earlier images + 20 newly supplied images."""
from copy import deepcopy
from reference_layouts import reference_templates

def text(content,x,y,size=24,font='Montserrat',color='#ffffff',width=80,**extra):
    return dict(dict(text=content,x=x,y=y,size=size,font=font,color=color,width=width,align='center',tracking=0,leading=115,angle=0,opacity=100,weight=400),**extra)

def supplied_templates():
    old=reference_templates()
    oldtitles=['I will love you forever','LỄ ĂN HỎI','every day','Romantic\nLOVE','Beautiful\nin white','FOREVER','ON YOUR\nwedding DAY','SUNFLOWER','The future','WHEREVER\nYOU ARE','First Sight','every day','Our love','Wherever you are','MAGAZINE']
    oldfiles=['093438','093441','093446','093447','093453','093457','093501','093503','093506','093514','093522','093529','093558','093603','093607']
    for i,t in enumerate(old):
        t['id']=f'user-old-{i+1:02d}';t['legacy_index']=60+i
        t['name']=f'{i+1:02d} · Bộ trước · '+t['name'].split('·',2)[-1].strip()
        t['reference_file']=f'image(20261030-{oldfiles[i]}).png'
        t['text_layers']=[text(oldtitles[i],72 if i in (0,4) else 50,93 if i not in (1,3,8,9) else 8,70 if i not in (1,5,7,14) else 45,'Allura' if i in (0,3,4,8,10) else 'Montserrat',width=65),text('OUR WEDDING STORY',50,97,10,tracking=18)]
    out=old
    def add(title,filename,slots,bg='blur',wide=False,mono=(),mats=(),panels=(),texts=(),effects=None,roles=None,styles=None):
        i=len(out)+1
        out.append(dict(id=f'user-new-{i-15:02d}',name=f'{i:02d} · Bộ mới · {title}',reference_file='image(20261030-'+filename+').png',slots=slots,background=bg,mono=list(mono),native_orientation='landscape' if wide else 'portrait',mats=list(mats),background_panels=list(panels),text_layers=list(texts),effects=dict(dict(blur=0,wash=0,brightness=100),**(effects or {})),slot_roles=roles or ['Ảnh '+str(k+1) for k in range(len(slots))],slot_styles=styles or {}))
    footer=lambda:[text('AUTUMN\n2024',17,93,16,width=25),text('H.ANH\n& H.NAM',50,93,16,width=26),text('HANOI\nVIET NAM',83,93,16,width=25)]
    add("Love’s Journey · hai tầng",'115906',[[0,0,1,.5],[0,.5,.5,.5],[.5,.5,.5,.5],[.507,.016,.44,.466],[.268,.509,.456,.482]],bg='white',texts=[text("Love’s journey",50,56,75,'Allura','#e7b448',85),text('HELA WEDDING FILM',50,98,10,tracking=25)],roles=['Nền decor tầng trên','Nền chi tiết trái','Nền chi tiết phải','Cô dâu trước gương','Ảnh nhóm tầng dưới'])
    add('Ceremony Bride · khung lớn','115910',[[.196,.142,.67,.716]],texts=[text('THE WEDDING PHOTOBOOK',50,12,17),text('Ceremony',36,67,46,'Allura',width=45),text('Bride',56,75,155,'Allura',width=65),text('06',54,84,25)]+footer())
    add('Wish You · đôi ảnh','115912',[[.036,.336,.469,.44],[.505,.336,.465,.44]],texts=[text('WISH YOU',9,32,11,'Cormorant Garamond',width=18),text('A HAPPY',50,32,11,'Cormorant Garamond',width=20),text('WEDDING',91,32,11,'Cormorant Garamond',width=18),text('HELA',50,87,25,'Cormorant Garamond','#171b1f'),text('W E D D I N G   F I L M',50,89,9,'Montserrat','#171b1f')],effects=dict(blur=12,wash=48))
    add('White Editorial · sáu ảnh','115913',[[.587,0,.316,.835],[.271,.404,.102,.114],[.271,.528,.316,.307],[.081,.665,.174,.17],[.081,.86,.42,.14],[.587,.86,.316,.14]],bg='white',wide=True,texts=[text('WEDDING FILM',43,3,11,'Montserrat','#151515',tracking=25),text('ALL FOR STARTING',22,25,17,'Montserrat','#222222',angle=90,width=25),text('12',24,38,100,'Cormorant Garamond','#bb8f7c',20),text('WISH YOU',17,65,12,'Cormorant Garamond','#222222',25),text('A HAPPY',32,39,12,'Cormorant Garamond','#222222',20)])
    add('Early Flowers · ảnh đơn','115917',[[.12,.255,.768,.535]],texts=[text('Early flowers',50,84,65,'Allura'),text('HAPPINESS OF THOSE WHO LOVE BEAUTY',50,87,11),text('H.ANH & H.NAM',50,91,50),text('THE WEDDING PHOTOBOOK',50,94,16)])
    add('Journey · chân dung nhóm ngang','115922',[[.567,0,.433,1],[.276,.103,.348,.795]],wide=True,texts=[text('HELA WEDDING FILM',45,5,13,tracking=24),text("Love’s journey",44,84,60,'Allura',width=38),text('WITH ALL YOUR TIME, MIND AND HEART',44,88,10,width=34)],effects=dict(brightness=78))
    add('Mother & Daughter · hai tầng','115923',[[0,0,1,.332],[0,.332,1,.668],[.033,.052,.47,.322],[.08,.517,.347,.237]],bg='white',texts=[text('HELA WEDDING FILM',74,32,12,tracking=22,width=44)])
    add('Forever Details · ba mảng','115941',[[.344,0,.656,1],[0,0,.344,1],[0,.183,.394,.50],[.423,.35,.577,.65]],bg='white',texts=[text('Forever',70,87,72,'Allura',width=50),text('WITH ALL YOUR TIME, MIND AND HEART',70,93,12,width=50),text('HELA WEDDING FILM',70,98,9,tracking=22,width=50)])
    add('Bride & Best Friends · ba ảnh','115953-1',[[0,0,1,.5],[.05,.618,.256,.287],[.36,.618,.272,.287],[.70,.618,.26,.287]],bg='blur',texts=[text('THE WEDDING PHOTOBOOK',50,57,16),text('Best Friends',50,61,26),text('Bride',50,83,100,'Allura',width=35)]+footer())
    add('Polaroid · ba ảnh','115953',[[.357,.158,.278,.181],[.043,.51,.486,.452],[.562,.557,.39,.363]],mats=[([.341,.148,.309,.23],'#ffffff',100)],texts=[text('HELA WEDDING FILM',50,9,12,'Montserrat','#111111',tracking=24),text('Forever',50,37,80,'Allura','#111111',45),text('WISH YOU',7,46,12,'Cormorant Garamond','#111111',14),text('A HAPPY',50,46,12,'Cormorant Garamond','#111111',18),text('WEDDING',93,46,12,'Cormorant Garamond','#111111',14)],effects=dict(blur=5,wash=42))
    add('Forever · khung trắng lệch trái','115955',[[.122,.304,.53,.593]],mats=[([.11,.175,.55,.825],'#ffffff',100)],texts=[text('HELA',38,23,38,'Cormorant Garamond','#111111',45),text('W E D D I N G   F I L M',38,25,11,'Montserrat','#111111',45),text('LOVE COMFORTETH LIKE SUNSHINE AFTER RAIN',38,94,13,'Montserrat','#111111',48),text('Forever',81,73,70,'Allura',width=32)],effects=dict(wash=18))
    add('Forever · hai trang','115955-1',[[0,0,.505,1],[.562,.071,.376,.827]],bg='white',wide=True,texts=[text('Forever',25,75,60,'Allura',width=35),text('WITH ALL YOUR TIME, MIND AND HEART',25,83,12,width=42),text('HELA WEDDING FILM',25,91,10,tracking=20,width=40)])
    add('Studio Editorial · lưới tám','115957',[[.233,.33,.184,.174],[.423,.33,.179,.174],[.606,.33,.18,.174],[.233,.506,.184,.174],[.606,.506,.18,.174],[.233,.684,.184,.174],[.423,.684,.179,.174],[.606,.684,.18,.174]],mats=[([.445,.546,.136,.10],'#b7c2b5',100)],texts=[text('HELA',50,19,150,'Cormorant Garamond','#20351c',70,weight=700),text('From Ha Noi',50,26,40,'Dancing Script','#20351c',50),text('Kim Tuyen & Ta Tung',50,28,14,'Cormorant Garamond','#20351c',60),text('Our story',51,59,44,'Allura','#20351c',15)],effects=dict(blur=10,wash=70,tone='warm',tone_strength=30))
    add('Storybook · một ảnh trên bảng xanh','120000',[[0,0,1,.52],[.502,.329,.422,.506]],mats=[([.471,.257,.486,.69],'#284330',100),([.341,.576,.13,.37],'#d6d6bf',55)],texts=[text('Storybook',15,73,55,'Allura',width=25),text('2026',31,73,19,width=15),text('( 2026 )',54,85,21,'Cormorant Garamond',width=20),text('LIFE BLOOMS IN ONE FRAME',78,85,16,'Cormorant Garamond',width=36)],effects=dict(tone='warm',tone_strength=15))
    add('Storybook · bốn khung lệch','120005',[[.312,.206,.186,.19],[.312,.417,.186,.191],[.554,.267,.346,.341],[.462,.608,.185,.192]],texts=[text('Storybook',22,22,65,'Allura','#141414',45),text('( 2026 )',12,36,23,'Cormorant Garamond','#111111',22),text('LIFE BLOOMS IN ONE FRAME',43,36,18,'Cormorant Garamond','#111111',45),text('Forever',19,66,60,'Allura','#111111',32),text('WITH ALL YOUR TIME, MIND AND HEART',23,72,11,'Montserrat','#111111',42)],effects=dict(wash=35))
    add('Fine Portrait · lề trắng','120007',[[.155,.095,.705,.823]],bg='white',texts=[text('HELA WEDDING FILM',70,52,13,tracking=25,width=32)])
    add('September · ba ảnh xếp lớp','120017',[[.153,.04,.237,.183],[.319,.164,.477,.507],[.125,.676,.24,.274]],mats=[([.132,.027,.105,.06],'#ffffff',35),([.105,.657,.13,.10],'#ffffff',40)],texts=[text('Sep\n2026',11,51,16,width=15),text('15  16  17  18  19',20,57,21,width=28),text('HELA',38,54,54,width=30),text('Wedding Film',38,56.5,12,width=25)],effects=dict(wash=30,blur=4))
    add('Wedding Grid · chín ảnh','120030',[[.136+c*.244,.099+rr*.272,.234,.264] for rr in range(3) for c in range(3)],bg='white',mono=[4],texts=[text('HELA WEDDING FILM',50,95,12,'Montserrat','#111111',80,tracking=25)])
    add('Storybook · một ảnh nền đỏ','120037',[[.214,.121,.226,.255],[.502,.343,.42,.491]],mats=[([.472,.257,.486,.69],'#61442b',100),([.341,.576,.13,.37],'#dad4cd',45),([.177,.343,.088,.064],'#dad4cd',45)],texts=[text('Storybook',15,73,55,'Allura',width=25),text('2026',31,73,19,width=15),text('( 2026 )',54,85,21,'Cormorant Garamond',width=20),text('LIFE BLOOMS IN ONE FRAME',78,85,16,'Cormorant Garamond',width=36)],effects=dict(brightness=58,tone='warm',tone_strength=65,vignette=22))
    add('Blue Magazine · ba ảnh','120039',[[.536,.055,.266,.223],[.536,.278,.266,.20],[.369,.536,.284,.211]],bg='blur',mats=[([.369,.298,.284,.45],'#ffffff',100)],texts=[text('Great love is like the sea',50,41,25,'Cormorant Garamond','#111111',30),text('HELA',28,65,100,'Cormorant Garamond',width=43),text('Wedding Film',37,68,28,'Cormorant Garamond',width=30),text('THE SOFTEST WHISPER, THE SWEETEST TIME',25,50,14,'Cormorant Garamond',width=22)],effects=dict(tone='cool',tone_strength=80,brightness=120))
    background_slots={'115906':[0,1,2],'115923':[0,1],'115941':[0,1],'115953-1':[0],'120000':[0]}
    for t in out:
        key=t['reference_file'].removeprefix('image(20261030-').removesuffix(').png')
        t['background_slots']=background_slots.get(key,[])
        if not t.get('slot_roles'):t['slot_roles']=['Ảnh '+str(i+1) for i in range(len(t['slots']))]
        for index in t['background_slots']:
            if not t['slot_roles'][index].startswith('Nền'):t['slot_roles'][index]='Nền · '+t['slot_roles'][index]
    return out

TEMPLATE_COUNT=35
