"""Native build preflight with real vision model weights, not an accuracy benchmark."""
def run():
    from PIL import Image
    from identity import Faces
    faces=Faces(print,True)
    features,count=faces.extract(Image.new('RGB',(320,320),'white'))
    assert count==0
    from ai_check import load_ai_libraries
    torch,tv=load_ai_libraries();torch.set_num_threads(min(4,torch.get_num_threads()))
    model=tv.models.detection.ssdlite320_mobilenet_v3_large(weights=tv.models.detection.SSDLite320_MobileNet_V3_Large_Weights.DEFAULT).eval()
    with torch.inference_mode():prediction=model([torch.zeros(3,320,320)])[0]
    assert 'scores' in prediction
    print('YuNet, SFace and person detector load/inference OK. Real wedding accuracy requires review.',flush=True)
if __name__=='__main__':run()
