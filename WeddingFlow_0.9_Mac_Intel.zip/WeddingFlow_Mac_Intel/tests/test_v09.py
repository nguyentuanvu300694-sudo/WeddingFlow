import os,unittest,tempfile
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from pathlib import Path
from datetime import date
from PIL import Image
import numpy as np
from PySide6.QtWidgets import QApplication,QListView
from PySide6.QtCore import Qt,QItemSelectionModel
from app import Window
from core import inspect_photo,render,TEMPLATES
from identity import match_identities
from calendar_typo import calendar_dates,apply_calendar
APP=QApplication.instance() or QApplication([])
class UpdateTests(unittest.TestCase):
    def test_grid_multiselect_and_responsive_preview(self):
        with tempfile.TemporaryDirectory() as td:
            photos=[]
            for i in range(4):
                p=Path(td)/f'{i}.png';Image.new('RGB',(300,400),(i*60,20,30)).save(p);photos.append(inspect_photo(p))
            w=Window();w.photos=photos;w.refresh_list();w.view_mode.setCurrentIndex(1)
            self.assertEqual(w.list.viewMode(),QListView.ViewMode.IconMode)
            index=next(i for i,t in enumerate(TEMPLATES) if len(t['slots'])==4);w.template.setCurrentIndex(index)
            w.list.clearSelection()
            for i in range(4):w.list.item(i).setSelected(True)
            w.use_current();self.assertEqual(w.paths,[p.path for p in photos]);self.assertEqual(len(w.crops),4)
            w.show();APP.processEvents();w.resize(1450,950);APP.processEvents();before=w.preview.pixmap().size()
            w.resize(1900,1250);APP.processEvents();after=w.preview.pixmap().size()
            self.assertGreater(after.width(),before.width());self.assertGreater(after.height(),before.height());w.close()
    def test_below_text_is_occluded_by_photo(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'red.png';Image.new('RGB',(100,100),'red').save(p)
            template=dict(slots=[[0,0,1,1]],background='white',mono=[])
            layer=dict(text='HELLO',x=50,y=50,size=100,font='Montserrat',color='#ffffff',width=100,z_order='below')
            config=dict(text_enabled=True,text_layers=[layer])
            result=render(template,[str(p)],300,300,typography=config)
            self.assertEqual(result.getpixel((150,150)),(255,0,0))
            layer['z_order']='above';above=render(template,[str(p)],300,300,typography=config)
            self.assertNotEqual(result.tobytes(),above.tobytes())
    def test_calendar_rolls_month_and_leap_year(self):
        self.assertEqual(calendar_dates('2024-03-02'),[date(2024,2,27),date(2024,2,28),date(2024,2,29),date(2024,3,1),date(2024,3,2)])
        im=Image.new('RGB',(600,900),'black');self.assertNotEqual(im.tobytes(),apply_calendar(im,dict(enabled=True,date='2024-03-02')).tobytes())
    def test_one_face_cannot_match_two_references(self):
        face=np.array([1.,0.]);scores,matches=match_identities([face],{'bride':[face],'groom':[np.array([.99,.01])]})
        self.assertFalse(matches)
        scores,matches=match_identities([face,np.array([0.,1.])],{'bride':[face],'groom':[np.array([0.,1.])]})
        self.assertEqual(matches,{'bride','groom'})
    def test_latest_all_templates_render(self):
        self.assertEqual(len(TEMPLATES),50)
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'sample.png';Image.new('RGB',(120,180),'#8f4e33').save(p)
            for t in TEMPLATES[35:]:
                image=render(t,[str(p)]*len(t['slots']),240,360,typography=dict(text_enabled=True,text_layers=t['text_layers'],calendar=t.get('calendar',{})))
                self.assertEqual(image.size,(240,360))
if __name__=='__main__':unittest.main()
