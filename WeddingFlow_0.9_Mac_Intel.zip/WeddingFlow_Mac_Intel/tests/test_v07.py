import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from PySide6.QtWidgets import QApplication
_QT_APP=QApplication.instance() or QApplication([])
from pathlib import Path
import tempfile,unittest
from PIL import Image,ImageDraw,ImageChops
from core import TEMPLATES,oriented_template,render,default_background,save_project,open_project
from photo_effects import effective_config,grade_background,paste_framed

class ReferenceLayoutTests(unittest.TestCase):
    def test_all_reference_layers_inside_canvas_in_both_directions(self):
        self.assertEqual(len(TEMPLATES[:15]),15)
        for t in TEMPLATES[:15]:
            for wide in (False,True):
                adjusted=oriented_template(t,wide)
                rects=adjusted['slots']+[v[0] for v in adjusted.get('mats',[])]+[v[0] for v in adjusted.get('background_panels',[])]
                for x,y,w,h in rects:
                    self.assertGreater(w,0);self.assertGreater(h,0);self.assertGreaterEqual(x,0);self.assertGreaterEqual(y,0)
                    self.assertLessEqual(x+w,1.000001);self.assertLessEqual(y+h,1.000001)
    def test_reference_render_and_export_both_orientations(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'photo.png';im=Image.new('RGB',(320,480),'#be4254');ImageDraw.Draw(im).ellipse((20,50,220,350),fill='#e7dcb2');im.save(p)
            for t in TEMPLATES[:15]:
                for wide in (False,True):
                    a=oriented_template(t,wide);size=(360,240) if wide else (240,360)
                    result=render(a,[str(p)]*len(a['slots']),*size)
                    self.assertEqual(result.size,size);self.assertEqual(result.mode,'RGB')
            out=render(oriented_template(TEMPLATES[13]),[str(p)]*3,1200,1800)
            out.save(Path(d)/'export.jpg',quality=95)
            with Image.open(Path(d)/'export.jpg') as exported:self.assertEqual(exported.size,(1200,1800))
    def test_auto_styles_do_not_leak_and_manual_overrides_persist(self):
        mono=effective_config(TEMPLATES[3],default_background());self.assertEqual(mono['tone'],'mono')
        natural=effective_config(TEMPLATES[0],mono);self.assertEqual(natural['tone'],'natural')
        manual=dict(default_background(),auto_style=False,tone='sepia',grain=32,corner=10,border=2)
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'project.json';save_project(p,[],{'background_config':manual});_,state=open_project(p)
            self.assertEqual(effective_config(TEMPLATES[3],state['background_config']),manual)
    def test_film_repeatable_and_disabled_is_identity(self):
        im=Image.new('RGB',(240,360),'#ce7a4e')
        c=dict(default_background(),auto_style=False,grain=50,scratches=50,vignette=30,effect_seed=42)
        a=grade_background(im,c);b=grade_background(im,c)
        self.assertIsNone(ImageChops.difference(a,b).getbbox())
        self.assertIsNotNone(ImageChops.difference(a,im).getbbox())
        self.assertIsNone(ImageChops.difference(grade_background(im,default_background()),im).getbbox())
    def test_foreground_color_is_not_graded_and_corners_reveal_background(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'red.png';Image.new('RGB',(200,200),'red').save(p)
            t=dict(slots=[[.2,.2,.6,.6]],background='blur',mono=[])
            c=dict(default_background(),auto_style=False,tone='mono',tone_strength=100,grain=70,scratches=60,corner=20,border=3)
            out=render(t,[str(p)],200,200,background_config=c)
            self.assertEqual(out.getpixel((100,100)),(255,0,0))
            self.assertNotEqual(out.getpixel((40,40)),(255,0,0))
    def test_frame_color_and_square_zero_corner(self):
        bg=Image.new('RGB',(200,200),'blue');fg=Image.new('RGB',(100,100),'red')
        paste_framed(bg,fg,(50,50),dict(corner=0,border=5,border_color='#00ff00'))
        self.assertEqual(bg.getpixel((50,50)),(0,255,0));self.assertEqual(bg.getpixel((100,100)),(255,0,0))

class EffectsDialogTests(unittest.TestCase):
    def test_live_dialog_manual_frame_and_film_persist_across_templates(self):
        from app import Window
        from PySide6.QtWidgets import QApplication,QSpinBox,QDoubleSpinBox
        from PySide6.QtCore import QTimer
        app=QApplication.instance() or QApplication([]);window=Window();errors=[]
        def edit():
            dialog=app.activeModalWidget()
            try:
                dialog.findChild(QDoubleSpinBox,'effect_corner').setValue(14.5)
                dialog.findChild(QDoubleSpinBox,'effect_border').setValue(2.5)
                dialog.findChild(QSpinBox,'effect_scratches').setValue(55)
            except Exception as e:errors.append(e)
            finally:
                if dialog:dialog.accept()
        try:
            window.template.setCurrentIndex(3)
            QTimer.singleShot(20,edit);window.choose_background()
            self.assertFalse(errors)
            self.assertEqual(window.bg_config['corner'],14.5);self.assertEqual(window.bg_config['scratches'],55)
            self.assertFalse(window.bg_config['auto_style'])
            window.template.setCurrentIndex(8)
            self.assertEqual(window.orientation.currentData(),'landscape')
            self.assertEqual(effective_config(window.output_template(),window.bg_config)['corner'],14.5)
            self.assertEqual(window.state()['background_config']['border'],2.5)
        finally:
            window.close();window.deleteLater();app.processEvents()
