import hashlib,io,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PIL import Image
from core import Photo,group_duplicates,save_project,open_project
from drive_source import import_album,resolve_export_sources,parse_folder_url,restore_previews,DriveClient,DriveError,cache_path

class FakeDrive:
    def __init__(self):self.previews=[];self.originals=[];self.metas=[dict(id=str(i),name=f'wedding{i}.jpg',mimeType='image/jpeg',version='4',md5Checksum=str(i)*32,imageMediaMetadata={'width':6000,'height':4000},thumbnailLink='https://lh3.googleusercontent.com/example') for i in range(1,4)]
    def metadata(self,id,key=''):
        if id=='folder':return {'id':id,'mimeType':'application/vnd.google-apps.folder'}
        return next(m for m in self.metas if m['id']==id)
    def iter_images(self,*args):return iter(self.metas)
    def preview(self,meta,dest):
        self.previews.append(meta['id']);Image.new('RGB',(200,300),'red').save(dest)
    def original(self,photo,dest):
        self.originals.append(photo.remote_id);Image.new('RGB',(1000,1500),'blue').save(dest)
    def save_credentials(self):pass

class DriveTests(unittest.TestCase):
    def test_url_and_resource_key(self):
        self.assertEqual(parse_folder_url('https://drive.google.com/drive/folders/abc-123?resourcekey=secret'),('abc-123','secret'))
        for bad in ['https://example.com/drive/folders/abc','http://drive.google.com/drive/folders/abc','https://drive.google.com/file/d/abc/view']:
            with self.assertRaises(DriveError):parse_folder_url(bad)
    def test_import_only_previews_and_checksum_semantics(self):
        with tempfile.TemporaryDirectory() as d:
            client=FakeDrive();photos,errors=import_album(client,'https://drive.google.com/drive/folders/folder',root=d)
            self.assertFalse(errors);self.assertEqual(len(photos),3);self.assertEqual(client.originals,[])
            self.assertEqual((photos[0].width,photos[0].height),(6000,4000));self.assertEqual(photos[0].remote_name,'wedding1.jpg')
            # Identical thumbnail bytes must not collapse distinct originals in exact mode.
            group_duplicates(photos,-1);self.assertTrue(all(p.keep for p in photos))
            import_album(client,'https://drive.google.com/drive/folders/folder',root=d)
            self.assertEqual(len(client.previews),3)
    def test_export_downloads_selected_only_once(self):
        with tempfile.TemporaryDirectory() as d:
            client=FakeDrive();photos,_=import_album(client,'https://drive.google.com/drive/folders/folder',root=d)
            for p in photos:p.remote_md5=''
            paths=[photos[0].path,photos[0].path];bg=photos[1].path
            result,background=resolve_export_sources(photos,paths,bg,client_factory=lambda:client,root=d)
            self.assertEqual(client.originals,['1','2']);self.assertEqual(result[0],result[1]);self.assertNotEqual(background,bg)
            resolve_export_sources(photos,paths,bg,client_factory=lambda:self.fail('Cached original should not reconnect'),root=d)
            self.assertEqual(client.originals,['1','2']);self.assertNotIn('3',client.originals)
    def test_preview_failure_does_not_download_original(self):
        with tempfile.TemporaryDirectory() as d:
            client=FakeDrive()
            def fail(meta,dest):raise DriveError('No preview')
            client.preview=fail;photos,errors=import_album(client,'https://drive.google.com/drive/folders/folder',root=d)
            self.assertFalse(photos);self.assertEqual(len(errors),3);self.assertFalse(client.originals)
    def test_restore_and_session_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            client=FakeDrive();photos,_=import_album(client,'https://drive.google.com/drive/folders/folder',root=d)
            project=Path(d)/'project.json';save_project(project,photos,{})
            loaded,_=open_project(project);self.assertEqual(loaded[0].remote_md5,photos[0].remote_md5)
            old=loaded[0].path;Path(old).unlink()
            mapping,errors=restore_previews(loaded,client_factory=lambda:client,root=d)
            self.assertFalse(errors);self.assertEqual(mapping[old],loaded[0].path);self.assertFalse(client.originals)
    def test_version_change_blocks_restore(self):
        with tempfile.TemporaryDirectory() as d:
            client=FakeDrive();photos,_=import_album(client,'https://drive.google.com/drive/folders/folder',root=d)
            Path(photos[0].path).unlink();client.metas[0]['version']='5'
            mapping,errors=restore_previews(photos,client_factory=lambda:client,root=d)
            self.assertFalse(mapping);self.assertEqual(len(errors),1);self.assertFalse(client.originals)

class Response:
    def __init__(self,data=None,content=b'',status=200):self.data=data;self.content=content;self.status_code=status
    def json(self):return self.data
    def close(self):pass
    def iter_content(self,size):yield self.content
class Session:
    def __init__(self,fn):self.fn=fn;self.calls=[]
    def get(self,url,**kwargs):self.calls.append((url,kwargs));return self.fn(url,kwargs)
class ApiTests(unittest.TestCase):
    def test_paginated_recursive_listing(self):
        def respond(url,k):
            p=k['params']
            if "'root'" in p['q'] and 'pageToken' not in p:return Response({'files':[{'id':'child','name':'sub','mimeType':'application/vnd.google-apps.folder'}],'nextPageToken':'two'})
            if "'root'" in p['q']:return Response({'files':[{'id':'a','name':'a.jpg','mimeType':'image/jpeg'}]})
            return Response({'files':[{'id':'b','name':'b.jpg','mimeType':'image/jpeg'}]})
        client=DriveClient(Session(respond));self.assertEqual([m['id'] for m in client.iter_images('root')],['a','b'])
    def test_untrusted_thumbnail_host_rejected(self):
        session=Session(lambda *args:self.fail('Do not send token to third-party host'))
        with self.assertRaises(DriveError):DriveClient(session).get('https://example.com/thumbnail')
        self.assertFalse(session.calls)
    def test_original_checksum_and_download_rights(self):
        buf=io.BytesIO();Image.new('RGB',(20,30),'red').save(buf,format='JPEG');body=buf.getvalue()
        meta={'id':'a','version':'1','size':str(len(body)),'md5Checksum':hashlib.md5(body).hexdigest(),'capabilities':{'canDownload':True}}
        session=Session(lambda url,k:Response(content=body) if k['params'].get('alt')=='media' else Response(meta))
        client=DriveClient(session)
        with tempfile.TemporaryDirectory() as d:
            p=Photo('',20,30,'','0',0,remote_id='a',remote_version='1',remote_name='a.jpg')
            out=Path(d)/'original.jpg';client.original(p,out);self.assertEqual(out.read_bytes(),body)
            meta['md5Checksum']='incorrect'
            with self.assertRaises(DriveError):client.original(p,Path(d)/'bad.jpg')
            self.assertFalse((Path(d)/'bad.jpg').exists());self.assertFalse((Path(d)/'bad.part').exists())
            meta['capabilities']['canDownload']=False
            with self.assertRaises(DriveError):client.original(p,Path(d)/'no.jpg')
if __name__=='__main__':unittest.main()
