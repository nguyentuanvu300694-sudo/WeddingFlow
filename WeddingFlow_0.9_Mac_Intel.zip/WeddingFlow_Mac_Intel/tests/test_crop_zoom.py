import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import unittest,tempfile,hashlib
from pathlib import Path
from PIL import Image,ImageDraw,ImageChops,ImageOps
from core import crop_geometry,crop_to_slot,normalize_crop,render,save_project,open_project
from PySide6.QtWidgets import QApplication
APP=QApplication.instance() or QApplication([])

class CropZoomTests(unittest.TestCase):
    def test_legacy_crop_matches_fit(self):
        im=Image.new('RGB',(300,200));ImageDraw.Draw(im).rectangle((140,0,299,199),fill='red')
        for center in ([0,0],[.5,.5],[1,1]):
            self.assertIsNone(ImageChops.difference(crop_to_slot(im,(100,150),center),ImageOps.fit(im,(100,150),method=Image.Resampling.LANCZOS,centering=tuple(center))).getbbox())
    def test_zoom_and_pan_select_expected_area(self):
        self.assertEqual(crop_geometry((400,200),(100,100),[1,0,2]),(300,0,400,100))
        im=Image.new('RGB',(400,200),'blue');ImageDraw.Draw(im).rectangle((300,0,399,99),fill='red')
        self.assertEqual(crop_to_slot(im,(100,100),[1,0,2]).getpixel((50,50)),(255,0,0))
        self.assertEqual(normalize_crop([.2,.8]),[.2,.8,1])
    def test_per_slot_zoom_export_and_project_roundtrip_original_untouched(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'photo.png';im=Image.new('RGB',(400,200),'blue');ImageDraw.Draw(im).rectangle((300,0,399,99),fill='red');im.save(p)
            before=hashlib.sha256(p.read_bytes()).digest();crops=[[1,0,2],[0,1,4]]
            save_project(Path(d)/'album.json',[],{'crops':crops});_,state=open_project(Path(d)/'album.json')
            t=dict(slots=[[0,0,.5,1],[.5,0,.5,1]],background='white',mono=[])
            for w,h in [(200,100),(800,400)]:
                result=render(t,[str(p)]*2,w,h,crops=state['crops'])
                self.assertEqual(result.getpixel((w//4,h//2)),(255,0,0));self.assertEqual(result.getpixel((3*w//4,h//2)),(0,0,255))
            self.assertEqual(hashlib.sha256(p.read_bytes()).digest(),before)
    def test_editor_pan_reset_and_independent_main_zoom(self):
        from crop_editor import CropEditor
        from app import Window
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'photo.png';Image.new('RGB',(400,200),'red').save(p)
            editor=CropEditor(str(p),1,[.5,.5,2]);editor.pan(30,0);self.assertLess(editor.values()[0],.5);editor.reset();self.assertEqual(editor.values(),[.5,.5,1]);editor.reject();editor.deleteLater()
            w=Window();w.paths=[str(p)]*2;w.crops=[[.5,.5,1],[.2,.8,2]];w.slot.clear();w.slot.addItems(['1','2']);w.slot.setCurrentIndex(1);w.slot_changed()
            self.assertEqual(w.zoom.value(),200);w.zoom.setValue(250);self.assertEqual(w.crops[1][2],2.5);self.assertEqual(w.crops[0][2],1)
            w.close();w.deleteLater();APP.processEvents()
