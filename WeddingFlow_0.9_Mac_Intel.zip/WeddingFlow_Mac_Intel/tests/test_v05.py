import sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PIL import Image
from core import render,default_background,background_uses_image,save_project,open_project
from love_art import ARTWORKS,make_stamp,apply_artwork,default_artwork
class ArtworkBackgroundTests(unittest.TestCase):
 def test_all_stamps_are_transparent(self):
  self.assertEqual(len(ARTWORKS),80)
  for i in range(len(ARTWORKS)):
   stamp=make_stamp(i);self.assertEqual(stamp.mode,'RGBA');self.assertIsNotNone(stamp.getbbox());self.assertEqual(stamp.getpixel((0,0))[3],0)
 def test_artwork_visibility_and_position(self):
  base=Image.new('RGB',(400,600),'white');c=default_artwork();c['y']=0
  top=apply_artwork(base,c);c['y']=100;bottom=apply_artwork(base,c)
  self.assertNotEqual(top.tobytes(),bottom.tobytes());self.assertNotEqual(top.tobytes(),base.tobytes())
  c['opacity']=0;self.assertEqual(apply_artwork(base,c).tobytes(),base.tobytes())
 def test_background_applies_to_white_cream_and_full_bleed(self):
  with tempfile.TemporaryDirectory() as d:
   fg=Path(d)/'fg.jpg';bg=Path(d)/'bg.png';Image.new('RGB',(100,150),'red').save(fg);Image.new('RGB',(100,150),'blue').save(bg)
   c=default_background();c.update(mode='custom',blur=0,brightness=100,wash=0,margin=10)
   for background in ['white','cream','blur']:
    t=dict(slots=[[0,0,1,1]],background=background,mono=[])
    out=render(t,[str(fg)],200,300,str(bg),background_config=c)
    self.assertEqual(out.getpixel((0,0)),(0,0,255));self.assertGreater(out.getpixel((100,150))[0],240)
 def test_background_unused_when_solid_or_white_template(self):
  c=default_background();t={'background':'white'}
  self.assertFalse(background_uses_image(t,c));c['mode']='solid';self.assertFalse(background_uses_image(t,c));c['mode']='custom';self.assertTrue(background_uses_image(t,c))
 def test_custom_background_requires_selected_photo(self):
  c=default_background();c['mode']='custom'
  with self.assertRaises(ValueError):render({'slots':[[0,0,1,1]],'background':'white','mono':[]},['missing.jpg'],200,300,background_config=c)
 def test_new_state_roundtrip(self):
  with tempfile.TemporaryDirectory() as d:
   path=Path(d)/'project.json';state={'typography':default_artwork(),'background_config':dict(default_background(),mode='custom',blur=42),'background':'chosen.jpg'}
   save_project(path,[],state);_,restored=open_project(path);self.assertEqual(restored,state)
if __name__=='__main__':unittest.main()
