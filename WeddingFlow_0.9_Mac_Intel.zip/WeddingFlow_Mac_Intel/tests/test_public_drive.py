import sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PIL import Image
from core import group_duplicates
from public_drive import import_public_album,public_records
from drive_source import resolve_export_sources,DriveError
class FakePublic:
 def __init__(self):self.previews=[];self.originals=[]
 def preview(self,id,dest):self.previews.append(id);Image.new('RGB',(300,400),'red').save(dest)
 def original(self,p,dest):self.originals.append(p.remote_id);Image.new('RGB',(600,800),'blue').save(dest)
 def save_credentials(self):pass
class PublicTests(unittest.TestCase):
 def records(self):return [SimpleNamespace(id='a',path='folder/a.jpg'),SimpleNamespace(id='b',path='folder/b.jpg')]
 def test_import_does_not_login_or_download_originals(self):
  with tempfile.TemporaryDirectory() as d:
   client=FakePublic()
   with patch('drive_source.DriveClient.connect',side_effect=AssertionError('No OAuth')):
    ps,errors=import_public_album('https://drive.google.com/drive/folders/folder',root=d,records=self.records(),client=client)
   self.assertFalse(errors);self.assertEqual(len(ps),2);self.assertFalse(client.originals)
   self.assertTrue(all(p.remote_mode=='public' for p in ps));self.assertEqual(ps[0].remote_name,'a.jpg')
   group_duplicates(ps,-1);self.assertTrue(all(p.keep for p in ps))
 def test_public_export_downloads_only_selected_and_refreshes(self):
  with tempfile.TemporaryDirectory() as d:
   client=FakePublic();ps,_=import_public_album('https://drive.google.com/drive/folders/folder',root=d,records=self.records(),client=client)
   paths=[ps[0].path,ps[0].path]
   with patch('drive_source.DriveClient.connect',side_effect=AssertionError('No OAuth')):
    result,_=resolve_export_sources(ps,paths,client_factory=lambda:client,root=d)
    self.assertEqual(result[0],result[1]);self.assertEqual(client.originals,['a'])
    resolve_export_sources(ps,paths,client_factory=lambda:client,root=d)
   self.assertEqual(client.originals,['a','a'])
 def test_listing_sets_skip_download_and_disables_cookies(self):
  with patch('gdown.download_folder',return_value=self.records()) as mock:
   self.assertEqual(len(public_records('https://drive.google.com/drive/folders/folder')),2)
   self.assertTrue(mock.call_args.kwargs['skip_download']);self.assertFalse(mock.call_args.kwargs['use_cookies'])
 def test_one_bad_preview_does_not_abort_others(self):
  class Partial(FakePublic):
   def preview(self,id,dest):
    if id=='a':raise DriveError('Preview unavailable')
    super().preview(id,dest)
  with tempfile.TemporaryDirectory() as d:
   client=Partial();ps,err=import_public_album('https://drive.google.com/drive/folders/folder',root=d,records=self.records(),client=client)
   self.assertEqual(len(ps),1);self.assertEqual(ps[0].remote_id,'b');self.assertEqual(len(err),1);self.assertFalse(client.originals)
if __name__=='__main__':unittest.main()
