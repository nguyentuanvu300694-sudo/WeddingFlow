import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import unittest
from threading import Event
from app import Job,Window
from PySide6.QtWidgets import QApplication

class ImportPauseTests(unittest.TestCase):
    def test_pause_preserves_worker_and_resumes(self):
        ready=Event();advance=Event();passed=Event()
        def task(progress):
            ready.set();advance.wait(2);progress('next photo');passed.set()
        job=Job(task);job.start()
        try:
            self.assertTrue(ready.wait(2))
            self.assertTrue(job.toggle_pause());advance.set()
            self.assertFalse(passed.wait(.1))
            self.assertFalse(job.toggle_pause())
            self.assertTrue(passed.wait(2))
        finally:
            job.gate.set();advance.set();job.wait(3000)
    def test_pause_button_remains_enabled_during_import(self):
        app=QApplication.instance() or QApplication([])
        window=Window();gate=Event()
        window.run_job(lambda progress:gate.wait(2),lambda result:None,pausable=True)
        try:
            self.assertTrue(window.pause_import.isEnabled())
            self.assertFalse(window.content_split.isEnabled())
            window.toggle_import_pause()
            self.assertEqual(window.pause_import.text(),'Tiếp tục nhập ảnh')
            window.toggle_import_pause()
        finally:
            gate.set();window.job.gate.set();window.job.wait(3000);app.processEvents();window.close()
