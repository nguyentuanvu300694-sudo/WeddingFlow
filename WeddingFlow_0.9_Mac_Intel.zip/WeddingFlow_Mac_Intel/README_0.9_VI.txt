WeddingFlow 0.9 – 50 layout theo ảnh tham khảo

Các ZIP này là mã nguồn + công cụ build, không phải DMG/EXE đã tạo sẵn.
Upload 3 ZIP vào repository, thay toàn bộ .github/workflows/build-windows.yml
bằng GITHUB_BUILD_ALL.yml có trong ZIP, commit rồi tải kết quả ở Actions > Artifacts.
Workflow chỉ đọc ZIP phiên bản 0.9; ZIP 0.9 có thể giữ lại trong repo.

1. Danh sách / lưới: menu bên trái. Cmd (Mac) / Ctrl (Windows) chọn nhiều,
Shift chọn dãy. Chọn đủ số ô rồi bấm Đưa các ảnh đã chọn vào layout.
Ảnh được điền theo thứ tự hiển thị, không theo thứ tự bấm. Không tự bỏ ảnh thừa.
Nếu layout đã có ảnh, chọn ít ảnh hơn để thay liên tiếp từ ô đang chọn.
2. Preview tự vừa vùng hiển thị khi kéo cửa sổ hoặc thanh chia cột.
Các công cụ chỉnh sửa dưới preview có thể cuộn.
3. Màu theo mẫu / giữ màu / đen trắng cho từng ô. Không thay đổi ảnh gốc.
4. TEXT & FONT: thứ tự lớp riêng từng text. Typo PNG có menu trên/dưới ảnh.
Dưới ảnh nghĩa là sau các ô ảnh chính nhưng trên nền. Bị ảnh che thì chữ khuất.
5. Typo lịch: ngày/tháng/năm thật, tự xử lý qua tháng/năm nhuận; 5 ngày kết thúc
ở ngày cưới, khoanh ngày cưới. Đổi font/màu/kích thước/vị trí/độ rõ/thứ tự lớp.
Mẫu 40 và 45 dùng lịch mặc định, có thể chỉnh lại theo ngày thật.
6. Nền: mờ, giảm sáng, film grain/xước/bụi, flare và vị trí flare, tối góc.
Tắt tự phối theo mẫu để giữ tùy chỉnh. Hiệu ứng nền tách khỏi ảnh chính.
7. Phân loại AI: tải OpenCLIP, YuNet, SFace (khi có ảnh tham chiếu) và bộ phát
hiện người trong lần đầu; sau đó xử lý ảnh trên máy. Không upload ảnh lên API.
Ảnh decor phải được phân loại decor và vượt kiểm tra không phát hiện người.
Đây là đề xuất, không đảm bảo tuyệt đối, nhất là người rất nhỏ/che khuất.
Không tự huấn luyện mô hình từ các ảnh layout.
8. Ảnh tham chiếu cô dâu/chú rể: mỗi ảnh phải có đúng 1 khuôn mặt rõ, đủ lớn;
có thể thêm vài góc. Bấm phân loại lại để áp dụng. Dùng bộ lọc Có cô dâu,
Có chú rể, Có cả hai, Cần kiểm tra. Góc khuất/ảnh xa dễ không nhận được.
Chỉ dùng nhãn đề xuất sau khi tự kiểm tra. Không dùng nhận diện để tự xóa ảnh.
Ảnh tham chiếu lưu kèm trong JSON dự án; chia sẻ JSON cũng chia sẻ ảnh đó.
9. Mô hình nhận diện: OpenCV Zoo YuNet/SFace. Mô hình người: torchvision
SSDLite320 MobileNet V3 pretrained. Model weights được tải từ nguồn gốc khi dùng.
Mã tích hợp xem identity.py; giấy phép mô hình theo OpenCV Zoo và torchvision.

Kiểm tra tại môi trường phát triển: unit/integration + GUI smoke trên Linux.
Không kiểm tra độ chính xác nhận diện trên album cưới thật tại đây.
Mỗi build GitHub còn chạy kiểm tra native AI, vision models, unit tests,
PyInstaller và executable --self-test; chỉ upload nếu các bước đều thành công.
Mac app ký ad-hoc, chưa notarize nếu không có chứng chỉ Developer ID.
