"""Offline AI preflight: load real native operators and exercise CLIP without downloading weights."""
def load_ai_libraries():
    import importlib.util
    from pathlib import Path
    import torch
    # torchvision normally suppresses the underlying dlopen error. Expose it
    # before importing torchvision so missing binaries/rpaths are diagnosable.
    spec=importlib.util.find_spec('torchvision')
    if spec is None or not spec.submodule_search_locations:
        raise RuntimeError('Missing torchvision package in AI build.')
    folder=Path(next(iter(spec.submodule_search_locations)))
    candidates=sorted(folder.glob('_C*.so'))+sorted(folder.glob('_C*.pyd'))
    if not candidates:raise RuntimeError('Missing torchvision native extension in '+str(folder))
    try:torch.ops.load_library(str(candidates[0]))
    except Exception as exc:
        raise RuntimeError('Cannot load torchvision native extension '+str(candidates[0])+': '+str(exc)) from exc
    import torchvision
    return torch,torchvision

def check_ai():
    torch,torchvision=load_ai_libraries()
    from torchvision.ops import nms
    boxes=torch.tensor([[0.,0.,10.,10.],[0.,0.,10.,10.]],dtype=torch.float32)
    kept=nms(boxes,torch.tensor([.9,.8]),.5)
    if kept.tolist()!=[0]:raise RuntimeError('torchvision NMS self-test failed.')
    import open_clip
    from PIL import Image
    # Random weights test the inference path, not classification accuracy.
    previous_threads=torch.get_num_threads()
    try:
        torch.set_num_threads(min(4,previous_threads))
        model,_,preprocess=open_clip.create_model_and_transforms('ViT-B-32',pretrained=None,device='cpu')
        model.eval();tokens=open_clip.get_tokenizer('ViT-B-32')(['a wedding photo'])
        with torch.inference_mode():
            image_features=model.encode_image(preprocess(Image.new('RGB',(224,224),'white')).unsqueeze(0))
            text_features=model.encode_text(tokens)
        if image_features.shape!=text_features.shape or not torch.isfinite(image_features).all() or not torch.isfinite(text_features).all():
            raise RuntimeError('OpenCLIP inference self-test failed.')
    finally:torch.set_num_threads(previous_threads)
    return 'AI offline check OK: torch '+torch.__version__+' / torchvision '+torchvision.__version__

if __name__=='__main__':print(check_ai(),flush=True)
