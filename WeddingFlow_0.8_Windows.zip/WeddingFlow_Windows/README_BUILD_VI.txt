WeddingFlow 0.8 — Windows x64
ĐÂY LÀ GÓI MÃ NGUỒN VÀ SCRIPT BUILD, CHƯA PHẢI FILE CÀI ĐẶT.
1. Upload cả 3 ZIP WeddingFlow_0.8_Mac_M.zip, WeddingFlow_0.8_Mac_Intel.zip, WeddingFlow_0.8_Windows.zip lên thư mục gốc repo GitHub, không giải nén.
2. Thay nội dung .github/workflows/build-windows.yml bằng GITHUB_BUILD_ALL.yml trong gói bất kỳ.
3. Commit vào main. Vào Actions; có 3 job độc lập. Tải 3 artifact khi các job xanh.
4. Giải nén artifact để lấy DMG chip M, DMG Intel và EXE Windows. Đăng vào Releases nếu muốn chia sẻ.
Build tại máy: Mac đúng chip chạy Build_Release_Mac.command; Windows x64 chạy Build_Release_Windows.bat.
Bản Mac yêu cầu macOS 14 trở lên, được ký ad-hoc; chưa notarize nếu không cung cấp chứng chỉ Developer ID.
