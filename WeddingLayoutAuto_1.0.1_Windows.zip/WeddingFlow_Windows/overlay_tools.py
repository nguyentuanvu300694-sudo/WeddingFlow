"""Overlay geometry shared by interactive preview and drag position updates."""
def overlay_config(config,key):
    if not key:return None
    kind,index=key.split(':');index=int(index)
    if kind=='text':
        layers=config.get('text_layers',[])
        return layers[index] if 0<=index<len(layers) else None
    if kind=='art':return config
    if kind=='calendar':return config.get('calendar')
    return None

def artwork_size(config,size):
    from love_art import config_stamp
    stamp=config_stamp(config);w,h=size
    target=max(1,round(w*max(20,min(95,int(config.get('width',76))))/100))
    scale=min(target/stamp.width,h*.45/stamp.height)
    return max(1,round(stamp.width*scale)),max(1,round(stamp.height*scale))

def overlay_descriptors(config,size):
    from editable_text import text_plate
    w,h=size;result=[]
    def add(key,title,box,c):result.append(dict(key=key,title=title,box=box,plane=c.get('z_order','above')))
    if config.get('enabled'):
        sw,sh=artwork_size(config,size);x=round((w-sw)*config.get('x',50)/100);y=round((h-sh)*config.get('y',96)/100)
        add('art:0','Chữ nghệ thuật / PNG',(x,y,sw,sh),config)
    c=config.get('calendar',{})
    if c.get('enabled'):
        scale=min(w,h)*float(c.get('size',100))/100;sw,sh=max(1,round(scale*.58)),max(1,round(scale*.25))
        add('calendar:0','Lịch ngày cưới',(w*c.get('x',25)/100-sw/2,h*c.get('y',20)/100-sh/2,sw,sh),c)
    if config.get('text_enabled'):
        for i,layer in enumerate(config.get('text_layers',[])):
            if not layer.get('visible',True) or not layer.get('text','').strip():continue
            sw,sh=text_plate(layer,size).size
            add('text:'+str(i),layer['text'].replace('\n',' ')[:28],(w*layer.get('x',50)/100-sw/2,h*layer.get('y',50)/100-sh/2,sw,sh),layer)
    result.sort(key=lambda item:item['plane']=='above')
    return result

def move_config_overlay(config,key,dx,dy,size):
    c=overlay_config(config,key)
    if c is None:return
    w,h=size;kind=key.split(':')[0]
    if kind=='art':
        sw,sh=artwork_size(config,size);dx=dx*w/max(1,w-sw);dy=dy*h/max(1,h-sh)
    c['x']=max(0,min(100,float(c.get('x',50))+dx*100))
    c['y']=max(0,min(100,float(c.get('y',96 if kind=='art' else 50))+dy*100))
    if kind=='text':config['auto_text']=False
