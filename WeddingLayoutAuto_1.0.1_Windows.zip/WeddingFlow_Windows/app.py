from __future__ import annotations
import os,sys,json,traceback
from copy import deepcopy
from threading import Event
if "--self-test" in sys.argv:os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
from pathlib import Path
from PIL.ImageQt import ImageQt
from PySide6.QtCore import Qt,QThread,Signal,QSize,QUrl,QTimer,QRectF
from PySide6.QtGui import QPixmap,QIcon,QColor,QDesktopServices,QPainter,QPen
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QHBoxLayout,QVBoxLayout,QGridLayout,QPushButton,QLabel,QComboBox,QListWidget,QListWidgetItem,QFileDialog,QMessageBox,QCheckBox,QSlider,QSpinBox,QInputDialog,QSplitter,QScrollArea,QGroupBox,QDialog,QLineEdit,QFormLayout,QColorDialog,QDoubleSpinBox,QAbstractItemView,QListView,QSizePolicy)
from core import *
from photo_effects import TONES,effective_config
from typography import default_typography
from love_art import default_artwork,ARTWORKS,make_stamp,custom_png_data,config_stamp

class Job(QThread):
    progress=Signal(str); result=Signal(object); failed=Signal(str)
    def __init__(self,fn):
        super().__init__();self.fn=fn;self.gate=Event();self.gate.set();self.paused=False;self.last_progress='Đang nhập ảnh…'
    def checkpoint(self):self.gate.wait()
    def report(self,message):
        self.checkpoint();self.last_progress=message;self.progress.emit(message)
    def toggle_pause(self):
        self.paused=not self.paused
        if self.paused:self.gate.clear()
        else:self.gate.set()
        return self.paused
    def run(self):
        try:self.result.emit(self.fn(self.report))
        except Exception:self.failed.emit(traceback.format_exc())

class FitPreview(QLabel):
    overlayMoved=Signal(object,float,float)
    overlaySelected=Signal(object)
    def __init__(self,*args):
        super().__init__(*args);self.source=None;self.overlays=[];self.selected=None;self.drag_key=None;self.last_point=None
        self.setMouseTracking(True)
    def setSource(self,pix):
        self.source=pix;self.fit()
    def setText(self,text):
        self.source=None;self.overlays=[];super().setText(text)
    def fit(self):
        if self.source is not None:
            super().setPixmap(self.source.scaled(self.contentsRect().size(),Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
    def setOverlays(self,overlays,selected=None):
        self.overlays=overlays;self.selected=selected;self.update()
    def image_rect(self):
        if self.source is None:return QRectF()
        size=self.source.size().scaled(self.contentsRect().size(),Qt.AspectRatioMode.KeepAspectRatio)
        return QRectF((self.width()-size.width())/2,(self.height()-size.height())/2,size.width(),size.height())
    def normalized(self,point):
        rect=self.image_rect()
        if rect.isEmpty():return None
        return ((point.x()-rect.x())/rect.width(),(point.y()-rect.y())/rect.height())
    def hit(self,point):
        pos=self.normalized(point)
        if pos is None:return None
        x,y=pos[0]*self.source.width(),pos[1]*self.source.height()
        for item in reversed(self.overlays):
            bx,by,bw,bh=item['box']
            if bx<=x<=bx+bw and by<=y<=by+bh:return item['key']
        return None
    def mousePressEvent(self,event):
        if event.button()==Qt.MouseButton.LeftButton:
            key=self.hit(event.position())
            if key:
                self.selected=self.drag_key=key;self.last_point=self.normalized(event.position());self.overlaySelected.emit(key);self.setCursor(Qt.CursorShape.ClosedHandCursor);self.update();event.accept();return
        super().mousePressEvent(event)
    def mouseMoveEvent(self,event):
        if self.drag_key and self.last_point is not None:
            point=self.normalized(event.position())
            if point:
                dx,dy=point[0]-self.last_point[0],point[1]-self.last_point[1];self.last_point=point;self.overlayMoved.emit(self.drag_key,dx,dy)
            event.accept();return
        self.setCursor(Qt.CursorShape.OpenHandCursor if self.hit(event.position()) else Qt.CursorShape.ArrowCursor)
        super().mouseMoveEvent(event)
    def mouseReleaseEvent(self,event):
        self.drag_key=None;self.last_point=None;self.setCursor(Qt.CursorShape.ArrowCursor);super().mouseReleaseEvent(event)
    def paintEvent(self,event):
        super().paintEvent(event)
        if not self.source or not self.selected:return
        rect=self.image_rect();painter=QPainter(self);painter.setPen(QPen(QColor('#43dbaf'),1.5,Qt.PenStyle.DashLine))
        for item in self.overlays:
            if item['key']==self.selected:
                x,y,w,h=item['box'];painter.drawRect(QRectF(rect.x()+x/self.source.width()*rect.width(),rect.y()+y/self.source.height()*rect.height(),w/self.source.width()*rect.width(),h/self.source.height()*rect.height()))
        painter.end()
    def resizeEvent(self,event):
        super().resizeEvent(event);self.fit()

class Window(QMainWindow):
    def __init__(self):
        super().__init__();self.setWindowTitle('WEDDING LAYOUT AUTO - by NTV MEDIA from TNDP with love');self.resize(1450,950);self.setWindowIcon(QIcon(str(Path(__file__).resolve().parent/'app_icon.ico')))
        self.identity_refs={};self.mono_overrides={};self.photos=[];self.paths=[];self.crops=[];self.seed=0;self.bg=None;self.busy=False;self.job=None
        self.ty=dict(default_artwork(),enabled=False,text_enabled=True,auto_text=True,text_layers=[]);self.type_preview=None;self.background_preview=None;self.bg_config=default_background()
        self.setAcceptDrops(True)
        self.root=QWidget();self.setCentralWidget(self.root);outer=QVBoxLayout(self.root)
        top=QHBoxLayout();outer.addLayout(top)
        title=QLabel('WEDDING LAYOUT AUTO\nby NTV MEDIA from TNDP with love');title.setStyleSheet('font-size:16px;font-weight:700;color:#ded4b8');top.addWidget(title);top.addStretch()
        self.buttons=[]
        for name,fn in [('Mở ảnh trên máy',self.import_local),('Dán link Drive',self.import_drive),('Drive riêng tư',self.import_drive_advanced),('Mở dự án',self.load_session),('Lưu dự án',self.save_session)]:
            b=QPushButton(name);b.clicked.connect(fn)
            if fn==self.import_local:
                b.setText('MỞ ẢNH TRÊN MÁY');b.setStyleSheet('QPushButton {background:#bc2638;color:white;font-size:16px;font-weight:700;padding:12px;} QPushButton:hover {background:#dd3549;}')
            elif fn==self.import_drive:
                b.setText('DÁN LINK DRIVE');b.setStyleSheet('QPushButton {background:#1f844b;color:white;font-size:14px;font-weight:700;padding:12px;} QPushButton:hover {background:#289f5e;}')
            top.addWidget(b);self.buttons.append(b)
        self.content_split=split=QSplitter();outer.addWidget(split,1)
        left=QWidget();ll=QVBoxLayout(left);left.setMinimumWidth(275);split.addWidget(left)
        ll.addWidget(QLabel('01  ·  CHỌN & PHÂN LOẠI'))
        drop_note=QLabel('Kéo thả ảnh hoặc thư mục vào cửa sổ để thêm ảnh.\nCó thể thả nhiều ảnh / thư mục cùng lúc.');drop_note.setWordWrap(True);ll.addWidget(drop_note)
        self.ai=QPushButton('Phân loại bằng AI');self.ai.clicked.connect(self.classify);ll.addWidget(self.ai);self.buttons.append(self.ai)
        note=QLabel('AI chạy trên máy sau lần tải mô hình đầu tiên.\nNhãn là đề xuất; bạn có thể sửa bên dưới.');note.setWordWrap(True);ll.addWidget(note)
        ll.addWidget(QLabel('Độ nhạy gom ảnh giống (0 = chỉ trùng tệp)'))
        self.sensitivity=QSpinBox();self.sensitivity.setRange(0,16);self.sensitivity.setValue(7);ll.addWidget(self.sensitivity)
        b=QPushButton('Gom ảnh giống & đề xuất giữ');b.clicked.connect(self.duplicates);ll.addWidget(b);self.buttons.append(b)
        self.filter=QComboBox();self.filter.addItems(['Tất cả ảnh']+LABELS);self.filter.currentIndexChanged.connect(self.refresh_list);ll.addWidget(self.filter)
        self.only_dupes=QCheckBox('Chỉ xem nhóm ảnh giống');self.only_dupes.toggled.connect(self.refresh_list);ll.addWidget(self.only_dupes)
        self.view_mode=QComboBox();self.view_mode.addItems(['Danh sách ảnh','Lưới ảnh']);self.view_mode.currentIndexChanged.connect(self.change_view_mode);ll.addWidget(self.view_mode)
        self.identity_button=QPushButton('Ảnh tham chiếu cô dâu / chú rể');self.identity_button.clicked.connect(self.edit_identity);ll.addWidget(self.identity_button)
        self.list=QListWidget();self.list.setAcceptDrops(False);self.list.viewport().setAcceptDrops(False);self.list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection);self.list.setIconSize(QSize(100,100));self.list.currentItemChanged.connect(self.show_photo);ll.addWidget(self.list,1)
        selection_note=QLabel('⌘ Cmd / Ctrl: chọn nhiều · Shift: chọn dãy\nẢnh vào ô theo thứ tự hiển thị.');selection_note.setWordWrap(True);ll.addWidget(selection_note)
        center=QWidget();cl=QVBoxLayout(center);split.addWidget(center)
        cl.addWidget(QLabel('02  ·  DUYỆT ẢNH'))
        self.image=QLabel('Chọn thư mục ảnh để bắt đầu');self.image.setAlignment(Qt.AlignmentFlag.AlignCenter);self.image.setMinimumSize(300,250);cl.addWidget(self.image,1)
        self.info=QLabel('');self.info.setWordWrap(True);cl.addWidget(self.info)
        self.keep=QCheckBox('Giữ ảnh này để tạo layout');self.keep.toggled.connect(self.keep_changed);cl.addWidget(self.keep)
        self.checks=[];group=QGroupBox('Sửa nhãn của ảnh đang chọn');gl=QGridLayout(group)
        for i,label in enumerate(LABELS):
            c=QCheckBox(label);c.toggled.connect(self.labels_changed);gl.addWidget(c,i//3,i%3);self.checks.append(c)
        cl.addWidget(group)
        self.use=QPushButton('Đưa các ảnh đã chọn vào layout');self.use.clicked.connect(self.use_current);cl.addWidget(self.use)
        right=QWidget();rl=QVBoxLayout(right);right.setMinimumWidth(370);split.addWidget(right)
        rl.addWidget(QLabel('03  ·  TẠO LAYOUT'))
        orientation_row=QHBoxLayout();orientation_row.addWidget(QLabel('Hướng ảnh kết quả'))
        self.orientation=QComboBox();self.orientation.addItem('Dọc','portrait');self.orientation.addItem('Ngang','landscape');self.orientation.addItem('Vuông / tùy chỉnh','custom');orientation_row.addWidget(self.orientation);rl.addLayout(orientation_row)
        self.orientation.currentIndexChanged.connect(self.orientation_changed)
        self.template=QComboBox();self.template.addItems([t['name'] for t in TEMPLATES]);
        for i,t in enumerate(TEMPLATES):self.template.setItemData(i,t['reference_file'],Qt.ItemDataRole.ToolTipRole)
        self.template.currentIndexChanged.connect(self.template_changed);rl.addWidget(self.template)
        self.layout_label=QComboBox();self.layout_label.addItems(['Tất cả ảnh được giữ']+LABELS);rl.addWidget(self.layout_label)
        self.generate=QPushButton('Tự chọn ảnh & tạo layout');self.generate.clicked.connect(self.generate_layout);rl.addWidget(self.generate);self.buttons.append(self.generate)
        self.preview=FitPreview(str(len(TEMPLATES))+' layout từ ảnh tham khảo');self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter);self.preview.setMinimumSize(240,180);self.preview.setSizePolicy(QSizePolicy.Policy.Ignored,QSizePolicy.Policy.Expanding);rl.addWidget(self.preview,1)
        # Compact two-column tools: all actions remain visible without an inner scroll.
        self.editor_panel=QWidget();rl.addWidget(self.editor_panel);grid=QGridLayout(self.editor_panel);grid.setContentsMargins(0,0,0,0);grid.setSpacing(5)
        self.text_button=QPushButton('Thêm TEXT & FONT');self.text_button.clicked.connect(self.edit_text_layers);grid.addWidget(self.text_button,0,0)
        self.type_button=QPushButton('Chữ nghệ thuật / PNG');self.type_button.clicked.connect(self.edit_typography);grid.addWidget(self.type_button,0,1)
        self.mono_choice=QComboBox();self.mono_choice.addItems(['Màu theo mẫu','Giữ màu','Đen trắng']);self.mono_choice.currentIndexChanged.connect(self.mono_changed);grid.addWidget(self.mono_choice,1,0)
        calendar_button=QPushButton('Typo lịch ngày cưới');calendar_button.clicked.connect(self.edit_calendar);grid.addWidget(calendar_button,1,1)
        self.layer_order=QComboBox();self.layer_order.addItems(['Typo PNG trên ảnh','Typo PNG dưới ảnh']);self.layer_order.currentIndexChanged.connect(self.png_order_changed);grid.addWidget(self.layer_order,2,0)
        self.slot=QComboBox();self.slot.currentIndexChanged.connect(self.slot_changed);grid.addWidget(self.slot,2,1)
        for column,(name,fn) in enumerate([('Thay ảnh từ máy',self.replace_slot),('Nền & viền ảnh',self.choose_background)]):
            b=QPushButton(name);b.clicked.connect(fn);grid.addWidget(b,3,column)
        self.overlay_picker=QComboBox();self.overlay_picker.addItem('Chọn chữ để kéo trên preview');self.overlay_picker.currentIndexChanged.connect(self.select_overlay);grid.addWidget(self.overlay_picker,4,0)
        color_button=QPushButton('Màu chữ · bảng màu đầy đủ');color_button.clicked.connect(self.quick_overlay_color);grid.addWidget(color_button,4,1)
        self.sliders=[]
        for column,text in enumerate(['Ngang','Dọc']):
            row=QHBoxLayout();row.addWidget(QLabel(text));slider=QSlider(Qt.Orientation.Horizontal);slider.setRange(0,100);slider.setValue(50);slider.valueChanged.connect(self.crop_changed);row.addWidget(slider);grid.addLayout(row,5,column);self.sliders.append(slider)
        zoom_row=QHBoxLayout();zoom_row.addWidget(QLabel('Zoom ảnh'))
        self.zoom=QSpinBox();self.zoom.setRange(100,400);self.zoom.setSuffix('%');self.zoom.setValue(100);self.zoom.valueChanged.connect(self.crop_changed);zoom_row.addWidget(self.zoom);grid.addLayout(zoom_row,6,0)
        crop_button=QPushButton('Crop / zoom ảnh…');crop_button.clicked.connect(self.edit_crop);grid.addWidget(crop_button,6,1)
        row=QHBoxLayout();grid.addLayout(row,7,0)
        self.outw=QSpinBox();self.outw.setRange(600,15000);self.outw.setValue(2400)
        self.outh=QSpinBox();self.outh.setRange(600,15000);self.outh.setValue(3600)
        self.outw.valueChanged.connect(self.output_size_changed);self.outh.valueChanged.connect(self.output_size_changed)
        row.addWidget(QLabel('px'));row.addWidget(self.outw);row.addWidget(QLabel('×'));row.addWidget(self.outh)
        self.export=QPushButton('Xuất JPG chất lượng cao');self.export.clicked.connect(self.export_image);grid.addWidget(self.export,7,1);self.buttons.append(self.export)
        self.preview.overlayMoved.connect(self.move_overlay);self.preview.overlaySelected.connect(self.preview_selected_overlay)
        self.drag_timer=QTimer(self);self.drag_timer.setSingleShot(True);self.drag_timer.setInterval(35);self.drag_timer.timeout.connect(self.redraw)
        self.selected_overlay=None
        self.pause_import=QPushButton('Tạm dừng nhập ảnh');self.pause_import.clicked.connect(self.toggle_import_pause);self.pause_import.hide();outer.addWidget(self.pause_import)
        self.status=QLabel('Sẵn sàng · Ảnh gốc được giữ nguyên');self.status.setWordWrap(True);outer.addWidget(self.status)
        split.setSizes([320,610,470]);self.template_changed()
    def sync_overlays(self,size):
        from overlay_tools import overlay_descriptors
        descriptors=overlay_descriptors(self.ty,size)
        self.preview.setOverlays(descriptors,self.selected_overlay)
        self.overlay_picker.blockSignals(True);self.overlay_picker.clear();self.overlay_picker.addItem('Chọn chữ để kéo',None)
        for item in descriptors:self.overlay_picker.addItem(item['title'],item['key'])
        selected=next((i for i in range(self.overlay_picker.count()) if self.overlay_picker.itemData(i)==self.selected_overlay),0)
        self.overlay_picker.setCurrentIndex(selected);self.overlay_picker.blockSignals(False)
    def select_overlay(self,index):
        self.selected_overlay=self.overlay_picker.currentData();self.preview.selected=self.selected_overlay;self.preview.update()
    def preview_selected_overlay(self,key):
        self.selected_overlay=key
        index=next((i for i in range(self.overlay_picker.count()) if self.overlay_picker.itemData(i)==key),0)
        self.overlay_picker.blockSignals(True);self.overlay_picker.setCurrentIndex(index);self.overlay_picker.blockSignals(False)
    def move_overlay(self,key,dx,dy):
        from overlay_tools import move_config_overlay
        move_config_overlay(self.ty,key,dx,dy,self.preview.source.size().toTuple())
        self.selected_overlay=key;self.drag_timer.start()
    def quick_overlay_color(self):
        from overlay_tools import overlay_config
        config=overlay_config(self.ty,self.selected_overlay)
        if config is None:
            QMessageBox.information(self,'Chọn chữ trước','Bấm vào chữ trên preview hoặc chọn lớp chữ trong danh sách cạnh nút màu.');return
        color=QColorDialog.getColor(QColor(config.get('color','#ffffff')),self,'Chọn màu chữ · đầy đủ RGB / HEX')
        if color.isValid():
            config['color']=color.name()
            if self.selected_overlay.split(':')[0]=='text':self.ty['auto_text']=False
            elif self.selected_overlay.split(':')[0]=='art' and self.ty.get('kind')=='custom_png':config['recolor_png']=True
            self.redraw()
    def auto_decor_background(self):
        candidates=[p for p in self.photos if p.keep and 'Decor / setup' in p.labels and p.people_state=='no_people']
        if self.bg is None and candidates:self.bg=max(candidates,key=lambda p:p.quality).path
    def change_view_mode(self,index):
        self.list.setViewMode(QListView.ViewMode.IconMode if index else QListView.ViewMode.ListMode)
        self.list.setResizeMode(QListView.ResizeMode.Adjust)
        self.list.setWrapping(bool(index));self.list.setWordWrap(True)
        self.list.setMovement(QListView.Movement.Static)
        self.list.setGridSize(QSize(145,180) if index else QSize())
        self.list.setIconSize(QSize(120,115) if index else QSize(100,100))
    def mono_changed(self,index):
        key=str(self.slot.currentIndex())
        if index==0:self.mono_overrides.pop(key,None)
        else:self.mono_overrides[key]=index==2
        self.redraw()
    def png_order_changed(self,index):
        self.ty['z_order']='below' if index else 'above';self.redraw()
    def edit_calendar(self):
        from calendar_typo import CalendarDialog
        dialog=CalendarDialog(self.ty.get('calendar',{}),self)
        if dialog.exec()==QDialog.DialogCode.Accepted:self.ty['calendar']=dialog.values();self.redraw()
    def edit_identity(self):
        from identity import ReferenceDialog
        dialog=ReferenceDialog(self.identity_refs,self)
        if dialog.exec()==QDialog.DialogCode.Accepted:
            self.identity_refs=dialog.values();self.status.setText('Đã lưu ảnh tham chiếu. Bấm Phân loại bằng AI để đối chiếu album.')
    def run_job(self,fn,done,pausable=False):
        if self.busy:return
        self.busy=True
        # Freeze project mutations while background workers own analysis state.
        self.content_split.setEnabled(False)
        for b in self.buttons:b.setEnabled(False)
        self.pause_import.setText('Tạm dừng nhập ảnh');self.pause_import.setVisible(pausable)
        self.job=Job(fn);self.job.progress.connect(self.show_job_progress)
        self.job.result.connect(done);self.job.failed.connect(self.failed);self.job.finished.connect(self.job_done);self.job.start()
    def show_job_progress(self,message):
        if self.job and self.job.paused:return
        self.status.setText(message)
    def toggle_import_pause(self):
        if not self.busy or not self.job:return
        paused=self.job.toggle_pause()
        self.pause_import.setText('Tiếp tục nhập ảnh' if paused else 'Tạm dừng nhập ảnh')
        self.status.setText('Đã yêu cầu tạm dừng · ảnh/lượt tải đang xử lý sẽ hoàn tất. Bấm Tiếp tục để nhập tiếp.' if paused else self.job.last_progress)
    def job_done(self):
        self.busy=False;self.content_split.setEnabled(True)
        for b in self.buttons:b.setEnabled(True)
        self.pause_import.hide()
    def failed(self,error):
        self.status.setText('Thao tác chưa hoàn tất')
        box=QMessageBox(self);box.setWindowTitle('WEDDING LAYOUT AUTO');box.setText(error.strip().splitlines()[-1] if error.strip() else 'Chưa hoàn tất thao tác. Hãy thử lại.');box.setDetailedText(error);box.exec()
    def closeEvent(self,event):
        if self.busy:
            QMessageBox.information(self,'Đang xử lý','Hãy tiếp tục nếu đang tạm dừng và đợi nhập ảnh hoàn tất trước khi đóng.');event.ignore()
        else:event.accept()
    def local_drop_paths(self,mime):
        if not mime.hasUrls():return []
        result=[]
        for url in mime.urls():
            if not url.isLocalFile():continue
            p=Path(url.toLocalFile())
            if p.is_dir() or (p.is_file() and p.suffix.lower() in EXTS):result.append(str(p))
        return result
    def dragEnterEvent(self,event):
        if not self.busy and self.local_drop_paths(event.mimeData()):event.acceptProposedAction()
        else:event.ignore()
    def dragMoveEvent(self,event):
        self.dragEnterEvent(event)
    def dropEvent(self,event):
        paths=self.local_drop_paths(event.mimeData())
        if self.busy or not paths:event.ignore();return
        event.acceptProposedAction();self.start_drop_import(paths)
    def start_drop_import(self,paths):
        self.run_job(lambda progress:import_paths(paths,progress),self.dropped_imported,pausable=True)
    def dropped_imported(self,result):
        photos,errors=result
        existing={str(Path(p.path).resolve()) for p in self.photos}
        added=[]
        for photo in photos:
            key=str(Path(photo.path).resolve())
            if key not in existing:added.append(photo);existing.add(key)
        self.photos.extend(added);self.refresh_list()
        self.status.setText(f'Đã thêm {len(added)} ảnh · bỏ qua {len(photos)-len(added)} đường dẫn đã có · {len(errors)} tệp lỗi. Layout hiện tại được giữ.')
        if errors:QMessageBox.warning(self,'Một số tệp không nhập được','\n'.join(errors[:20]))
    def import_local(self):
        folder=QFileDialog.getExistingDirectory(self,'Chọn thư mục ảnh (quét cả thư mục con)')
        if folder:self.start_scan(folder)
    def start_scan(self,folder):self.run_job(lambda progress:scan(folder,progress),self.scanned,pausable=True)
    def scanned(self,result):
        photos,errors=result
        if photos:self.photos=photos;self.paths=[];self.crops=[];self.bg=None;self.bg_config=default_background();self.refresh_list();self.redraw()
        remote=any(p.remote_id for p in photos)
        self.status.setText(f'Đã đọc {len(photos)} '+('ảnh xem trước Drive · chưa tải ảnh gốc' if remote else 'ảnh')+f' · {len(errors)} tệp không đọc được')
        if errors:QMessageBox.warning(self,'Một số ảnh không đọc được','\n'.join(errors[:20]))
    def drive_help(self):
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(__file__).resolve().parent/'GOOGLE_DRIVE_SETUP_VI.txt')))
    def import_drive(self):
        from public_drive import import_public_album
        from drive_source import parse_folder_url
        url,ok=QInputDialog.getText(self,'Dán link Google Drive','Thư mục cần có quyền “Bất kỳ ai có đường liên kết → Người xem”.\nChỉ tải preview; ảnh gốc chỉ tải khi xuất. Không cần OAuth JSON.')
        if not ok or not url:return
        try:parse_folder_url(url)
        except Exception as e:QMessageBox.warning(self,'Link chưa đúng',str(e));return
        self.run_job(lambda progress:import_public_album(url,progress),self.scanned,pausable=True)
    def import_drive_advanced(self):
        from drive_source import DriveClient,install_client,client_config,import_album,parse_folder_url
        options=['Mở album · chỉ ảnh xem trước','Thiết lập Google · chọn OAuth JSON','Khôi phục ảnh xem trước của dự án','Ngắt kết nối Google trên máy','Hướng dẫn kết nối Google']
        action,ok=QInputDialog.getItem(self,'Google Drive · ảnh xem trước','Không tải cả album gốc. Ảnh gốc chỉ tải khi xuất.\nQuyền chỉ đọc toàn bộ Drive; app chỉ duyệt thư mục bạn nhập. Cần OAuth JSON một lần.',options,0,False)
        if not ok:return
        if action==options[4]:self.drive_help();return
        if action==options[1]:
            path,_=QFileDialog.getOpenFileName(self,'Chọn OAuth JSON loại Desktop app','','Google OAuth (*.json)')
            if path:
                try:install_client(path);self.status.setText('Đã thiết lập Google. Bấm Google Drive → Mở album để đăng nhập.');QMessageBox.information(self,'Đã thiết lập','Bây giờ chọn Google Drive → Mở album. Google sẽ yêu cầu quyền chỉ đọc Drive.')
                except Exception:self.failed(traceback.format_exc())
            return
        if action==options[3]:
            try:DriveClient.disconnect();self.status.setText('Đã xóa phiên đăng nhập lưu trên máy. Bộ nhớ đệm ảnh vẫn còn; quyền Google có thể thu hồi tại tài khoản Google.')
            except Exception:self.failed(traceback.format_exc())
            return
        if action==options[2]:self.recover_drive_previews();return
        try:client_config()
        except Exception:
            QMessageBox.information(self,'Cần thiết lập Google một lần','Mở Google Drive → Hướng dẫn kết nối Google để tạo OAuth JSON loại Desktop app. Sau đó chọn Thiết lập Google. Không dùng lại cách tải gdown.');self.drive_help();return
        url,ok=QInputDialog.getText(self,'Nhập thư mục Google Drive','Dán link thư mục bạn có quyền xem. Không cần công khai.\nApp đọc ảnh xem trước trong cả thư mục con.')
        if not ok or not url:return
        try:parse_folder_url(url)
        except Exception as e:QMessageBox.warning(self,'Link chưa đúng',str(e));return
        def task(progress):return import_album(DriveClient.connect(progress),url,progress)
        self.run_job(task,self.scanned,pausable=True)
    def recover_drive_previews(self):
        from drive_source import restore_previews
        if not self.photos:return
        def task(progress):return restore_previews(self.photos,progress)
        def done(result):
            mapping,errors=result;self.paths=[mapping.get(p,p) for p in self.paths];self.bg=mapping.get(self.bg,self.bg)
            self.refresh_list();self.redraw();self.status.setText(f'Khôi phục {len(mapping)} ảnh xem trước · {len(errors)} lỗi')
            if errors:QMessageBox.warning(self,'Một số preview chưa khôi phục được','\n'.join(errors[:20]))
        self.run_job(task,done)
    def classify(self):
        if not self.photos:return
        if QMessageBox.question(self,'Phân loại AI','Lần đầu tải mô hình phân loại, phát hiện người và nhận diện mặt (hàng trăm MB). Ảnh được xử lý trên máy, không gửi lên API.\nTiếp tục?',QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No)!=QMessageBox.StandardButton.Yes:return
        def task(progress):
            result=Classifier(progress).apply(self.photos,progress)
            from identity import analyze_people
            return analyze_people(result,self.identity_refs,progress)
        self.run_job(task,self.classified)
    def classified(self,photos):
        self.photos=photos;self.refresh_list();self.status.setText('AI đã đề xuất nhãn. Duyệt và sửa trước khi tạo layout.')
    def duplicates(self):
        if not self.photos:return
        threshold=self.sensitivity.value()
        def task(progress):
            progress('Đang gom ảnh giống…')
            # threshold 0 explicitly means byte-identical files only.
            return group_duplicates(self.photos,threshold if threshold else -1)
        def done(photos):
            self.photos=photos;self.refresh_list();n=sum(not p.keep for p in photos)
            self.status.setText(f'Đề xuất bỏ {n} ảnh khỏi lựa chọn. Duyệt nhóm ảnh giống để đổi ảnh giữ lại; không xóa tệp.')
        self.run_job(task,done)
    def current(self):
        item=self.list.currentItem();return self.photos[item.data(Qt.ItemDataRole.UserRole)] if item and 0<=item.data(Qt.ItemDataRole.UserRole)<len(self.photos) else None
    def refresh_list(self,*args):
        prior=self.current();path=prior.path if prior else None
        self.list.blockSignals(True);self.list.clear();target=None
        label=self.filter.currentText() if self.filter.currentIndex()>0 else None
        indices=[i for i,p in enumerate(self.photos) if (not label or label in p.labels) and (not self.only_dupes.isChecked() or p.group>=0)]
        if self.only_dupes.isChecked():indices.sort(key=lambda i:(self.photos[i].group,not self.photos[i].keep))
        for i in indices:
            p=self.photos[i];prefix='✓ ' if p.keep else '○ '
            text=prefix+(p.remote_name or Path(p.path).name)+('\nNhóm giống '+str(p.group+1) if p.group>=0 else '')+'\n'+', '.join(p.labels)
            item=QListWidgetItem(text);item.setData(Qt.ItemDataRole.UserRole,i)
            try:item.setIcon(QIcon(QPixmap.fromImage(ImageQt(load_image(p.path,120)))))
            except Exception:pass
            self.list.addItem(item)
            if p.path==path:target=item
        self.list.blockSignals(False)
        if target:self.list.setCurrentItem(target)
        elif self.list.count():self.list.setCurrentRow(0)
        else:self.show_photo()
    def show_photo(self,*args):
        p=self.current()
        self.keep.blockSignals(True)
        for c in self.checks:c.blockSignals(True)
        if p:
            try:self.image.setPixmap(QPixmap.fromImage(ImageQt(load_image(p.path,900))).scaled(600,580,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
            except Exception:self.image.setText('Ảnh không còn ở đường dẫn đã lưu.')
            self.info.setText(f'{p.remote_name or Path(p.path).name} · {p.width} × {p.height} px'+(' (kích thước preview)' if p.remote_mode=='public' else '')+(' · Drive: đang xem preview, chưa tải gốc' if p.remote_id else '')+'\n'+('Nhóm ảnh giống '+str(p.group+1) if p.group>=0 else 'Chưa thuộc nhóm ảnh giống'))
            self.info.setText(self.info.text()+('\nDecor: đã kiểm tra không phát hiện người' if p.people_state=='no_people' else '')+('\nĐối chiếu mặt: '+', '.join(k+' '+format(v,'.2f') for k,v in p.identity_scores.items()) if p.identity_scores else ''))
            self.keep.setChecked(p.keep)
        else:self.image.clear();self.info.setText('');self.keep.setChecked(False)
        for c in self.checks:c.setChecked(bool(p and c.text() in p.labels));c.blockSignals(False)
        self.keep.blockSignals(False)
    def keep_changed(self,value):
        p=self.current()
        if p:p.keep=value;self.refresh_list()
    def labels_changed(self,*args):
        p=self.current()
        if p:p.labels=[c.text() for c in self.checks if c.isChecked()];self.refresh_list()
    def output_size_changed(self,*args):
        w,h=self.outw.value(),self.outh.value()
        mode='landscape' if w>h else 'portrait' if h>w else 'custom'
        self.orientation.blockSignals(True);self.orientation.setCurrentIndex(self.orientation.findData(mode));self.orientation.blockSignals(False)
        self.redraw()
    def orientation_changed(self,*args):
        mode=self.orientation.currentData();w,h=self.outw.value(),self.outh.value()
        if mode=='custom':w=h=min(w,h)
        else:
            short,long=sorted((w,h))
            if short==long:
                long=min(15000,round(short*1.5))
                if long==short:short=round(long/1.5)
            w,h=(long,short) if mode=='landscape' else (short,long)
        self.outw.blockSignals(True);self.outh.blockSignals(True);self.outw.setValue(w);self.outh.setValue(h);self.outw.blockSignals(False);self.outh.blockSignals(False)
        if self.ty.get('auto_text',True):self.ty['text_layers']=deepcopy(self.output_template().get('text_layers',[]))
        self.output_size_changed()
    def output_template(self):
        t=deepcopy(oriented_template(TEMPLATES[self.template.currentIndex()],self.outw.value()>self.outh.value()))
        t['mono']=[i for i in range(len(t['slots'])) if self.mono_overrides.get(str(i),i in t['mono'])]
        return t
    def template_changed(self,*args):
        self.paths=[];self.crops=[];self.mono_overrides={}
        native=TEMPLATES[self.template.currentIndex()].get('native_orientation')
        if native:self.orientation.setCurrentIndex(self.orientation.findData(native))
        t=TEMPLATES[self.template.currentIndex()]
        # Calendar is a manual overlay; changing layout never inserts a sample date.
        if self.ty.get('auto_text',True):self.ty.update(text_layers=deepcopy(self.output_template().get('text_layers',[])),text_enabled=True,auto_text=True)
        self.slot.clear();self.slot.addItems(['Ô '+str(i+1)+' · '+(t.get('slot_roles') or ['Ảnh']*len(t['slots']))[i] for i in range(len(t['slots']))]);self.redraw()
    def generate_layout(self):
        try:
            t=TEMPLATES[self.template.currentIndex()];label=self.layout_label.currentText() if self.layout_label.currentIndex()>0 else None
            chosen=pick_photos(self.photos,len(t['slots']),label,self.seed);self.seed+=1
            decor=[p for p in self.photos if p.keep and 'Decor / setup' in p.labels and getattr(p,'people_state','')=='no_people']
            if self.bg is None and decor:self.bg=max(decor,key=lambda p:p.quality).path
            self.paths=[p.path for p in chosen];self.crops=[[.5,.5,1] for _ in chosen];self.slot_changed();self.redraw()
        except Exception as e:QMessageBox.information(self,'Chưa đủ ảnh',str(e))
    def slot_changed(self,*args):
        i=self.slot.currentIndex()
        self.mono_choice.blockSignals(True);self.mono_choice.setCurrentIndex(0 if str(i) not in self.mono_overrides else (2 if self.mono_overrides[str(i)] else 1));self.mono_choice.blockSignals(False)
        if 0<=i<len(self.crops):
            self.crops[i]=normalize_crop(self.crops[i])
            for s,value in zip(self.sliders,self.crops[i]):s.blockSignals(True);s.setValue(round(value*100));s.blockSignals(False)
            self.zoom.blockSignals(True);self.zoom.setValue(round(self.crops[i][2]*100));self.zoom.blockSignals(False)
    def crop_changed(self,*args):
        i=self.slot.currentIndex()
        if 0<=i<len(self.crops):self.crops[i]=[s.value()/100 for s in self.sliders]+[self.zoom.value()/100];self.redraw()
    def edit_crop(self):
        i=self.slot.currentIndex()
        if self.busy:return
        if not 0<=i<len(self.paths):
            QMessageBox.information(self,'Chọn ảnh trước','Tạo layout rồi chọn ô ảnh cần crop.');return
        try:
            from crop_editor import CropEditor
            slot=self.output_template()['slots'][i];aspect=slot[2]*self.outw.value()/(slot[3]*self.outh.value())
            dialog=CropEditor(self.paths[i],aspect,self.crops[i],self)
            if dialog.exec()==QDialog.DialogCode.Accepted:self.crops[i]=dialog.values();self.slot_changed();self.redraw()
            dialog.deleteLater()
        except Exception:self.failed(traceback.format_exc())
    def set_slot(self,path):
        if not self.paths:
            QMessageBox.information(self,'Tạo bố cục trước','Bấm “Tự chọn ảnh & tạo layout” trước khi thay từng ô.');return
        i=self.slot.currentIndex()
        if i>=0:self.paths[i]=path;self.crops[i]=[.5,.5,1];self.slot_changed();self.redraw()
    def use_current(self):
        items=sorted(self.list.selectedItems(),key=self.list.row)
        selected=[self.photos[item.data(Qt.ItemDataRole.UserRole)].path for item in items]
        if not selected:return
        n=len(self.output_template()['slots'])
        if len(selected)>n:
            QMessageBox.information(self,'Quá số ô',f'Mẫu có {n} ô; đang chọn {len(selected)} ảnh. Hãy chọn tối đa {n} ảnh.');return
        if len(selected)==n:
            self.paths=selected;self.crops=[[.5,.5,1] for _ in selected]
        elif not self.paths:
            QMessageBox.information(self,'Chọn đủ ảnh',f'Chọn đủ {n} ảnh để tạo mẫu này. Đang chọn {len(selected)} ảnh.');return
        else:
            start=max(0,self.slot.currentIndex())
            if start+len(selected)>n:
                QMessageBox.information(self,'Không đủ ô còn lại','Chọn ô bắt đầu sớm hơn hoặc chọn ít ảnh hơn.');return
            for offset,path in enumerate(selected):self.paths[start+offset]=path;self.crops[start+offset]=[.5,.5,1]
        self.auto_decor_background();self.slot_changed();self.redraw();self.status.setText(f'Đã đưa {len(selected)} ảnh vào layout theo thứ tự hiển thị.')
    def replace_slot(self):
        path,_=QFileDialog.getOpenFileName(self,'Chọn ảnh cho ô hiện tại','','Images (*.jpg *.jpeg *.png *.tif *.tiff *.webp)')
        if path:self.set_slot(path)
    def choose_background(self):
        dialog=QDialog(self);dialog.setWindowTitle('Màu nền · film · bo góc và viền ảnh');dialog.resize(920,760)
        layout=QHBoxLayout(dialog);scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setMinimumWidth(430);layout.addWidget(scroll)
        panel=QWidget();form=QFormLayout(panel);scroll.setWidget(panel)
        auto=QCheckBox('Tự áp dụng hiệu ứng theo mẫu layout');auto.setChecked(self.bg_config.get('auto_style',True));form.addRow(auto)
        shuffle=QPushButton('Tự phối một kiểu nền khác');form.addRow(shuffle)
        mode=QComboBox();mode.addItems(['Theo nền của mẫu','Ảnh nền riêng do tôi chọn','Nền trơn']);mode.setCurrentIndex(['template','custom','solid'].index(self.bg_config.get('mode','template')));form.addRow('Kiểu nền',mode)
        current=QPushButton('Dùng ảnh đang duyệt (máy / Drive)');form.addRow(current)
        file=QPushButton('Chọn ảnh nền từ máy…');form.addRow(file)
        source=QLabel(Path(self.bg).name if self.bg else 'Nền của mẫu dùng ảnh ô đầu tiên');source.setWordWrap(True);form.addRow('Ảnh nền',source)
        tone=QComboBox()
        for name,value in TONES:tone.addItem(name,value)
        form.addRow('Phối màu nền',tone)
        controls={}
        labels=[('blur','Độ mờ nền',0,80),('brightness','Độ sáng nền %',20,180),('wash','Phủ trắng nền %',0,80),('tone_strength','Mức phối màu %',0,100),('saturation','Độ bão hòa nền %',0,200),('contrast','Tương phản nền %',20,180),('grain','Hạt film nền %',0,100),('scratches','Xước / bụi film nền %',0,100),('flare','Flare sáng nền %',0,100),('flare_x','Flare ngang %',0,100),('flare_y','Flare dọc %',0,100),('vignette','Tối góc nền %',0,100),('margin','Lề khi dùng nền riêng %',0,18),('x','Vị trí nền ngang',0,100),('y','Vị trí nền dọc',0,100),('corner','Bo góc ảnh chính %',0,50),('border','Độ dày viền ảnh %',0,12),('shadow','Bóng đổ ảnh chính %',0,100)]
        for key,label,low,high in labels:
            spin=QDoubleSpinBox() if key in ('corner','border') else QSpinBox()
            spin.setRange(low,high);spin.setObjectName('effect_'+key)
            if key in ('corner','border'):spin.setDecimals(1);spin.setSingleStep(.5)
            form.addRow(label,spin);controls[key]=spin
        border_color=QPushButton('Chọn màu viền…');form.addRow('Viền ảnh chính',border_color)
        solid=QComboBox()
        for label,value in [('Trắng','#ffffff'),('Kem','#faf8f4'),('Đen','#171b1f'),('Olive','#3b5345')]:solid.addItem(label,value)
        solid.setCurrentIndex(max(0,solid.findData(self.bg_config.get('color','#faf8f4'))));form.addRow('Màu nền trơn',solid)
        note=QLabel('Hiệu ứng màu, mờ và film chỉ áp dụng lên nền. Bo góc và viền áp dụng các ô ảnh chính.\nTắt Tự áp dụng để giữ chỉnh sửa khi đổi mẫu. Ảnh gốc không bị thay đổi.');note.setWordWrap(True);form.addRow(note)
        close=QPushButton('Xong');close.clicked.connect(dialog.accept);form.addRow(close)
        self.background_preview=QLabel('Tạo layout để xem hiệu ứng');self.background_preview.setAlignment(Qt.AlignmentFlag.AlignCenter);self.background_preview.setMinimumSize(320,450);layout.addWidget(self.background_preview)
        def populate():
            c=effective_config(self.output_template(),self.bg_config)
            tone.blockSignals(True);tone.setCurrentIndex(max(0,tone.findData(c.get('tone','natural'))));tone.blockSignals(False)
            for k,v in controls.items():v.blockSignals(True);v.setValue(c[k]);v.blockSignals(False)
        populate()
        def changed(*args):
            self.bg_config.update(auto_style=auto.isChecked(),mode=['template','custom','solid'][mode.currentIndex()],color=solid.currentData())
            if not auto.isChecked():self.bg_config.update(tone=tone.currentData(),**{k:v.value() for k,v in controls.items()})
            self.redraw()
        def manual(*args):
            auto.blockSignals(True);auto.setChecked(False);auto.blockSignals(False);changed()
        def auto_changed(*args):
            self.bg_config['auto_style']=auto.isChecked()
            if auto.isChecked():
                from photo_effects import effect_defaults
                self.bg_config.update(effect_defaults());self.bg_config.update(blur=20,brightness=100,wash=10);populate()
            changed()
        def shuffle_style():
            import random
            self.bg_config['effect_seed']=int(self.bg_config.get('effect_seed',7))+1
            rng=random.Random(self.bg_config['effect_seed'])
            auto.blockSignals(True);auto.setChecked(False);auto.blockSignals(False)
            tone.blockSignals(True);tone.setCurrentIndex(rng.randrange(len(TONES)));tone.blockSignals(False)
            values=dict(blur=rng.choice([0,10,20,35]),wash=rng.choice([0,8,18]),grain=rng.choice([0,12,25]),scratches=rng.choice([0,10,22]),vignette=rng.choice([0,12,25]),brightness=rng.choice([80,90,100,110]),tone_strength=rng.choice([45,70,100]))
            for k,v in values.items():controls[k].blockSignals(True);controls[k].setValue(v);controls[k].blockSignals(False)
            changed()
        def choose_border_color():
            color=QColorDialog.getColor(QColor(self.bg_config.get('border_color','#ffffff')),dialog,'Chọn màu viền')
            if color.isValid():self.bg_config['border_color']=color.name();manual()
        def update_source(path,name):
            try:load_image(path,64).close()
            except Exception as e:QMessageBox.warning(dialog,'Chưa đọc được ảnh nền',str(e));return
            self.bg=path;source.setText(name);mode.setCurrentIndex(1);changed()
        def choose_current():
            p=self.current()
            if p:update_source(p.path,p.remote_name or Path(p.path).name)
            else:QMessageBox.information(dialog,'Chọn ảnh trước','Chọn một ảnh trong danh sách bên trái hoặc chọn ảnh nền từ máy.')
        def choose_file():
            path,_=QFileDialog.getOpenFileName(dialog,'Chọn ảnh nền riêng','','Images (*.jpg *.jpeg *.png *.webp *.tif *.tiff)')
            if path:update_source(path,Path(path).name)
        current.clicked.connect(choose_current);file.clicked.connect(choose_file);shuffle.clicked.connect(shuffle_style);border_color.clicked.connect(choose_border_color)
        mode.currentIndexChanged.connect(changed);solid.currentIndexChanged.connect(changed);tone.currentIndexChanged.connect(manual);auto.toggled.connect(auto_changed)
        for control in controls.values():control.valueChanged.connect(manual)
        self.redraw();dialog.exec();self.background_preview=None;dialog.deleteLater()
    def redraw(self):
        if not self.paths:self.preview.setOverlays([]);self.preview.setText('Chọn chủ đề và bấm tạo layout\nMẫu hiện tại: '+str(len(TEMPLATES[self.template.currentIndex()]['slots']))+' ô');return
        try:
            scale=min(1600/self.outw.value(),1600/self.outh.value())
            pw,ph=round(self.outw.value()*scale),round(self.outh.value()*scale)
            im=render(self.output_template(),self.paths,pw,ph,self.bg,self.crops,self.ty,self.bg_config)
            pix=QPixmap.fromImage(ImageQt(im))
            self.preview.setSource(pix)
            self.sync_overlays((pw,ph))
            if self.type_preview is not None:self.type_preview.setPixmap(pix.scaled(300,450,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
            if self.background_preview is not None:self.background_preview.setPixmap(pix.scaled(300,450,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
        except Exception as e:self.preview.setText(str(e))
    def edit_text_layers(self):
        if self.busy:return
        from text_editor import TextEditor
        from typography import apply_typography
        def preview(config):
            scale=min(430/self.outw.value(),570/self.outh.value());w=max(1,round(self.outw.value()*scale));h=max(1,round(self.outh.value()*scale))
            if self.paths:return render(self.output_template(),self.paths,w,h,self.bg,self.crops,config,self.bg_config)
            return apply_typography(Image.new('RGB',(w,h),'#b5b4af'),config)
        dialog=TextEditor(self.ty,self.output_template().get('text_layers',[]),preview,self)
        if dialog.exec()==QDialog.DialogCode.Accepted:self.ty=deepcopy(dialog.config);self.redraw()
        dialog.deleteLater()
    def edit_typography(self):
        if self.ty.get('kind') not in ('artwork','custom_png'):self.ty=default_artwork()
        dialog=QDialog(self);dialog.setWindowTitle('Love & Wedding · chọn chữ nghệ thuật');dialog.resize(1080,680)
        layout=QHBoxLayout(dialog);gallery_panel=QWidget();gallery_layout=QVBoxLayout(gallery_panel);layout.addWidget(gallery_panel)
        source=QComboBox();source.addItems(['Mẫu Love & Wedding có sẵn','Typography PNG trên máy']);source.setCurrentIndex(1 if self.ty.get('kind')=='custom_png' else 0);gallery_layout.addWidget(source)
        choose_png=QPushButton('Chọn file typography PNG…');gallery_layout.addWidget(choose_png)
        png_name=QLabel(self.ty.get('png_name','Chưa chọn file PNG'));png_name.setWordWrap(True);gallery_layout.addWidget(png_name)
        category=QComboBox();category.addItems(['Tất cả phong cách','Original','Signature','Modern Editorial','Romantic Flourish','Magazine Collage']);gallery_layout.addWidget(category)
        gallery=QListWidget();gallery.setIconSize(QSize(240,80));gallery.setMinimumWidth(280);gallery_layout.addWidget(gallery)
        def filter_artworks(*args):
            for row,a in enumerate(ARTWORKS):gallery.item(row).setHidden(category.currentIndex()>0 and a['group']!=category.currentText())
            if gallery.currentItem() and gallery.currentItem().isHidden():
                for row in range(gallery.count()):
                    if not gallery.item(row).isHidden():gallery.setCurrentRow(row);break
        category.currentIndexChanged.connect(filter_artworks)
        for i,a in enumerate(ARTWORKS):
            stamp=make_stamp(i).copy();stamp.thumbnail((240,80));tile=Image.new('RGBA',(250,90),'#faf8f4');tile.alpha_composite(stamp,((250-stamp.width)//2,(90-stamp.height)//2))
            item=QListWidgetItem(a['title']);item.setIcon(QIcon(QPixmap.fromImage(ImageQt(tile))));item.setData(Qt.ItemDataRole.UserRole,i);gallery.addItem(item)
        panel=QWidget();form=QFormLayout(panel);layout.addWidget(panel)
        enabled=QCheckBox('Hiện chữ nghệ thuật');enabled.setChecked(self.ty.get('enabled',True));form.addRow(enabled)
        color=QComboBox()
        for name,value in [('Đen mực','#2c302c'),('Trắng','#ffffff'),('Champagne','#b99a5e'),('Đỏ rượu','#873a43'),('Olive','#3b5345'),('Đỏ','#e5243b'),('Xanh lá','#22a95c'),('Xanh dương','#246dff'),('Hồng','#ec8fb6'),('Tím','#9561d4'),('Vàng','#f3ce36'),('Cam','#ef8b35'),('Xám','#888888')]:color.addItem(name,value)
        chosen_color=self.ty.get('color','#2c302c')
        if color.findData(chosen_color)<0:color.addItem(chosen_color,chosen_color)
        color.setCurrentIndex(max(0,color.findData(chosen_color)));form.addRow('Màu chữ',color)
        full_color=QPushButton('Bảng màu đầy đủ · RGB / HEX…');form.addRow(full_color)
        controls={}
        for key,label,low,high in [('width','Độ rộng chữ %',20,95),('opacity','Độ rõ chữ %',10,100),('x','Vị trí ngang',0,100),('y','Vị trí dọc',0,100)]:
            spin=QSpinBox();spin.setRange(low,high);spin.setValue(self.ty.get(key,50));form.addRow(label,spin);controls[key]=spin
        positions=QComboBox();positions.addItems(['Chọn vị trí nhanh…','Trên','Giữa','Dưới']);form.addRow('Đặt nhanh',positions)
        note=QLabel('80 mẫu chữ tiếng Anh được phối sẵn.\nChọn mẫu rồi đặt lên ảnh; không cần gõ chữ hoặc chọn font.\nPNG nhập giữ nguyên màu và độ trong suốt.\nNên dùng PNG nền trong suốt; file được lưu kèm dự án.');note.setWordWrap(True);form.addRow(note)
        close=QPushButton('Xong');close.clicked.connect(dialog.accept);form.addRow(close)
        self.type_preview=QLabel('Chọn layout để xem chữ trên ảnh');self.type_preview.setMinimumSize(300,450);self.type_preview.setAlignment(Qt.AlignmentFlag.AlignCenter);layout.addWidget(self.type_preview)
        def changed(*args):
            row=gallery.currentItem().data(Qt.ItemDataRole.UserRole) if gallery.currentItem() else 0;self.ty.update(kind='custom_png' if source.currentIndex()==1 and self.ty.get('png_data') else 'artwork',enabled=enabled.isChecked(),preset=row,color=color.currentData(),**{k:v.value() for k,v in controls.items()});self.redraw()
            if not self.paths:
                stamp=config_stamp(self.ty);stamp.thumbnail((300,430));tile=Image.new('RGBA',(300,450),'#e9e4da');tile.alpha_composite(stamp,((300-stamp.width)//2,(450-stamp.height)//2));self.type_preview.setPixmap(QPixmap.fromImage(ImageQt(tile)))
        def choose_full_color():
            selected=QColorDialog.getColor(QColor(self.ty.get('color','#ffffff')),dialog,'Màu chữ nghệ thuật / PNG')
            if selected.isValid():
                if color.findData(selected.name())<0:color.addItem(selected.name(),selected.name())
                if source.currentIndex()==1:self.ty['recolor_png']=True
                color.setCurrentIndex(color.findData(selected.name()));changed()
        full_color.clicked.connect(choose_full_color)
        def choose_custom_png():
            path,_=QFileDialog.getOpenFileName(dialog,'Chọn typography PNG','','PNG (*.png *.PNG)')
            if not path:return
            try:data=custom_png_data(path)
            except Exception as e:QMessageBox.warning(dialog,'Không đọc được PNG',str(e));return
            self.ty.update(png_data=data,png_name=Path(path).name,recolor_png=False)
            png_name.setText(Path(path).name);source.setCurrentIndex(1);changed()
        def source_changed(*args):
            custom=source.currentIndex()==1
            gallery.setEnabled(not custom);category.setEnabled(not custom);color.setEnabled(not custom)
            changed()
        choose_png.clicked.connect(choose_custom_png);source.currentIndexChanged.connect(source_changed)
        def position_changed(i):
            if i>0:controls['x'].setValue(50);controls['y'].setValue([0,5,50,96][i])
        gallery.currentRowChanged.connect(changed);color.currentIndexChanged.connect(changed);enabled.toggled.connect(changed);positions.currentIndexChanged.connect(position_changed)
        for control in controls.values():control.valueChanged.connect(changed)
        gallery.setCurrentRow(int(self.ty.get('preset',0))%len(ARTWORKS));source_changed();dialog.exec();self.type_preview=None
    def export_image(self):
        if not self.paths:return
        path,_=QFileDialog.getSaveFileName(self,'Xuất ảnh layout','WEDDING LAYOUT AUTO.jpg','JPEG (*.jpg)')
        if not path:return
        if not path.lower().endswith(('.jpg','.jpeg')):path+='.jpg'
        path=str(Path(path).resolve())
        originals={str(Path(p.path).resolve()) for p in self.photos}|{str(Path(p).resolve()) for p in self.paths}
        if self.bg:originals.add(str(Path(self.bg).resolve()))
        if path in originals:QMessageBox.warning(self,'Bảo vệ ảnh gốc','Hãy chọn tên mới, không ghi đè ảnh gốc.');return
        t=self.output_template();paths=list(self.paths);crops=[c[:] for c in self.crops];bg=self.bg;w,h=self.outw.value(),self.outh.value();ty=dict(self.ty);bgconfig=dict(self.bg_config)
        if bgconfig.get('mode')=='custom' and not bg:
            QMessageBox.information(self,'Chọn ảnh nền trước','Mở Nền & viền ảnh và chọn ảnh nền trước khi xuất.');return
        if not background_uses_image(t,bgconfig):bg=None
        def task(progress):
            from drive_source import resolve_export_sources
            source_paths,source_bg=resolve_export_sources(self.photos,paths,bg,progress)
            sources={str(Path(p).resolve()) for p in source_paths+([source_bg] if source_bg else [])}
            if path in sources:raise ValueError('Hãy xuất ra tệp mới, không ghi đè ảnh gốc đã tải.')
            progress(f'Đang xuất {w} × {h} px từ ảnh gốc…');im=render(t,source_paths,w,h,source_bg,crops,ty,bgconfig);im.save(path,'JPEG',quality=96,subsampling=0,dpi=(300,300));return path
        self.run_job(task,lambda p:self.status.setText('Đã xuất: '+p))
    def state(self):return dict(template=self.template.currentIndex(),template_id=TEMPLATES[self.template.currentIndex()]['id'],paths=self.paths,crops=self.crops,background=self.bg,width=self.outw.value(),height=self.outh.value(),orientation=self.orientation.currentData(),typography=dict(self.ty),identity_refs=self.identity_refs,mono_overrides=self.mono_overrides,background_config=dict(self.bg_config))
    def save_session(self):
        path,_=QFileDialog.getSaveFileName(self,'Lưu dự án','album.weddingflow.json','WeddingFlow (*.json)')
        if path:
            try:save_project(path,self.photos,self.state());self.status.setText('Đã lưu dự án: '+path)
            except Exception:self.failed(traceback.format_exc())
    def load_session(self):
        path,_=QFileDialog.getOpenFileName(self,'Mở dự án','','WeddingFlow (*.json)')
        if not path:return
        try:
            photos,state=open_project(path);missing=[p.path for p in photos if not Path(p.path).is_file()]
            self.photos=photos;self.identity_refs=state.get('identity_refs',{})
            saved_id=state.get('template_id');legacy=int(state.get('template',0));index=next((i for i,t in enumerate(TEMPLATES) if t['id']==saved_id),None)
            if index is None:index=legacy-60 if not saved_id and 60<=legacy<75 else 0
            self.template.setCurrentIndex(index)
            self.mono_overrides=state.get('mono_overrides',{})
            self.ty=state.get('typography',dict(default_artwork(),enabled=False))
            self.layer_order.blockSignals(True);self.layer_order.setCurrentIndex(1 if self.ty.get('z_order')=='below' else 0);self.layer_order.blockSignals(False)
            self.bg_config=default_background();self.bg_config.update(state.get('background_config',{}))
            self.paths=state.get('paths',[]);saved_crops=state.get('crops',[]);self.crops=[normalize_crop(saved_crops[i] if i<len(saved_crops) else None) for i in range(len(self.paths))];self.bg=state.get('background')
            if len(self.paths)!=len(TEMPLATES[self.template.currentIndex()]['slots']):self.paths=[];self.crops=[]
            self.outw.setValue(state.get('width',2400));self.outh.setValue(state.get('height',3600));self.refresh_list();self.slot_changed();self.redraw()
            self.status.setText(f'Đã mở dự án · {len(missing)} đường dẫn ảnh thiếu. Với ảnh Drive: chọn Drive riêng tư → Khôi phục ảnh xem trước của dự án.')
        except Exception:self.failed(traceback.format_exc())

if __name__=='__main__':
    if '--self-test' in sys.argv:
        from packaged_smoke import run
        sys.exit(run(Window))
    app=QApplication(sys.argv);app.setApplicationName('WEDDING LAYOUT AUTO - by NTV MEDIA from TNDP with love');app.setStyle('Fusion')
    app.setStyleSheet('''QWidget { background:#171b1f; color:#e5e5e2; font-size:13px; } QPushButton { background:#303a40; padding:10px; border:1px solid #465158; border-radius:7px; } QPushButton:hover {background:#46575c;} QPushButton:disabled {color:#777;} QComboBox,QSpinBox {padding:8px;background:#252c31;} QListWidget {background:#1f252a;border:0;} QListWidget::item {padding:7px;} QListWidget::item:selected {background:#3d5356;} QGroupBox {margin-top:14px;padding-top:18px;border:1px solid #3a4347;} QLabel {background:transparent;} QCheckBox {padding:5px;}''')
    window=Window();window.show();sys.exit(app.exec())
