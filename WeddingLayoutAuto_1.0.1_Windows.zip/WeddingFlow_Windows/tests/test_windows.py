import os,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import drive_source
from windows_tools import check_platform
class WindowsCompatibilityTests(unittest.TestCase):
 def test_windows_cache_respects_localappdata(self):
  with tempfile.TemporaryDirectory() as d:
   with patch.object(drive_source.sys,'platform','win32'),patch.dict(os.environ,{'LOCALAPPDATA':d}):
    self.assertEqual(drive_source.app_dir(),Path(d)/'WeddingFlow')
 @unittest.skipIf(sys.platform=='win32','On Windows, building is permitted.')
 def test_refuses_to_claim_cross_platform_exe_build(self):
  with self.assertRaises(RuntimeError):check_platform()
if __name__=='__main__':unittest.main()
