import os,unittest,tempfile
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from pathlib import Path
from PIL import Image
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QMimeData,QUrl,QPointF,QPoint,Qt
from PySide6.QtGui import QDropEvent,QDragEnterEvent
from app import Window
from core import TEMPLATES,import_paths,inspect_photo
APP=QApplication.instance() or QApplication([])
class Version10Tests(unittest.TestCase):
    def test_all_templates_start_without_text_or_calendar(self):
        self.assertEqual(len(TEMPLATES),50)
        w=Window()
        for i in range(len(TEMPLATES)):
            w.template.setCurrentIndex(i)
            self.assertFalse(w.ty['text_layers']);self.assertFalse(w.ty.get('enabled'));self.assertFalse(w.ty.get('calendar',{}).get('enabled'))
        w.close()
    def test_mixed_folder_file_import_recursive_and_unique(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);nested=root/'nested';nested.mkdir()
            a=root/'a.jpg';b=nested/'b.PNG';Image.new('RGB',(20,30),'red').save(a);Image.new('RGB',(20,30),'blue').save(b)
            (root/'ignore.txt').write_text('not an image')
            photos,errors=import_paths([str(root),str(a),str(nested)])
            self.assertEqual(len(photos),2);self.assertFalse(errors)
            w=Window();w.photos=[inspect_photo(a)];w.paths=[str(a)];w.crops=[[.2,.3,2]];w.dropped_imported((photos,[]))
            self.assertEqual(len(w.photos),2);self.assertEqual(w.paths,[str(a)]);self.assertEqual(w.crops,[[.2,.3,2]]);w.close()
    def test_drop_event_accepts_files_and_rejects_busy_or_remote(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'a.jpg';Image.new('RGB',(20,30)).save(p)
            w=Window();calls=[];w.start_drop_import=lambda paths:calls.append(paths)
            mime=QMimeData();mime.setUrls([QUrl.fromLocalFile(str(p))])
            enter=QDragEnterEvent(QPoint(10,10),Qt.DropAction.CopyAction,mime,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.NoModifier)
            w.dragEnterEvent(enter);self.assertTrue(enter.isAccepted())
            event=QDropEvent(QPointF(10,10),Qt.DropAction.CopyAction,mime,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.NoModifier)
            w.dropEvent(event);self.assertTrue(event.isAccepted());self.assertEqual(calls,[[str(p)]])
            w.busy=True;event=QDropEvent(QPointF(10,10),Qt.DropAction.CopyAction,mime,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.NoModifier);w.dropEvent(event);self.assertFalse(event.isAccepted());self.assertEqual(len(calls),1)
            mime.setUrls([QUrl('https://example.org/a.jpg')]);self.assertFalse(w.local_drop_paths(mime));w.busy=False;w.close()
if __name__=='__main__':unittest.main()
