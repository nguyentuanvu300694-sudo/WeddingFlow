import os,tempfile,unittest,ast
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from pathlib import Path
from PIL import Image
from PySide6.QtWidgets import QApplication,QScrollArea
from PySide6.QtCore import Qt,QPoint
from PySide6.QtTest import QTest
from app import Window
from core import inspect_photo
from editorial_layouts import text
from overlay_tools import overlay_descriptors,move_config_overlay
from love_art import custom_png_data,config_stamp
APP=QApplication.instance() or QApplication([])
class PreviewTests(unittest.TestCase):
    def test_preview_mouse_drag_updates_text_and_compact_tools_fit(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'red.png';Image.new('RGB',(400,600),'#66354c').save(path)
            w=Window();w.template.setCurrentIndex(1);w.photos=[inspect_photo(path)];w.refresh_list();w.use_current()
            w.ty.update(text_enabled=True,auto_text=False,text_layers=[text('MOVE ME',50,50,90)])
            w.redraw();w.show();APP.processEvents()
            rect=w.preview.image_rect();point=QPoint(round(rect.center().x()),round(rect.center().y()))
            QTest.mousePress(w.preview,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.NoModifier,point)
            QTest.mouseMove(w.preview,point+QPoint(25,15),delay=20)
            QTest.mouseRelease(w.preview,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.NoModifier,point+QPoint(25,15))
            APP.processEvents()
            self.assertGreater(w.ty['text_layers'][0]['x'],50);self.assertGreater(w.ty['text_layers'][0]['y'],50)
            self.assertEqual(w.selected_overlay,'text:0')
            self.assertFalse(w.editor_panel.findChildren(QScrollArea))
            self.assertLessEqual(w.export.mapTo(w,w.export.rect().bottomRight()).y(),w.height())
            self.assertEqual(w.windowTitle(),'WEDDING LAYOUT AUTO - by NTV MEDIA from TNDP with love');w.close()
    def test_art_drag_matches_visible_distance(self):
        c=dict(enabled=True,kind='artwork',preset=0,width=50,x=50,y=50)
        before=overlay_descriptors(c,(800,1200))[0]['box'];move_config_overlay(c,'art:0',.05,.03,(800,1200));after=overlay_descriptors(c,(800,1200))[0]['box']
        self.assertAlmostEqual(after[0]-before[0],40,delta=1);self.assertAlmostEqual(after[1]-before[1],36,delta=1)
    def test_png_recolor_preserves_alpha(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'type.png';Image.new('RGBA',(20,30),(10,20,30,100)).save(path)
            c=dict(kind='custom_png',png_data=custom_png_data(path),recolor_png=True,color='#00ff00')
            self.assertEqual(config_stamp(c).getpixel((5,5)),(0,255,0,100))
if __name__=='__main__':unittest.main()
