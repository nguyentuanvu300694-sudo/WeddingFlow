@echo off
call "%~dp0Windows_Launcher.bat" release
set "WEDDING_STATUS=%ERRORLEVEL%"
pause
exit /b %WEDDING_STATUS%
