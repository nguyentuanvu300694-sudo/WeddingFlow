"""Original English love/wedding typographic stamps, composed from OFL fonts.
No pixels, watermarks or lettering outlines are extracted from the reference.
"""
from functools import lru_cache
from PIL import Image,ImageDraw,ImageColor

def art(title,top,bottom='',font='Allura',pair='Cormorant Garamond',kicker=''):
 return dict(title=title,top=top,bottom=bottom,font=font,pair=pair,kicker=kicker)
ARTWORKS=[
 art('Live together','Live together',font='Allura',kicker='TWO HEARTS · ONE STORY'),
 art('Madly in love','madly in love',font='Dancing Script'),
 art('Love at first sight','Love at','first sight',font='Allura',pair='Great Vibes'),
 art('You complete me','You complete me',font='Great Vibes'),
 art('Always & forever','Always &','forever',font='Cormorant Garamond Italic',pair='Allura'),
 art('The love of my life','the love','of my life',font='Allura',pair='Dancing Script'),
 art('Better together','Better together',font='Dancing Script',kicker='EVERY DAY · EVERY SEASON'),
 art('With all my heart','with all my heart',font='Allura'),
 art('Our wedding day','OUR WEDDING','day',font='Cormorant Garamond',pair='Great Vibes'),
 art('Our love story','Our love','story',font='Allura',pair='Playfair Display Italic'),
 art('Endless love','Endless love',font='Great Vibes',kicker='A LIFETIME WITH YOU'),
 art('Just married','JUST','married',font='Montserrat',pair='Allura'),
 art('A beautiful beginning','A beautiful','beginning',font='Cormorant Garamond Italic',pair='Great Vibes'),
 art('Two hearts, one promise','Two hearts','one promise',font='Great Vibes',pair='Cormorant Garamond'),
 art('Yours, always','Yours, always',font='Allura'),
 art('Forever feels like you','Forever','feels like you',font='Great Vibes',pair='Cormorant Garamond Italic'),
 art('To have & to hold','to have','& to hold',font='Allura',pair='Dancing Script'),
 art('The beginning of forever','the beginning','of forever',font='Cormorant Garamond Italic',pair='Allura'),
 art('A lifetime of love','a lifetime','of love',font='Allura',pair='Playfair Display'),
 art('Written in the stars','Written','in the stars',font='Great Vibes',pair='Cormorant Garamond Italic'),
 art('Here begins forever','Here begins','forever',font='Cormorant Garamond',pair='Great Vibes'),
 art('You are my home','You are','my home',font='Allura',pair='Dancing Script'),
 art('Love, laughter & us','Love, laughter','& us',font='Dancing Script',pair='Great Vibes'),
 art('My sweetest love','My sweetest','love',font='Allura',pair='Playfair Display Italic'),
 art('A love to remember','a love','to remember',font='Great Vibes',pair='Cormorant Garamond'),
 art('Where our story begins','Where our','story begins',font='Allura',pair='Cormorant Garamond Italic'),
 art('Together is a beautiful place','Together','is a beautiful place',font='Great Vibes',pair='Cormorant Garamond'),
 art('One day, one lifetime','ONE DAY','one lifetime',font='Montserrat',pair='Allura'),
 art('We choose love','We choose','love',font='Cormorant Garamond Italic',pair='Great Vibes'),
 art('Love in every moment','Love','in every moment',font='Allura',pair='Cormorant Garamond'),
 art('Happily ever after','happily','ever after',font='Great Vibes',pair='Dancing Script'),
 art('Our forever starts here','Our forever','starts here',font='Allura',pair='Cormorant Garamond Italic'),
]
from extra_art import extra_artworks,draw_extra
for item in ARTWORKS:item['group']='Original'
ARTWORKS+=extra_artworks()

def default_artwork():return dict(kind='artwork',enabled=True,preset=0,color='#2c302c',width=76,x=50,y=96,opacity=100)

def bezier(draw,points,fill,width):
 out=[]
 for i in range(101):
  t=i/100;s=1-t
  out.append(tuple(s**3*points[0][j]+3*s*s*t*points[1][j]+3*s*t*t*points[2][j]+t**3*points[3][j] for j in (0,1)))
 draw.line(out,fill=fill,width=width)

@lru_cache(maxsize=40)
def make_stamp(index,color='#2c302c'):
 from typography import get_font
 from pathlib import Path
 asset=Path(__file__).resolve().parent/'artwork'/f'{int(index)%len(ARTWORKS):02d}.png'
 if asset.exists():
  with Image.open(asset) as source:alpha=source.convert('RGBA').getchannel('A')
  tinted=Image.new('RGBA',alpha.size,ImageColor.getrgb(color)+(255,));tinted.putalpha(alpha);return tinted
 a=ARTWORKS[int(index)%len(ARTWORKS)]
 if a.get('design'):return draw_extra(a,index,color,bezier)
 im=Image.new('RGBA',(2200,900));d=ImageDraw.Draw(im);fill=ImageColor.getrgb(color)+(255,)
 def put(text,family,size,y,maxwidth=1940):
  f=get_font(family,size)
  while d.textlength(text,font=f)>maxwidth and f.size>10:f=get_font(family,f.size-4)
  box=d.textbbox((0,0),text,font=f);x=(2200-d.textlength(text,font=f))/2
  d.text((x,y-box[1]),text,font=f,fill=fill)
  return y+box[3]-box[1]
 y=65
 if a['kicker']:y=put(a['kicker'],'Montserrat',37,y)+65
 if a['bottom']:
  end=put(a['top'],a['font'],220,y);end=put(a['bottom'],a['pair'],240,end+35)
 else:end=put(a['top'],a['font'],290,y+35)
 # Delicate custom flourishes; drawn below the lettering, not across its strokes.
 by=min(815,end+58)
 if index%3==0:
  bezier(d,[(680,by+8),(930,by-35),(1120,by+45),(1510,by-5)],fill,3)
 elif index%3==1:
  d.line((830,by,1035,by),fill=fill,width=2);d.line((1165,by,1370,by),fill=fill,width=2)
  d.polygon([(1100,by-8),(1108,by),(1100,by+8),(1092,by)],fill=fill)
 else:
  bezier(d,[(760,by+4),(1010,by-18),(1190,by+24),(1430,by)],fill,2)
 bbox=im.getbbox()
 if not bbox:return im
 x0,y0,x1,y1=bbox;pad=40
 return im.crop((max(0,x0-pad),max(0,y0-pad),min(im.width,x1+pad),min(im.height,y1+pad)))

def custom_png_data(path):
 from pathlib import Path
 import base64,io
 path=Path(path)
 if path.stat().st_size>20*1024*1024:raise ValueError('Vui lòng chọn PNG dưới 20 MB.')
 with Image.open(path) as source:
  if source.format!='PNG':raise ValueError('Vui lòng chọn đúng file PNG.')
  im=source.convert('RGBA')
 box=im.getchannel('A').getbbox()
 if not box:raise ValueError('File PNG hoàn toàn trong suốt.')
 im=im.crop(box);im.thumbnail((4096,4096),Image.Resampling.LANCZOS)
 out=io.BytesIO();im.save(out,format='PNG')
 return base64.b64encode(out.getvalue()).decode('ascii')

def config_stamp(config):
 if config.get('kind')=='custom_png':
  import base64,io
  with Image.open(io.BytesIO(base64.b64decode(config['png_data']))) as im:stamp=im.convert('RGBA')
  if config.get('recolor_png'):
   tinted=Image.new('RGBA',stamp.size,config.get('color') or '#ffffff');tinted.putalpha(stamp.getchannel('A'));stamp=tinted
  return stamp
 return make_stamp(config.get('preset',0),config.get('color') or '#2c302c').copy()

def apply_artwork(image,config):
 if not config.get('enabled',True):return image
 w,h=image.size
 stamp=config_stamp(config)
 target=max(1,round(w*max(20,min(95,int(config.get('width',76))))/100))
 scale=min(target/stamp.width,h*.45/stamp.height)
 stamp=stamp.resize((max(1,round(stamp.width*scale)),max(1,round(stamp.height*scale))),Image.Resampling.LANCZOS)
 opacity=max(0,min(100,int(config.get('opacity',100))))/100
 if opacity<1:stamp.putalpha(stamp.getchannel('A').point(lambda a:round(a*opacity)))
 x=round((w-stamp.width)*max(0,min(100,int(config.get('x',50))))/100)
 y=round((h-stamp.height)*max(0,min(100,int(config.get('y',96))))/100)
 layer=Image.new('RGBA',(w,h));layer.alpha_composite(stamp,(x,y))
 return Image.alpha_composite(image.convert('RGBA'),layer).convert('RGB')
