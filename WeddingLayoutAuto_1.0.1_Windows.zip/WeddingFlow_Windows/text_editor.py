"""Multiple editable text layers, bundled font choices and local TTF/OTF import."""
from copy import deepcopy
from pathlib import Path
from PIL.ImageQt import ImageQt
from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap,QColor
from PySide6.QtWidgets import QDialog,QHBoxLayout,QVBoxLayout,QFormLayout,QWidget,QListWidget,QPushButton,QPlainTextEdit,QComboBox,QDoubleSpinBox,QSpinBox,QCheckBox,QLabel,QScrollArea,QColorDialog,QFileDialog,QMessageBox,QDialogButtonBox
from typography import font_catalog
from editable_text import import_font
from editorial_layouts import text

class TextEditor(QDialog):
    def __init__(self,config,defaults,preview,parent=None):
        super().__init__(parent);self.setWindowTitle('TEXT & FONT · chỉnh từng lớp chữ');self.resize(1120,780)
        self.config=deepcopy(config);self.defaults=deepcopy(defaults);self.preview_fn=preview;self.loading=False
        self.config.setdefault('text_layers',deepcopy(defaults));self.config.setdefault('text_enabled',True);self.config.setdefault('auto_text',True)
        outer=QVBoxLayout(self);body=QHBoxLayout();outer.addLayout(body,1)
        left=QVBoxLayout();body.addLayout(left);self.layers=QListWidget();self.layers.setMaximumWidth(210);left.addWidget(self.layers,1)
        for label,fn in [('Thêm chữ',self.add_layer),('Nhân đôi',self.duplicate),('Xóa lớp chữ',self.remove),('Xóa chữ / bắt đầu trống',self.reset)]:
            b=QPushButton(label);b.clicked.connect(fn);left.addWidget(b)
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setMinimumWidth(360);panel=QWidget();self.form=QFormLayout(panel);scroll.setWidget(panel);body.addWidget(scroll)
        self.enabled=QCheckBox('Hiện text');self.enabled.setChecked(self.config['text_enabled']);self.form.addRow(self.enabled)
        self.auto=QCheckBox('Làm trống chữ khi đổi layout');self.auto.setChecked(self.config['auto_text']);self.form.addRow(self.auto)
        self.content=QPlainTextEdit();self.content.setMaximumHeight(150);self.content.setObjectName('text_content');self.form.addRow('Nội dung',self.content)
        self.font=QComboBox()
        for record in font_catalog():self.font.addItem(record['name'],record['name'])
        self.form.addRow('Font',self.font)
        local=QPushButton('Nhập font TTF / OTF từ máy…');local.clicked.connect(self.choose_font);self.form.addRow(local)
        self.custom_name=QLabel('');self.custom_name.setWordWrap(True);self.form.addRow(self.custom_name)
        self.color=QPushButton('Chọn màu chữ…');self.color.clicked.connect(self.choose_color);self.form.addRow('Màu chữ',self.color)
        self.controls={}
        for key,label,low,high,default in [('size','Cỡ chữ / 1000 cạnh ngắn',2,300,30),('x','Tâm ngang %',0,100,50),('y','Tâm dọc %',0,100,50),('width','Độ rộng hộp chữ %',1,100,80),('tracking','Giãn chữ % cỡ font',-10,80,0),('leading','Giãn dòng %',80,250,115),('weight','Độ đậm (font variable)',100,900,400),('angle','Xoay chữ °',-180,180,0),('opacity','Độ rõ %',0,100,100)]:
            c=QDoubleSpinBox();c.setRange(low,high);c.setValue(default);c.setDecimals(1);c.setObjectName('text_'+key);self.controls[key]=c;self.form.addRow(label,c);c.valueChanged.connect(self.changed)
        self.align=QComboBox();self.align.addItems(['Trái','Giữa','Phải']);self.form.addRow('Căn dòng',self.align)
        self.z_order=QComboBox();self.z_order.addItems(['Trên ảnh','Dưới ảnh']);self.form.addRow('Thứ tự lớp',self.z_order);self.z_order.currentIndexChanged.connect(self.changed)
        self.visible=QCheckBox('Hiện lớp chữ này');self.form.addRow(self.visible)
        note=QLabel('Chọn font viết tay, serif hoặc sans để phối như mẫu. Font nhập được lưu kèm dự án. Font có sẵn là lựa chọn gần phong cách mẫu.');note.setWordWrap(True);self.form.addRow(note)
        self.preview=QLabel();self.preview.setMinimumSize(360,430);self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter);body.addWidget(self.preview,1)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel);buttons.accepted.connect(self.accept);buttons.rejected.connect(self.reject);outer.addWidget(buttons)
        self.layers.currentRowChanged.connect(self.select);self.content.textChanged.connect(self.changed);self.font.currentIndexChanged.connect(self.font_changed);self.align.currentIndexChanged.connect(self.changed);self.visible.toggled.connect(self.changed);self.enabled.toggled.connect(self.global_changed);self.auto.toggled.connect(self.global_changed)
        self.refresh_list();self.render_preview()
    def refresh_list(self,index=0):
        self.layers.blockSignals(True);self.layers.clear()
        for i,layer in enumerate(self.config['text_layers']):self.layers.addItem(f'{i+1:02d} · '+layer.get('text','').replace('\n',' ')[:28])
        self.layers.setCurrentRow(min(index,self.layers.count()-1));self.layers.blockSignals(False);self.select(self.layers.currentRow())
    def current(self):
        i=self.layers.currentRow();return self.config['text_layers'][i] if 0<=i<len(self.config['text_layers']) else None
    def select(self,index):
        layer=self.current();self.loading=True
        self.content.setPlainText(layer.get('text','') if layer else '')
        if layer:
            self.font.setCurrentIndex(max(0,self.font.findData(layer.get('font','Montserrat'))));self.custom_name.setText(layer.get('font_name','Font có sẵn'))
            for key,c in self.controls.items():c.setValue(layer.get(key,c.value()))
            self.z_order.setCurrentIndex(1 if layer.get('z_order')=='below' else 0)
            self.align.setCurrentIndex(['left','center','right'].index(layer.get('align','center')));self.visible.setChecked(layer.get('visible',True))
            self.color.setStyleSheet('background:'+layer.get('color','#ffffff')+';color:#555')
        self.loading=False
    def changed(self,*args):
        if self.loading:return
        layer=self.current()
        if layer is None:return
        layer['z_order']='below' if self.z_order.currentIndex() else 'above'
        layer.update(text=self.content.toPlainText(),align=['left','center','right'][self.align.currentIndex()],visible=self.visible.isChecked(),**{k:v.value() for k,v in self.controls.items()})
        self.config['auto_text']=False;self.auto.blockSignals(True);self.auto.setChecked(False);self.auto.blockSignals(False)
        self.layers.currentItem().setText(f'{self.layers.currentRow()+1:02d} · '+layer['text'].replace('\n',' ')[:28]);self.render_preview()
    def global_changed(self,*args):
        if self.loading:return
        self.config['text_enabled']=self.enabled.isChecked();self.config['auto_text']=self.auto.isChecked();self.render_preview()
    def font_changed(self,*args):
        if self.loading:return
        layer=self.current()
        if layer is None:return
        layer['font']=self.font.currentData();layer.pop('font_data',None);layer.pop('font_name',None);self.custom_name.setText('Font có sẵn');self.changed()
    def choose_font(self):
        layer=self.current()
        if layer is None:return
        path,_=QFileDialog.getOpenFileName(self,'Chọn font','','Fonts (*.ttf *.otf *.TTF *.OTF)')
        if not path:return
        try:layer['font_data']=import_font(path);layer['font_name']=Path(path).name;self.custom_name.setText(Path(path).name);self.changed()
        except Exception as e:QMessageBox.warning(self,'Không đọc được font',str(e))
    def choose_color(self):
        layer=self.current()
        if layer is None:return
        c=QColorDialog.getColor(QColor(layer.get('color','#ffffff')),self,'Màu chữ')
        if c.isValid():layer['color']=c.name();self.color.setStyleSheet('background:'+c.name()+';color:#555');self.changed()
    def add_layer(self):
        self.config['text_layers'].append(text('Nhập chữ của bạn',50,50,40,'Allura'));self.refresh_list(len(self.config['text_layers'])-1);self.changed()
    def duplicate(self):
        layer=self.current()
        if layer is not None:
            copy=deepcopy(layer);copy['y']=min(100,copy.get('y',50)+4);self.config['text_layers'].append(copy);self.refresh_list(len(self.config['text_layers'])-1);self.changed()
    def remove(self):
        i=self.layers.currentRow()
        if i>=0:self.config['text_layers'].pop(i);self.config['auto_text']=False;self.auto.setChecked(False);self.refresh_list(max(0,i-1));self.render_preview()
    def reset(self):
        self.config['text_layers']=deepcopy(self.defaults);self.config['auto_text']=True;self.auto.blockSignals(True);self.auto.setChecked(True);self.auto.blockSignals(False);self.refresh_list();self.render_preview()
    def render_preview(self):
        try:
            im=self.preview_fn(self.config);self.preview.setPixmap(QPixmap.fromImage(ImageQt(im)).scaled(430,570,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
        except Exception as e:self.preview.setText(str(e))
