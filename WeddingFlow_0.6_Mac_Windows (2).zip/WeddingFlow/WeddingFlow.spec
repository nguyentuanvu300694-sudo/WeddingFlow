# Run on Windows: python -m PyInstaller --clean --noconfirm WeddingFlow.spec
from pathlib import Path
import sys
from PyInstaller.utils.hooks import collect_all,collect_submodules,collect_data_files,copy_metadata
if sys.platform!='win32':raise RuntimeError('Build the Windows executable on Windows.')
root=Path(SPECPATH)
datas=[(str(root/'fonts'),'fonts'),(str(root/'artwork'),'artwork')]
for name in ['README_VI.txt','GOOGLE_DRIVE_SETUP_VI.txt','WINDOWS_VI.txt','app_icon.ico']:
 datas.append((str(root/name),'.'))
oc_data,oc_bins,oc_hidden=collect_all('open_clip')
datas+=oc_data+collect_data_files('timm')
for distribution in ['open_clip_torch','timm','torch','torchvision','keyring','gdown']:
 datas+=copy_metadata(distribution)
hidden=oc_hidden+collect_submodules('timm.models')+['keyring.backends.Windows','packaged_smoke','extra_art','public_drive','drive_source','more_templates']
a=Analysis([str(root/'app.py')],pathex=[str(root)],binaries=oc_bins,datas=datas,hiddenimports=hidden,hookspath=[],runtime_hooks=[str(root/'runtime_windows.py')],excludes=['PyQt5','PyQt6','PySide2','tkinter','matplotlib','IPython','jupyter','pytest','torchaudio','tensorflow'],noarchive=False)
pyz=PYZ(a.pure)
exe=EXE(pyz,a.scripts,[],exclude_binaries=True,name='WeddingFlow',icon=str(root/'app_icon.ico'),debug=False,bootloader_ignore_signals=False,strip=False,upx=False,console=False)
collect=COLLECT(exe,a.binaries,a.datas,strip=False,upx=False,name='WeddingFlow')
