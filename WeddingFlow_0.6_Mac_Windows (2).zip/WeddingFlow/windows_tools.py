"""Windows x64 setup/build driver, invoked by the accompanying .bat files."""
from pathlib import Path
import hashlib,os,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parent

def check_platform():
 if sys.platform!='win32':raise RuntimeError('Run this tool on Windows. PyInstaller cannot produce a Windows executable from macOS/Linux.')
 if sys.version_info[:2] not in [(3,11),(3,12)] or sys.maxsize<=2**32:raise RuntimeError('Install Python 3.11 or 3.12, Windows 64-bit.')

def command(args,env=None):
 print('Running:', ' '.join(str(a) for a in args),flush=True)
 subprocess.run([str(a) for a in args],cwd=ROOT,env=env,check=True)

def setup():
 check_platform();venv=ROOT/'.venv-win';python=venv/'Scripts'/'python.exe'
 if not python.exists():command([sys.executable,'-m','venv',venv])
 digest=hashlib.sha256((ROOT/'requirements.txt').read_bytes()).hexdigest();marker=venv/'.requirements.sha256'
 if not marker.exists() or marker.read_text()!=digest:
  command([python,'-m','pip','install','--upgrade','pip'])
  # CPU wheels keep the first Windows build independent of CUDA/GPU configuration.
  command([python,'-m','pip','install','torch','torchvision','--index-url','https://download.pytorch.org/whl/cpu'])
  command([python,'-m','pip','install','-r',ROOT/'requirements.txt'])
  marker.write_text(digest)
 return python

def main(action):
 python=setup()
 if action=='run':command([python,ROOT/'app.py']);return
 if action not in ['build','release']:raise ValueError('Use run, build or release.')
 command([python,'-m','pip','install','PyInstaller>=6.16,<7','pyinstaller-hooks-contrib'])
 command([python,'-m','unittest','discover','-s','tests'])
 spec='WeddingFlow_Single.spec' if action=='release' else 'WeddingFlow.spec'
 command([python,'-m','PyInstaller','--noconfirm','--clean',spec])
 executable=ROOT/'dist'/'WeddingFlow.exe' if action=='release' else ROOT/'dist'/'WeddingFlow'/'WeddingFlow.exe'
 if not executable.is_file():raise RuntimeError('Build did not create WeddingFlow.exe.')
 print('Checking packaged Qt, fonts and art assets...',flush=True)
 env=os.environ.copy();env['QT_QPA_PLATFORM']='offscreen'
 subprocess.run([str(executable),'--self-test'],cwd=ROOT,env=env,check=True,timeout=180)
 if action=='release':
  print('Standalone Windows executable:',executable,flush=True);return
 archive=shutil.make_archive(str(ROOT/'dist'/'WeddingFlow_0.6_Windows_x64'),'zip',root_dir=ROOT/'dist',base_dir='WeddingFlow')
 print('\nEXE:',executable,'\nShare the entire folder or ZIP:',archive,flush=True)

if __name__=='__main__':
 try:main(sys.argv[1] if len(sys.argv)>1 else 'run')
 except Exception as e:print('\nFAILED:',e,flush=True);sys.exit(1)
