WEDDINGFLOW — BẢN THỬ NGHIỆM 0.6.1 · MAC + WINDOWS
Ứng dụng desktop Qt/Python cho Mac Apple Silicon và Windows x64.
Gói này chứa mã nguồn, trình khởi động và bộ build Windows; CHƯA có .exe
Windows hoặc .app/.dmg Mac đã build sẵn.

ĐÓNG GÓI EXE / DMG
Đã thêm quy trình native để tạo Windows EXE một file và Mac .app/.dmg:
- Build_Release_Windows.bat: standalone EXE.
- Build_Release_Mac.command: Mac app + DMG.
- GitHub Actions: hai job chạy trên Windows và macOS thật.
Đọc RELEASE_BUILD_VI.txt. Chưa có EXE/DMG đã build sẵn trong gói; cần máy
native hoặc kết nối GitHub để chạy quy trình. Mac mặc định chưa notarize.

MỚI TRONG 0.6.1 — HƯỚNG ẢNH KẾT QUẢ
Phần Tạo layout có lựa chọn Dọc / Ngang (và Vuông nếu cần).
- Dọc mặc định 2400 × 3600 px; Ngang 3600 × 2400 px.
- Khi đổi hướng, app hoán đổi cạnh ngắn/dài hiện tại và sắp lại các ô theo
  hướng khung. Nội dung ảnh giữ thẳng, không xoay ảnh thành nằm nghiêng.
- Có thể nhập kích thước riêng; lựa chọn hướng tự cập nhật theo số pixel.
- Hướng và kích thước lưu cùng dự án, tương thích dự án cũ theo kích thước.
Đã thử qua giao diện: xuất JPG dọc/ngang đúng kích thước, ảnh giữ thẳng,
lưu/mở dự án giữ hướng và nhập kích thước riêng đồng bộ với lựa chọn.

CÀI VÀ MỞ
WINDOWS:
- Cài Python 3.11 hoặc 3.12 bản 64-bit, có Python Launcher.
- Giải nén, nhấp đúp Start_Windows.bat để chạy từ mã nguồn.
- Muốn tạo EXE: nhấp đúp Build_Windows.bat trên Windows.
- Kết quả: dist/WeddingFlow/WeddingFlow.exe và ZIP portable cùng thư mục.
- Chuyển cả thư mục ứng dụng; giữ thư mục _internal đi cùng file .exe.
- Xem WINDOWS_VI.txt để biết cách build, kiểm tra và chuyển cho máy khác.
MAC:
- Cài Python 3.11/3.12 macOS universal2 nếu chưa có.
- Trong Terminal, chuyển tới thư mục WeddingFlow rồi chạy bash Start.command.
Không cần tắt Gatekeeper. Lần đầu tải thư viện cần Internet.

MỚI TRONG 0.6
- Thêm 48 artwork tiếng Anh, tổng 80. Giữ nguyên ID của 32 mẫu cũ để dự án
  đang làm vẫn mở đúng mẫu chữ đã chọn.
- Bốn nhóm mới: Signature, Modern Editorial, Romantic Flourish,
  Magazine Collage; có bộ lọc phong cách trong thư viện chữ.
- Nét ký mảnh, chữ cái đầu lớn, chữ lớn/nhỏ, serif phối script, nét uốn và
  câu phụ nhỏ. Tất cả là bản phối mới, không lấy pixel/đường nét từ ảnh mẫu.
- 80 PNG trong suốt trong artwork/. Mẫu mới phần lớn rộng khoảng 2200 px.
- Thêm chạy/build Windows, spec PyInstaller, hook cho ứng dụng không console,
  self-test EXE, icon và vị trí dữ liệu %LOCALAPPDATA%/WeddingFlow.
- Windows mặc định dùng PyTorch CPU; không yêu cầu cấu hình CUDA.
- 30 kiểm thử đạt trên Linux; smoke-test mã nguồn offline đạt. Đã kiểm tra
  giao diện lọc/chọn 80 artwork. Chưa build hoặc kiểm thử EXE trên Windows
  thật, chưa kiểm thử trực tiếp trên Mac M1. Bộ build sẽ thử EXE tại Windows.

MỚI TRONG 0.5 — CHỮ NGHỆ THUẬT VÀ NỀN RIÊNG
1. “Chữ nghệ thuật · Love & Wedding”: thay trình nhập/sửa chữ bằng thư viện
   32 cụm typography ban đầu (nay tổng 80), lấy cảm hứng từ phong cách ảnh mẫu.
   Ví dụ Live together, Madly in love, You complete me, The love of my life,
   Our wedding day, Always & forever, Our forever starts here…
2. Chọn trực tiếp mẫu chữ có hình xem trước; chỉnh màu, kích thước, vị trí,
   độ rõ hoặc tắt chữ. Không cần gõ câu, tên hoặc tự chọn font nữa.
3. Chữ nền trong suốt, không có khung trắng. Tệp PNG nền trong suốt độ phân
   giải cao kèm trong artwork/, nguồn chữ dùng font OFL trong fonts/.
   Đây là các bản phối mới, không lấy pixel, watermark hay đường nét chữ
   độc quyền từ ảnh tham chiếu. Bản PNG không phải vector; hạn chế phóng quá
   mức so với kích thước gốc khoảng 2000 px để tránh giảm độ sắc nét.
4. “Nền mờ theo ý tôi”: chọn ảnh nền từ máy hoặc ảnh đang duyệt (kể cả Drive),
   chỉnh độ mờ, độ sáng, phủ trắng, vị trí ngang/dọc và lề để thấy nền.
   Nền riêng áp dụng cho cả 60 layout, kể cả mẫu trước đây có nền trắng/kem.
   Giữ ảnh nền khi đổi layout. Ảnh chính vẫn rõ; chỉ lớp nền chịu hiệu ứng.
5. Chữ và nền riêng lưu cùng dự án. Dự án cũ vẫn hiển thị chữ cũ theo cấu hình
   cũ; khi mở thư viện nghệ thuật và chọn mẫu, chữ cũ được thay bằng mẫu mới.
   Không còn giao diện chỉnh nội dung/font tự do của bản 0.4.

MỚI TRONG 0.4 — DÁN LINK DRIVE, KHÔNG CẦN OAUTH JSON
CÁCH DÙNG NHANH:
1. Trên Google Drive, mở Chia sẻ → Quyền truy cập chung →
   Bất kỳ ai có đường liên kết → Người xem. Chỉ dùng cách này cho album
   bạn đồng ý chia sẻ qua liên kết. Quyền từng ảnh bên trong phải cho phép xem.
2. Trong WeddingFlow, bấm “Dán link Drive”, dán link thư mục.
3. App lấy danh sách và preview; chỉ tải ảnh gốc đang dùng khi bạn bấm Xuất.
Không cần Google Cloud, API key, OAuth JSON hay đăng nhập cho chế độ này.
Ảnh xem trước tải song song tối đa 4 ảnh, có tiến độ và báo riêng file bị lỗi.

GIỚI HẠN CHẾ ĐỘ LINK CÔNG KHAI:
- Dùng endpoint công khai của Google và gdown chỉ để liệt kê + tải từng ảnh
  gốc được chọn; không dùng download_folder để tải cả thư mục.
- Google có thể đổi endpoint, chặn tải hoặc giới hạn truy cập. Chế độ này
  tiện hơn OAuth nhưng không có bảo đảm độ ổn định của API chính thức.
- Không vượt qua quyền xem/tải. Nếu một ảnh gốc bị chặn, app dừng xuất:
  tải riêng ảnh đó bằng trình duyệt rồi “Thay ảnh từ máy”, hoặc đăng nhập
  qua “Drive riêng tư”. Không âm thầm xuất bằng preview.
- Không có metadata/checksum/phiên bản gốc đáng tin cậy trong chế độ công khai.
  Mức gom 0 không kết luận hai file khác ID là trùng hoàn toàn.
- App làm mới preview khi nhập album. Khi xuất lại, ảnh gốc công khai được
  tải lại để tránh tin vào cache cũ không kiểm chứng được phiên bản;
  một ảnh lặp nhiều ô vẫn chỉ tải một lần trong lần xuất đó.
- Kích thước hiển thị cho ảnh công khai là kích thước preview, không phải gốc.

GIỮ ALBUM RIÊNG TƯ:
Nút “Drive riêng tư” giữ chế độ API + đăng nhập từ bản 0.3. Cần Desktop OAuth
JSON một lần; hướng dẫn ở GOOGLE_DRIVE_SETUP_VI.txt. Chế độ này có kiểm tra
checksum/phiên bản Google và dùng lại bản gốc đã cache hợp lệ.
Bạn không cần thiết lập OAuth nếu chỉ dùng “Dán link Drive”.

ẢNH TRÊN MÁY
“Mở ảnh trên máy” quét cả thư mục con: JPG, JPEG, PNG, TIFF, WEBP.
Nhập album mới thay danh sách đang làm; lưu dự án trước nếu cần giữ lại.
Quét ảnh trong Drive Desktop có thể vẫn tải toàn bộ ảnh gốc; muốn dùng preview
hãy chọn Dán link Drive hoặc Drive riêng tư của bản 0.5.

PHÂN LOẠI AI
Bấm Phân loại bằng AI. Lần đầu tải OpenCLIP ViT-B-32 laion2b_s34b_b79k,
hàng trăm MB. Sau đó xử lý cục bộ, dùng MPS trên Apple Silicon nếu có.
Không gửi ảnh đến API phân loại. Nhãn zero-shot là đề xuất, chưa huấn luyện
riêng theo album của bạn. Có thể nhầm cô dâu, khách mặc áo dài và nghi lễ;
sửa bằng các ô nhãn. Không xác minh danh tính cô dâu/chú rể.
Với ảnh Drive, AI dùng preview có độ phân giải phụ thuộc Google.

GOM ẢNH GIỐNG
Mức 0: chỉ đề xuất ảnh gốc trùng theo checksum; ảnh Drive API dùng checksum gốc
Google cung cấp; chế độ link công khai chỉ xác định cùng file ID, tuyệt đối không dùng checksum thumbnail làm bằng chứng
hai bản gốc giống nhau. Nếu thiếu checksum, không gom các file khác ID ở mức 0.
Mức 7 mặc định: so pHash, thêm embedding rất gần kết hợp pHash nếu đã chạy AI.
Tăng mức sẽ gom nhiều hơn; nhóm theo ảnh đại diện để tránh nối chuỗi quá rộng.
Đề xuất giữ ảnh nhiều chi tiết và ít cháy/tối; không đánh giá mắt nhắm hoặc
biểu cảm. Với Drive, đây chỉ là so sánh preview, không kết luận độ nét bản gốc.
Bật Chỉ xem nhóm ảnh giống để sửa lựa chọn. Chạy lại sẽ đặt lại đề xuất giữ.
Không xóa, di chuyển hoặc chỉnh sửa ảnh gốc.

60 MẪU VÀ TYPOGRAPHY
20 mẫu đầu lấy cấu trúc từ ảnh tham chiếu; 40 bố cục bổ sung do app dựng.
Không phải 60 mẫu mới tải từ Google. Chọn mẫu, chủ đề rồi bấm tạo layout.
Bấm lại để thử một lượt chọn khác. Tự chọn không lặp ảnh hoặc nhóm ảnh giống
để lấp ô. Nếu thiếu ảnh, chọn mẫu ít ô hơn hoặc giữ thêm ảnh.
Chọn Ô 1, Ô 2… để thay ảnh; dùng thanh Ngang/Dọc chỉnh vị trí cắt.
Chọn nền decor riêng cho mẫu nền mờ; có thể đưa ảnh Drive đang duyệt vào ô.
Bấm Chữ nghệ thuật để mở thư viện 80 mẫu tiếng Anh. Chọn màu trắng cho nền
tối, đen mực cho nền sáng; có thêm champagne, đỏ rượu, olive. Đặt nhanh trên,
giữa hoặc dưới; chỉnh vị trí để không che mặt/chủ thể. Mẫu chữ không tự nhận
biết vị trí khuôn mặt, cần bạn xem bố cục trước khi xuất.
Các font OFL gốc vẫn đi kèm để tương thích dự án cũ: Playfair Display,
Cormorant Garamond, Lora, Montserrat, Be Vietnam Pro, Dancing Script,
Great Vibes, Allura. Không cần mạng để dùng thư viện chữ.

Bố cục không sao chép chính xác từng pixel, texture hay họa tiết từ ảnh mẫu.

XUẤT VÀ DỰ ÁN
Xuất mặc định 2400 × 3600 px, JPEG chất lượng 96, metadata 300 DPI.
Số pixel quyết định độ chi tiết thực tế. Xem trước cập nhật theo tỷ lệ xuất.
Ảnh có thể bị cắt; đây là căn vị trí thủ công, chưa nhận diện mặt để tự crop.
Dự án .json lưu nhãn, nhóm, lựa chọn giữ, ID/phiên bản Drive, đường dẫn preview,
layout, vị trí cắt và typography. Không chứa token và không đóng gói ảnh gốc.
Lưu thủ công trước khi đóng app/nhập album khác. Dự án 0.1/0.2 vẫn mở được.
Preview thiếu: dùng Drive riêng tư → Khôi phục ảnh xem trước của dự án.
Ảnh local đã di chuyển: giữ/khôi phục đường dẫn thư mục gốc để mở lại.

KIỂM THỬ VÀ GIỚI HẠN
30 kiểm thử lõi/typography/Drive/nền và tương thích Windows đã đạt: 60 mẫu, 12 kiểu chữ, EXIF, file hỏng,
checksum, phân trang, chỉ preview khi import, chỉ tải ảnh được chọn khi xuất,
cache, khôi phục preview và chống dùng nhầm phiên bản ở chế độ API.
Có kiểm thử 80 mẫu chữ trong suốt, đổi vị trí/độ rõ, nền riêng trên mẫu trắng,
kem, tràn khung và lưu/mở cấu hình chữ/nền. Kiểm tra giao diện chọn chữ,
chỉnh nền và giữ nền khi đổi layout.
Kiểm thử link công khai: không OAuth, không tải gốc lúc import, chỉ tải
ảnh được chọn lúc xuất, không gom nhầm thumbnail và bỏ qua preview lỗi.
Kiểm tra giao diện với Drive giả lập xác nhận bản xuất dùng pixel ảnh gốc,
không dùng thumbnail. Đã thử đọc 377 file trong thư mục Cưới qua link công khai và lấy một preview
thật không OAuth; tải và giải mã thành công một ảnh gốc được chọn (11.7 MB).
Chưa kiểm thử đăng nhập OAuth hoặc trực tiếp trên Mac M1;
chưa đo độ chính xác AI toàn bộ album. Chỉ chế độ Drive riêng tư cần OAuth client của bạn.
Google có thể không cung cấp preview, hạn chế tải hoặc yêu cầu đăng nhập lại.

MÃ NGUỒN
app.py: giao diện và tác vụ nền
core.py: phân tích, nhóm, lựa chọn, template, render
drive_source.py: OAuth, Drive chỉ đọc, cache preview và tải gốc theo nhu cầu
public_drive.py: dán link công khai, không cấu hình Google Cloud
more_templates.py: 40 bố cục bổ sung
love_art.py, extra_art.py và artwork/: 80 typography PNG, chọn mẫu/phối màu
typography.py và fonts/: font/giấy phép, renderer tương thích dự án cũ
tests/: kiểm thử. Chạy .venv/bin/python -m unittest discover -s tests
Start.command / Start_Windows.bat / requirements.txt: khởi chạy
Build_Windows.bat / windows_tools.py / WeddingFlow.spec: bộ build Windows
packaged_smoke.py / runtime_windows.py: kiểm tra và runtime EXE
Love_Wedding_Catalog.jpg / Artwork_picker.png / Background_picker.png /
UI_preview.png / Version05_example.jpg / New_Artworks_06.jpg /
Artwork_picker_06.png: minh họa
(ảnh minh họa dùng album mẫu; tên/ngày hiển thị không suy ra danh tính người).

NGUỒN
https://github.com/wkentaro/gdown
https://github.com/mlfoundations/open_clip
https://doc.qt.io/qtforpython-6/
https://github.com/google/fonts
https://developers.google.com/workspace/drive/api/quickstart/python
