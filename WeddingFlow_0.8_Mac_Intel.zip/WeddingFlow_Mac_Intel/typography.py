"""Offline Google Fonts and editable typography compositions."""
from pathlib import Path
import json,unicodedata
from functools import lru_cache
from PIL import Image,ImageDraw,ImageFont,ImageColor
ROOT=Path(__file__).resolve().parent/'fonts'
def font_catalog():
    p=ROOT/'catalog.json'
    return json.loads(p.read_text()) if p.exists() else []
STYLES=[
 ('01 · Wedding editorial',.86,'#51493e','Playfair Display',False),
 ('02 · Lời yêu viết tay',.84,'#6f5847','Dancing Script',False),
 ('03 · Vogue tối giản',.06,'#302c27','Cormorant Garamond',True),
 ('04 · Save the date',.07,'#ffffff','Montserrat',True),
 ('05 · Nét mực cổ điển',.84,'#2e342c','Lora',False),
 ('06 · Golden hour',.84,'#b99a5e','Cormorant Garamond Italic',False),
 ('07 · Our love story',.06,'#ffffff','Great Vibes',False),
 ('08 · Thiệp Việt',.84,'#873a43','Be Vietnam Pro',False),
 ('09 · Chữ ký kỷ niệm',.83,'#ffffff','Allura',False),
 ('10 · Modern romance',.84,'#353d37','Montserrat',True),
 ('11 · Fine art',.06,'#635949','Playfair Display Italic',False),
 ('12 · Love journal',.84,'#324c44','Cormorant Garamond',False)]

def default_typography():
 return dict(enabled=True,style=0,title='THE WEDDING',names='Tên cô dâu & Tên chú rể',date='Ngày · Tháng · Năm',quote='',font='Theo mẫu',color='',size=100,y=0,panel=True)

@lru_cache(maxsize=128)
def get_font(name,size):
    catalog=font_catalog();record=next((f for f in catalog if f['name']==name),None)
    if not record:raise ValueError('Không tìm thấy font '+name+'. Hãy giữ thư mục fonts cạnh app.py.')
    return ImageFont.truetype(str(ROOT/record['file']),max(6,int(size)))

def wrap(text,font,maxwidth,draw):
    lines=[]
    for paragraph in unicodedata.normalize('NFC',text).splitlines():
        words=paragraph.split();line=''
        for word in words:
            candidate=(line+' '+word).strip()
            if line and draw.textlength(candidate,font=font)>maxwidth:lines.append(line);line=word
            else:line=candidate
        if line:lines.append(line)
    return lines

def _apply_existing_typography(image,config=None):
    c=config or {}
    if not c.get('enabled'):return image
    if c.get('kind') in ('artwork','custom_png'):
        from love_art import apply_artwork
        return apply_artwork(image,c)
    w,h=image.size;_,y,color,font,upper=STYLES[int(c.get('style',0))%len(STYLES)]
    y=max(.005,min(.94,y+float(c.get('y',0))/1000))
    color=c.get('color') or color;ImageColor.getrgb(color)
    if c.get('font') and c['font']!='Theo mẫu':font=c['font']
    scale=max(.4,min(1.8,float(c.get('size',100))/100))
    entries=[(c.get('title',''),'Be Vietnam Pro',.011,True),
             (c.get('names',''),font,.037,upper),
             (c.get('date',''),'Be Vietnam Pro',.012,False),
             (c.get('quote',''),'Lora',.014,False)]
    # Fit whole block to the canvas and shrink long names rather than clip accents.
    draw=ImageDraw.Draw(image);maxwidth=w*.86
    for fit in [1,.9,.8,.7,.6,.5,.4,.3]:
        lines=[]
        for text,family,ratio,caps in entries:
            if not text.strip():continue
            text=unicodedata.normalize('NFC',text.upper() if caps else text)
            f=get_font(family,max(7,h*ratio*scale*fit))
            while draw.textlength(max(text.split(),key=len,default=''),font=f)>maxwidth and f.size>6:
                f=get_font(family,f.size-1)
            wrapped=wrap(text,f,maxwidth,draw)
            for line in wrapped:
                bbox=draw.textbbox((0,0),line,font=f);lh=bbox[3]-bbox[1]
                lines.append((line,f,bbox,max(1,round(h*.006*fit))))
        total=sum(b[3]-b[1]+gap for _,_,b,gap in lines)
        if total<=min(h*.29,h*(1-y)-h*.015):break
    top=min(round(y*h),h-total-round(h*.015));top=max(round(h*.01),top)
    overlay=Image.new('RGBA',(w,h));od=ImageDraw.Draw(overlay)
    if c.get('panel',True) and lines:
        rgb=ImageColor.getrgb(color);light=sum(rgb[:3])>500
        fill=(15,20,18,130) if light else (255,253,247,210)
        pad=round(h*.012);od.rectangle((round(w*.035),max(0,top-pad),round(w*.965),min(h,top+total+pad)),fill=fill)
    for line,f,bbox,gap in lines:
        tw=od.textlength(line,font=f)
        od.text(((w-tw)/2,top-bbox[1]),line,font=f,fill=color)
        top+=bbox[3]-bbox[1]+gap
    return Image.alpha_composite(image.convert('RGBA'),overlay).convert('RGB')


def apply_typography(image,config=None):
    c=config or {}
    image=_apply_existing_typography(image,c)
    if c.get('text_enabled',False):
        from editable_text import apply_text_layers
        image=apply_text_layers(image,c)
    return image
