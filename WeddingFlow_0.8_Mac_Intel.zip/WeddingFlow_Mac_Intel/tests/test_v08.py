import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import unittest,tempfile,base64
from pathlib import Path
from PIL import Image,ImageChops
from core import TEMPLATES,oriented_template,render,save_project,open_project
from typography import apply_typography,font_catalog,ROOT
from editable_text import import_font
from PySide6.QtWidgets import QApplication
APP=QApplication.instance() or QApplication([])

class CuratedLayoutTests(unittest.TestCase):
    def test_only_supplied_images_and_unique_ids(self):
        self.assertEqual(len(TEMPLATES),35);self.assertEqual(len({t['id'] for t in TEMPLATES}),35)
        self.assertEqual(len({t['reference_file'] for t in TEMPLATES}),35)
        self.assertEqual(sum(t['id'].startswith('user-old') for t in TEMPLATES),15)
        self.assertTrue(all(t['text_layers'] for t in TEMPLATES))
    def test_every_new_layout_renders_both_directions_with_text(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'photo.jpg';Image.new('RGB',(300,450),'#7b8a71').save(p)
            for t in TEMPLATES:
                for wide in (False,True):
                    a=oriented_template(t,wide)
                    for x,y,w,h in a['slots']:
                        self.assertGreater(w,0);self.assertGreater(h,0);self.assertGreaterEqual(x,0);self.assertGreaterEqual(y,0);self.assertLessEqual(x+w,1.00001);self.assertLessEqual(y+h,1.00001)
                    size=(480,320) if wide else (320,480)
                    c=dict(enabled=False,text_enabled=True,text_layers=a['text_layers'])
                    out=render(a,[str(p)]*len(a['slots']),*size,typography=c)
                    self.assertEqual(out.size,size)
    def test_text_works_when_artwork_disabled_and_custom_font_survives_roundtrip(self):
        data=import_font(ROOT/font_catalog()[0]['file'])
        c=dict(enabled=False,text_enabled=True,text_layers=[dict(text='Lễ Ăn Hỏi\nHạnh phúc',font_data=data,size=60,x=50,y=50,width=80,color='#ffffff',tracking=8,angle=10)])
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'project.json';save_project(p,[],{'typography':c});_,state=open_project(p)
            im=Image.new('RGB',(500,700),'black');out=apply_typography(im,state['typography'])
            self.assertIsNotNone(ImageChops.difference(im,out).getbbox())
            self.assertEqual(apply_typography(im,dict(c,text_enabled=False)).tobytes(),im.tobytes())
    def test_text_editor_edits_defaults_and_imported_fonts_without_mutating_cancelled_config(self):
        from text_editor import TextEditor
        defaults=TEMPLATES[16]['text_layers'];original=dict(enabled=False,text_enabled=True,auto_text=True,text_layers=defaults)
        dialog=TextEditor(original,defaults,lambda c:apply_typography(Image.new('RGB',(400,600),'#444444'),c))
        dialog.content.setPlainText('Tên cô dâu & Tên chú rể');dialog.controls['size'].setValue(58);dialog.font.setCurrentIndex(4)
        self.assertEqual(dialog.config['text_layers'][0]['text'],'Tên cô dâu & Tên chú rể');self.assertFalse(dialog.config['auto_text'])
        self.assertNotEqual(original['text_layers'][0]['text'],dialog.config['text_layers'][0]['text'])
        dialog.add_layer();self.assertEqual(len(dialog.config['text_layers']),len(defaults)+1)
        dialog.reset();self.assertEqual(dialog.config['text_layers'],defaults)
        dialog.reject();dialog.deleteLater();APP.processEvents()

    def test_stable_layout_id_and_legacy_project_migration(self):
        from app import Window
        from unittest.mock import patch
        window=Window()
        try:
            self.assertEqual(window.template.count(),35)
            window.template.setCurrentIndex(16)
            self.assertEqual(window.state()['template_id'],'user-new-02')
            self.assertTrue(window.ty['text_enabled'])
            window.ty['auto_text']=False;window.ty['text_layers'][0]['text']='Tên của tôi'
            window.template.setCurrentIndex(17)
            self.assertEqual(window.ty['text_layers'][0]['text'],'Tên của tôi')
            with tempfile.TemporaryDirectory() as d:
                p=Path(d)/'legacy.json';save_project(p,[],{'template':63,'paths':[],'crops':[]})
                with patch('app.QFileDialog.getOpenFileName',return_value=(str(p),'')):window.load_session()
                self.assertEqual(window.template.currentIndex(),3)
        finally:window.close();window.deleteLater();APP.processEvents()
