"""Deterministic background grading and foreground frames. Originals stay read-only."""
import random
import numpy as np
from PIL import Image,ImageOps,ImageEnhance,ImageFilter,ImageDraw,ImageChops

TONES=[('Tự nhiên','natural'),('Tự phối theo ảnh','auto'),('Ấm champagne','warm'),('Lạnh xanh','cool'),('Đen trắng','mono'),('Nâu sepia','sepia'),('Film bạc màu','faded')]

def effect_defaults():
    return dict(auto_style=True,tone='natural',tone_strength=50,saturation=100,contrast=100,grain=0,scratches=0,vignette=0,effect_seed=7,corner=0,border=0,border_color='#ffffff',shadow=0)

def effective_config(template,config):
    c=effect_defaults();c.update(config)
    if c.get('auto_style',True):
        defaults=effect_defaults();defaults.pop('effect_seed');c.update(defaults);c.update(template.get('effects',{}))
    return c

def grade_background(image,c):
    image=image.convert('RGB');tone=c.get('tone','natural');strength=max(0,min(100,c.get('tone_strength',50)))/100
    if tone=='mono':styled=ImageOps.grayscale(image).convert('RGB')
    elif tone=='sepia':styled=ImageOps.colorize(ImageOps.grayscale(image),'#251b18','#f8e7c5')
    elif tone in ('warm','cool','auto'):
        if tone=='auto':
            tiny=image.resize((1,1),Image.Resampling.BOX);rgb=tiny.getpixel((0,0));color=tuple(round(v*.7+255*.3) for v in rgb)
        else:color='#efc58e' if tone=='warm' else '#abc5e0'
        styled=Image.blend(image,Image.new('RGB',image.size,color),.28)
    elif tone=='faded':styled=ImageEnhance.Contrast(Image.blend(image,Image.new('RGB',image.size,'#b9a88e'),.16)).enhance(.78)
    else:styled=image
    image=Image.blend(image,styled,strength)
    image=ImageEnhance.Color(image).enhance(max(0,min(200,c.get('saturation',100)))/100)
    image=ImageEnhance.Contrast(image).enhance(max(20,min(180,c.get('contrast',100)))/100)
    grain=max(0,min(100,c.get('grain',0)))
    if grain:
        # Bounded intermediate memory even for large exports.
        w,h=image.size;scale=min(1,1024/max(w,h));size=(max(1,round(w*scale)),max(1,round(h*scale)))
        rng=np.random.default_rng(int(c.get('effect_seed',7)))
        noise=np.clip(rng.normal(128,grain*.15,(size[1],size[0])),0,255).astype('uint8')
        texture=Image.fromarray(noise).resize((w,h),Image.Resampling.BILINEAR).convert('RGB')
        image=ImageChops.add(image,texture,scale=1,offset=-128)
    scratches=max(0,min(100,c.get('scratches',0)))
    if scratches:
        rng=random.Random(int(c.get('effect_seed',7)));w,h=image.size
        # Work on a normalized film plate: same scratch pattern for preview/export.
        sw=720;sh=max(1,round(sw*h/w));film=Image.new('RGBA',(sw,sh));d=ImageDraw.Draw(film)
        for _ in range(round(scratches*.65)):
            x=rng.uniform(0,sw);y=rng.uniform(0,sh);length=rng.uniform(.015,.55)*sh
            d.line([(x,y),(x+rng.uniform(-2,2),min(sh,y+length))],fill=(245,237,221,rng.randint(25,95)),width=1)
        for _ in range(round(scratches*2)):
            x=rng.randrange(sw);y=rng.randrange(sh);rr=rng.choice([.5,.7,1.2]);d.ellipse((x-rr,y-rr,x+rr,y+rr),fill=(250,245,230,rng.randint(20,95)))
        image=Image.alpha_composite(image.convert('RGBA'),film.resize((w,h),Image.Resampling.BICUBIC)).convert('RGB')
    vignette=max(0,min(100,c.get('vignette',0)))/100
    if vignette:
        w,h=image.size;yy,xx=np.mgrid[-1:1:complex(512),-1:1:complex(512)]
        a=np.clip((xx*xx+yy*yy-.15)/1.85,0,1)*vignette*.8
        mask=Image.fromarray((a*255).astype('uint8')).resize((w,h),Image.Resampling.BILINEAR)
        image=Image.composite(Image.new('RGB',(w,h),'black'),image,mask)
    return image

def rounded_mask(size,radius):
    scale=2 if max(size)<=1600 else 1
    m=Image.new('L',(size[0]*scale,size[1]*scale));ImageDraw.Draw(m).rounded_rectangle((0,0,m.width-1,m.height-1),radius=max(0,radius)*scale,fill=255)
    return m.resize(size,Image.Resampling.LANCZOS) if scale>1 else m

def paste_framed(canvas,image,position,c):
    size=image.size;short=min(size);radius=short*max(0,min(50,c.get('corner',0)))/100
    border=min(short//3,round(short*max(0,min(12,c.get('border',0)))/100))
    mask=rounded_mask(size,radius)
    shadow=max(0,min(100,c.get('shadow',0)))
    if shadow:
        pad=max(3,round(short*.055));s=Image.new('L',(size[0]+pad*2,size[1]+pad*2));s.paste(mask,(pad,pad));s=s.filter(ImageFilter.GaussianBlur(pad*.65));s=s.point(lambda a:round(a*shadow/200))
        canvas.paste('black',(position[0]-pad,position[1]-pad+round(pad*.6)),s)
    if border:
        framed=Image.new('RGB',size,c.get('border_color','#ffffff'))
        inner=(size[0]-border*2,size[1]-border*2)
        image=ImageOps.fit(image,inner,method=Image.Resampling.LANCZOS)
        framed.paste(image,(border,border),rounded_mask(inner,max(0,radius-border)))
    else:framed=image
    canvas.paste(framed,position,mask)
