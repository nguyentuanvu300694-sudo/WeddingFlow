"""Image analysis and rendering; originals are always read-only."""
from __future__ import annotations
import hashlib, json, math
from dataclasses import dataclass, field, asdict
from pathlib import Path
from functools import lru_cache
import numpy as np
from PIL import Image, ImageOps, ImageFilter,ImageEnhance,ImageDraw
from photo_effects import effect_defaults,effective_config,grade_background,paste_framed

LABELS = ['Decor / setup','Cô dâu riêng','Chú rể riêng','Cặp đôi','Gia đình / khách','Nghi lễ','Áo dài','Váy cưới','Khác']
EXTS = {'.jpg','.jpeg','.png','.tif','.tiff','.webp'}
@dataclass
class Photo:
    path: str
    width: int
    height: int
    sha: str
    phash: str
    quality: float
    labels: list[str] = field(default_factory=list)
    group: int = -1
    keep: bool = True
    embedding: list[float] = field(default_factory=list)
    remote_id: str = ""
    remote_name: str = ""
    remote_version: str = ""
    remote_key: str = ""
    remote_md5: str = ""
    remote_size: int = 0
    remote_mode: str = "oauth"

def load_image(path, max_side=None):
    with Image.open(path) as src:
        # Respect camera EXIF orientation before crop, hash or display.
        im = ImageOps.exif_transpose(src).convert('RGB')
    if max_side:
        im.thumbnail((max_side,max_side), Image.Resampling.LANCZOS)
    return im

@lru_cache(maxsize=1)
def dct_matrix():
    x=np.arange(32); k=np.arange(32)[:,None]
    m=np.cos(np.pi*(2*x+1)*k/64); m[0]*=1/math.sqrt(2)
    return m*math.sqrt(2/32)

def fingerprint(im):
    a=np.asarray(im.convert('L').resize((32,32),Image.Resampling.LANCZOS),dtype=float)
    d=(dct_matrix()@a@dct_matrix().T)[:8,:8].flatten()[1:]
    bits=d>np.median(d)
    return f'{sum(int(b)<<i for i,b in enumerate(bits)):016x}'

def inspect_photo(path):
    p=Path(path).resolve()
    digest=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''): digest.update(chunk)
    im=load_image(p); w,h=im.size
    thumb=im.copy();thumb.thumbnail((512,512))
    a=np.asarray(thumb.convert('L'),dtype=float)
    lap=-4*a[1:-1,1:-1]+a[:-2,1:-1]+a[2:,1:-1]+a[1:-1,:-2]+a[1:-1,2:]
    # Heuristic ranking only: edge detail and clipped highlights/shadows.
    sharp=math.log1p(float(lap.var())) if lap.size else 0
    clipped=float(((a<5)|(a>250)).mean())
    quality=sharp-2*clipped+0.05*math.log1p(w*h)
    return Photo(str(p),w,h,digest.hexdigest(),fingerprint(im),quality)

def scan(folder, progress=lambda s:None):
    files=[]
    for p in Path(folder).rglob('*'):
        getattr(getattr(progress,'__self__',None),'checkpoint',lambda:None)()
        if p.is_file() and p.suffix.lower() in EXTS:files.append(p)
    files.sort()
    photos=[]; errors=[]
    for i,p in enumerate(files):
        progress(f'Đọc ảnh {i+1}/{len(files)} · {p.name}')
        try: photos.append(inspect_photo(p))
        except Exception as e: errors.append(f'{p.name}: {e}')
    return photos,errors

def distance(a,b):return (int(a,16)^int(b,16)).bit_count()

def group_duplicates(photos, threshold=7):
    """Representative grouping avoids A~B~C chaining across unrelated poses.
    'keep' is a proposal, never a file deletion. Re-running resets proposals.
    """
    groups=[]
    for p in sorted(photos,key=lambda p:p.quality,reverse=True):
        p.keep=True;p.group=-1
        found=None
        for g in groups:
            rep=g[0]
            near=distance(p.phash,rep.phash)<=threshold
            if threshold >= 0 and p.embedding and rep.embedding:
                # Semantic similarity alone must never collapse a whole wedding.
                near=near or (distance(p.phash,rep.phash)<=16 and np.dot(p.embedding,rep.embedding)>.985)
            if p.sha==rep.sha or near:found=g;break
        if found is None:groups.append([p])
        else:found.append(p)
    for i,g in enumerate(g for g in groups if len(g)>1):
        for j,p in enumerate(g):p.group=i;p.keep=(j==0)
    return photos

PROMPT_GROUPS = [
 [('Decor / setup','wedding venue decorations, flower arrangements, empty ceremony backdrop and table details, no people'),
  ('Cô dâu riêng','a solo portrait of one bride, no other people'),
  ('Chú rể riêng','a solo portrait of one groom, no other people'),
  ('Cặp đôi','a portrait of the bride and groom together, two people'),
  ('Gia đình / khách','a wedding group photo of family members or guests'),
  ('Nghi lễ','people performing a traditional wedding ceremony, exchanging gifts, rings or tea')],
 [('Áo dài','Vietnamese wedding bride or groom wearing traditional ao dai tunic'),
  ('Váy cưới','a bride wearing a white western wedding dress'),
  ('','people in everyday clothes or a closeup of decorations without bridal clothing')]
]
class Classifier:
    def __init__(self,progress):
        progress('Nạp AI · lần đầu tải mô hình, có thể mất vài phút…')
        from ai_check import load_ai_libraries
        torch,_=load_ai_libraries()
        import open_clip
        self.torch=torch
        self.device='mps' if torch.backends.mps.is_available() else 'cpu'
        try:
            self.model,_,self.preprocess=open_clip.create_model_and_transforms('ViT-B-32',pretrained='laion2b_s34b_b79k',device=self.device)
        except Exception:
            self.device='cpu'
            self.model,_,self.preprocess=open_clip.create_model_and_transforms('ViT-B-32',pretrained='laion2b_s34b_b79k',device='cpu')
        self.model.eval();tokenizer=open_clip.get_tokenizer('ViT-B-32')
        self.texts=[]
        with torch.inference_mode():
            for group in PROMPT_GROUPS:
                t=self.model.encode_text(tokenizer(['a photograph of '+p for _,p in group]).to(self.device))
                self.texts.append(t/t.norm(dim=-1,keepdim=True))
    def apply(self,photos,progress):
        t=self.torch
        with t.inference_mode():
            for i,p in enumerate(photos):
                progress(f'AI phân loại {i+1}/{len(photos)} · {(p.remote_name or Path(p.path).name)}')
                x=self.preprocess(load_image(p.path,1600)).unsqueeze(0).to(self.device)
                e=self.model.encode_image(x);e=e/e.norm(dim=-1,keepdim=True)
                p.embedding=e[0].cpu().float().tolist();labels=[]
                for group,text in zip(PROMPT_GROUPS,self.texts):
                    scores=(e@text.T)[0];j=int(scores.argmax().item());name=group[j][0]
                    if name:labels.append(name)
                p.labels=labels or ['Khác']
        return photos

def grid(cols,rows,margin=.05,gap=.012):
    w=(1-2*margin-(cols-1)*gap)/cols;h=(1-2*margin-(rows-1)*gap)/rows
    return [[margin+x*(w+gap),margin+y*(h+gap),w,h] for y in range(rows) for x in range(cols)]

def templates():
    # Normalized coordinates, inspired by supplied samples; reference text is not copied.
    overlap=[[.50,.06,.33,.28],[.11,.35,.44,.33],[.54,.60,.34,.29],[.05,.70,.29,.23]]
    hero=[[.03,.02,.76,.75],[.64,.39,.30,.27],[.08,.73,.25,.22],[.36,.73,.25,.22],[.64,.73,.25,.22]]
    strip=[[.08,.05,.84,.26],[.08,.35,.84,.26],[.08,.65,.84,.26]]
    defs=[
    ('01 · Chân dung nền hoa',[[.22,.08,.58,.66]],'blur',[]),
    ('02 · Lưới 6 trên nền decor',grid(3,2,.07,.008),'blur',[]),
    ('03 · Diptych đen trắng',[[0,0,.50,1],[.57,.15,.36,.72]],'white',[0]),
    ('04 · Ảnh nổi trên nền hoa',overlap,'blur',[]),
    ('05 · Ảnh chủ đạo + 4 ảnh nhỏ',hero,'blur',[]),
    ('06 · Nhật ký ngày cưới',[[.22,.04,.61,.29],[.64,.36,.30,.33],[.08,.50,.30,.34],[.36,.73,.30,.22]],'blur',[]),
    ('07 · Lưới 9 ảnh',grid(3,3,.025,.007),'white',[]),
    ('08 · Áo dài xếp lớp',[[.03,.03,.56,.60],[.61,.03,.36,.30],[.55,.39,.34,.38],[.08,.67,.48,.28],[.65,.81,.29,.16]],'blur',[]),
    ('09 · Ba khoảnh khắc',[[.27,.08,.59,.31],[.57,.42,.36,.24],[.07,.72,.70,.23]],'blur',[]),
    ('10 · Chân dung mono + màu',[[0,0,1,1],[.54,.34,.41,.40],[.43,.72,.47,.22]],'white',[0]),
    ('11 · Lưới 6 lệch tâm',[[.07,.19,.28,.27],[.36,.19,.28,.27],[.65,.19,.28,.27],[.07,.47,.28,.27],[.36,.47,.28,.27],[.65,.47,.28,.27]],'blur',[]),
    ('12 · Chín góc cô dâu',grid(3,3,.02,.008),'white',[]),
    ('13 · Một ngang + hai dọc',[[.08,.05,.84,.32],[.08,.39,.41,.45],[.51,.39,.41,.45]],'white',[2]),
    ('14 · Hai ảnh trên nền mềm',[[.40,.16,.49,.46],[.08,.52,.46,.43]],'blur',[]),
    ('15 · Mono toàn khung',[[0,0,1,1],[.09,.55,.35,.36]],'white',[0]),
    ('16 · Ba ảnh ngang',strip,'cream',[]),
    ('17 · Sáu ảnh giữa nền decor',[[.09,.31,.27,.23],[.37,.31,.27,.23],[.65,.31,.27,.23],[.09,.55,.27,.23],[.37,.55,.27,.23],[.65,.55,.27,.23]],'blur',[1]),
    ('18 · Ảnh lớn + chi tiết',[[.31,.27,.39,.37],[.08,.34,.22,.20],[.30,.66,.23,.20],[.55,.65,.34,.22]],'blur',[]),
    ('19 · Collage bất đối xứng',[[.63,.03,.33,.29],[.28,.30,.39,.44],[.68,.43,.28,.29],[.06,.73,.29,.23],[.36,.77,.29,.19]],'blur',[1]),
    ('20 · Bốn ảnh decor',grid(2,2,.035,.012),'white',[])]
    return [dict(name=n,slots=s,background=b,mono=m) for n,s,b,m in defs]
from more_templates import additions
from editorial_layouts import supplied_templates
TEMPLATES=supplied_templates()

def pick_photos(photos,n,label=None,seed=0):
    pool=[p for p in photos if p.keep and (not label or label in p.labels)]
    if len(pool)<n:raise ValueError(f'Cần {n} ảnh được giữ lại trong nhóm này, hiện có {len(pool)}. Hãy đổi mẫu, đổi nhóm hoặc giữ thêm ảnh.')
    pool.sort(key=lambda p:(-p.quality,p.path))
    # Rotate to offer alternatives while retaining deterministic projects.
    offset=seed%len(pool);pool=pool[offset:]+pool[:offset]
    chosen=[];seen=set()
    for p in pool:
        key=('group',p.group) if p.group>=0 else ('photo',p.path)
        if key not in seen:chosen.append(p);seen.add(key)
        if len(chosen)==n:return chosen
    raise ValueError('Chưa đủ nhóm ảnh khác nhau. Hãy chọn thêm ảnh hoặc giảm độ nhạy gom ảnh giống.')

@lru_cache(maxsize=16)
def preview_source(path, mtime):
    return load_image(path,1600)

def oriented_template(template,landscape=False):
    """Transpose every geometry layer when changing the native canvas direction."""
    if landscape==(template.get('native_orientation','portrait')=='landscape'):return template
    def transpose(rect):
        x,y,w,h=rect;return [y,x,h,w]
    result=dict(template,slots=[transpose(slot) for slot in template['slots']])
    result['mats']=[(transpose(rect),color,opacity) for rect,color,opacity in template.get('mats',[])]
    result['background_panels']=[(transpose(rect),index,tone) for rect,index,tone in template.get('background_panels',[])]
    result['text_layers']=[dict(layer,x=layer.get('y',50),y=layer.get('x',50)) for layer in template.get('text_layers',[])]
    return result

def default_background():
    return dict(effect_defaults(),mode='template',blur=20,brightness=100,wash=10,margin=5,x=50,y=50,color='#faf8f4')

def background_uses_image(template,config=None):
    c=config or {};mode=c.get('mode','template')
    return mode=='custom' or (mode=='template' and template['background']=='blur')

def normalize_crop(crop=None):
    values=list(crop or [.5,.5])
    def safe(i,default,low,high):
        try:v=float(values[i])
        except (IndexError,ValueError,TypeError):return default
        return max(low,min(high,v)) if math.isfinite(v) else default
    return [safe(0,.5,0,1),safe(1,.5,0,1),safe(2,1,1,4)]

def crop_geometry(source_size,target_size,crop=None):
    x,y,zoom=normalize_crop(crop);sw,sh=source_size;tw,th=target_size
    scale=max(tw/sw,th/sh)*zoom;vw,vh=min(sw,tw/scale),min(sh,th/scale)
    left=(sw-vw)*x;top=(sh-vh)*y
    return (max(0,left),max(0,top),min(sw,left+vw),min(sh,top+vh))

def crop_to_slot(image,size,crop=None):
    return image.resize(size,Image.Resampling.LANCZOS,box=crop_geometry(image.size,size,crop))

def render(template,paths,width=1080,height=1620,background_path=None,crops=None,typography=None,background_config=None):
    if len(paths)!=len(template['slots']):raise ValueError('Số ảnh không khớp số ô của mẫu.')
    c=default_background();c.update(background_config or {});c=effective_config(template,c);custom=c['mode']=='custom';styled=custom or bool(template.get('effects'))
    canvas=Image.new('RGB',(width,height),c['color'] if c['mode']=='solid' else ('#faf8f4' if template['background']=='cream' else 'white'))
    if background_uses_image(template,c):
        if custom and not background_path:raise ValueError('Hãy chọn ảnh nền từ máy hoặc ảnh đang duyệt trước.')
        bgpath=background_path or paths[0]
        bg=preview_source(bgpath,Path(bgpath).stat().st_mtime_ns) if max(width,height)<=1600 else load_image(bgpath,max(width,height))
        center=(max(0,min(100,c['x']))/100,max(0,min(100,c['y']))/100)
        canvas=ImageOps.fit(bg,(width,height),method=Image.Resampling.LANCZOS,centering=center)
        radius=max(width,height)*(max(0,min(80,c['blur']))/2000 if styled else .009)
        canvas=canvas.filter(ImageFilter.GaussianBlur(radius))
        if styled:
            canvas=ImageEnhance.Brightness(canvas).enhance(max(.2,min(1.8,c['brightness']/100)))
            canvas=Image.blend(canvas,Image.new('RGB',canvas.size,'white'),max(0,min(80,c['wash']))/100)
        else:canvas=Image.blend(canvas,Image.new('RGB',canvas.size,'#f1eee7'),.22)
    if c['mode']=='template':
        for rect,index,tone in template.get('background_panels',[]):
            x,y,w,h=rect;pw,ph=max(1,round(w*width)),max(1,round(h*height));path=paths[index]
            source=preview_source(path,Path(path).stat().st_mtime_ns) if max(width,height)<=1600 else load_image(path)
            panel=ImageOps.fit(source,(pw,ph),method=Image.Resampling.LANCZOS)
            if tone=='mono':panel=ImageOps.grayscale(panel).convert('RGB')
            panel=panel.filter(ImageFilter.GaussianBlur(max(width,height)*c['blur']/2000))
            canvas.paste(panel,(round(x*width),round(y*height)))
    canvas=grade_background(canvas,c)
    crops=crops or [[.5,.5] for _ in paths]
    margin=max(0,min(.18,c['margin']/100)) if custom else 0
    background_slots=set(template.get('background_slots',[]))
    def draw_slot(i):
        path=paths[i];x,y,w,h=template['slots'][i];isbg=i in background_slots;m=0 if isbg else margin
        x=m+(1-2*m)*x;y=m+(1-2*m)*y;w*=1-2*m;h*=1-2*m
        box=(max(1,round(w*width)),max(1,round(h*height)))
        im=preview_source(path,Path(path).stat().st_mtime_ns) if max(width,height)<=1600 else load_image(path)
        im=crop_to_slot(im,box,crops[i])
        if i in template['mono']:im=ImageOps.grayscale(im).convert('RGB')
        if isbg:
            im=im.filter(ImageFilter.GaussianBlur(max(width,height)*c['blur']/2000))
            im=ImageEnhance.Brightness(im).enhance(max(.2,min(1.8,c['brightness']/100)))
            im=Image.blend(im,Image.new('RGB',im.size,'white'),max(0,min(80,c['wash']))/100)
            canvas.paste(grade_background(im,c),(round(x*width),round(y*height)))
        else:paste_framed(canvas,im,(round(x*width),round(y*height)),c)
    for i in range(len(paths)):
        if i in background_slots:draw_slot(i)
    for rect,color,opacity in template.get('mats',[]):
        x,y,w,h=rect;size=(max(1,round(w*width)),max(1,round(h*height)))
        canvas.paste(Image.new('RGB',size,color),(round(x*width),round(y*height)),Image.new('L',size,round(opacity*2.55)))
    for i in range(len(paths)):
        if i not in background_slots:draw_slot(i)
    if template.get('outer_frame'):
        d=ImageDraw.Draw(canvas);inset=round(min(width,height)*.01)
        d.rounded_rectangle((inset,inset,width-inset-1,height-inset-1),radius=round(min(width,height)*.025),outline='#b7aaa1',width=max(1,round(min(width,height)/1400)))
    from typography import apply_typography
    return apply_typography(canvas,typography)

def save_project(path,photos,state):
    out=Path(path);tmp=out.with_suffix(out.suffix+'.tmp')
    tmp.write_text(json.dumps({'version':1,'photos':[asdict(p) for p in photos],'state':state},ensure_ascii=False),encoding='utf-8');tmp.replace(out)

def open_project(path):
    data=json.loads(Path(path).read_text(encoding='utf-8'))
    if data.get('version')!=1:raise ValueError('Phiên bản dự án không được hỗ trợ.')
    return [Photo(**p) for p in data['photos']], data.get('state',{})
