"""Offline check run against the built executable, without opening user files."""
def run(window_class):
 import sys,tempfile,traceback
 from pathlib import Path
 from PIL import Image
 from PySide6.QtWidgets import QApplication
 from love_art import ARTWORKS,make_stamp,default_artwork
 from typography import font_catalog,get_font
 from core import render,default_background,inspect_photo,TEMPLATES,oriented_template
 try:
  import sys
  if getattr(sys,'frozen',False):
   from ai_check import check_ai
   check_ai()
  app=QApplication.instance() or QApplication(sys.argv);window=window_class()
  assert len(ARTWORKS)==80
  for i in [0,31,32,55,79]:assert make_stamp(i).getbbox()
  for record in font_catalog():assert get_font(record['name'],30).getbbox('Wedding')
  with tempfile.TemporaryDirectory() as folder:
   path=Path(folder)/'photo test.jpg';Image.new('RGB',(200,300),'red').save(path)
   window.photos=[inspect_photo(path)];window.template.setCurrentIndex(1);window.refresh_list();window.generate_layout()
   t=dict(slots=[[.1,.1,.8,.65]],background='white',mono=[])
   result=render(t,[str(path)],400,600,str(path),typography=dict(default_artwork(),preset=79),background_config=dict(default_background(),mode='custom'))
   assert result.size==(400,600)
   assert len(TEMPLATES)==35
   sample=oriented_template(TEMPLATES[13],False)
   framed=render(sample,[str(path)]*len(sample['slots']),400,600,typography=None,background_config=dict(default_background(),auto_style=False,grain=25,scratches=30,corner=12,border=2,shadow=30))
   assert framed.size==(400,600)
   from typography import apply_typography
   labelled=apply_typography(framed,dict(enabled=False,text_enabled=True,text_layers=TEMPLATES[16]['text_layers']))
   assert labelled.size==(400,600)
  window.close();return 0
 except Exception:
  # A visible, local diagnostic for an EXE built with console=False.
  from drive_source import app_dir
  dest=app_dir()
  (dest/'build_selftest_error.txt').write_text(traceback.format_exc(),encoding='utf-8');return 1
