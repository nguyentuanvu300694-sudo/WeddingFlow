WeddingFlow 0.6.4 Windows x64
Có tạm dừng/tiếp tục import, typography PNG, hướng ảnh, nền mờ và 80 mẫu chữ.
Sửa đóng gói AI: cặp torch/torchvision CPU tương thích, thu thập native extension.
Kiểm tra AI offline trước và sau build, không tải trọng số khi kiểm tra.

BUILD TRÊN GITHUB (không cần máy Windows)
1. Upload nguyên WeddingFlow_0.6.4_Windows.zip vào thư mục gốc repo, không giải nén.
2. Sửa .github/workflows/build-windows.yml hiện có, thay toàn bộ bằng nội dung GITHUB_BUILD_WINDOWS.yml trong gói này.
3. Commit vào main. Mở Actions; đợi lượt chạy mới có dấu xanh.
4. Mở lượt chạy, tải artifact WeddingFlow-0.6.4-Windows, giải nén để lấy WeddingFlow.exe.
Chạy EXE trên Windows x64. AI tải trọng số lần đầu khi phân loại.

BUILD TRÊN WINDOWS: chạy Build_Release_Windows.bat (Python 3.11/3.12 x64).
