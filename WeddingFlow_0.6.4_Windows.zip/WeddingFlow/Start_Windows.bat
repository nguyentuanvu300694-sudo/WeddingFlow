@echo off
call "%~dp0Windows_Launcher.bat" run
set "WEDDING_STATUS=%ERRORLEVEL%"
if not "%WEDDING_STATUS%"=="0" pause
exit /b %WEDDING_STATUS%
