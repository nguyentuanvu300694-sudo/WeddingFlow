import sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PIL import Image
from core import *

class CoreTests(unittest.TestCase):
    def test_identical_and_exact_only(self):
        a=Photo('a',100,100,'same','0000000000000000',2,embedding=[1,0])
        b=Photo('b',100,100,'same','0000000000000000',1,embedding=[1,0])
        c=Photo('c',100,100,'different','0000000000000001',0,embedding=[1,0])
        group_duplicates([a,b,c],-1)
        self.assertTrue(a.keep);self.assertFalse(b.keep);self.assertTrue(c.keep)
    def test_no_transitive_chain(self):
        ps=[Photo(str(i),100,100,str(i),h,3-i) for i,h in enumerate(['0000000000000000','0000000000000003','000000000000000f'])]
        group_duplicates(ps,2)
        self.assertFalse(ps[1].keep);self.assertTrue(ps[2].keep)
    def test_presets_render_and_project(self):
        with tempfile.TemporaryDirectory() as d:
            a=Path(d)/'a.jpg';Image.new('RGB',(200,300),'red').save(a)
            p=inspect_photo(a)
            self.assertEqual((p.width,p.height),(200,300))
            for t in TEMPLATES:
                self.assertTrue(all(x>=0 and y>=0 and w>0 and h>0 and x+w<=1.001 and y+h<=1.001 for x,y,w,h in t['slots']))
                out=render(t,[str(a)]*len(t['slots']),200,300)
                self.assertEqual(out.size,(200,300))
            project=Path(d)/'test.json';save_project(project,[p],{'template':0})
            ps,s=open_project(project);self.assertEqual(ps[0].sha,p.sha);self.assertEqual(s['template'],0)
    def test_no_same_group_in_auto_layout(self):
        ps=[Photo(str(i),100,100,str(i),'0',i,group=0 if i<2 else -1) for i in range(4)]
        chosen=pick_photos(ps,3)
        self.assertEqual(len([p for p in chosen if p.group==0]),1)
        with self.assertRaises(ValueError):pick_photos(ps,4)
    def test_exif_orientation(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'rotate.jpg';im=Image.new('RGB',(100,200),'blue');exif=im.getexif();exif[274]=6;im.save(p,exif=exif)
            self.assertEqual(load_image(p).size,(200,100))
    def test_scan_reports_bad_files(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'bad.jpg';p.write_text('not an image')
            photos,errors=scan(d);self.assertFalse(photos);self.assertEqual(len(errors),1)
if __name__=='__main__':unittest.main()

class TypographyTests(unittest.TestCase):
    def test_all_styles_and_fonts(self):
        from typography import apply_typography,default_typography,STYLES,font_catalog
        base=Image.new('RGB',(400,600),'#c3c3b0')
        config=default_typography();config.update(names='Nguyễn Hồng & Trần Đức',title='LỄ THÀNH HÔN',date='30 · 10 · 2026')
        for i in range(len(STYLES)):
            config['style']=i;out=apply_typography(base,config)
            self.assertEqual(out.size,base.size);self.assertNotEqual(out.tobytes(),base.tobytes())
        for record in font_catalog():
            config['font']=record['name'];self.assertEqual(apply_typography(base,config).mode,'RGB')
        config['enabled']=False;self.assertEqual(apply_typography(base,config).tobytes(),base.tobytes())
    def test_sixty_distinct_presets(self):
        self.assertEqual(len(TEMPLATES),60)
        self.assertEqual(len({t['name'] for t in TEMPLATES}),60)
    def test_long_text_and_extreme_position(self):
        from typography import apply_typography,default_typography
        config=default_typography();config.update(names='Nguyễn Thị Minh Hương & Trần Hoàng Đức Anh',quote='Mình cùng nhau viết tiếp những ngày bình yên. '*5,y=800,size=180)
        out=apply_typography(Image.new('RGB',(400,600),'white'),config)
        self.assertEqual(out.size,(400,600))
