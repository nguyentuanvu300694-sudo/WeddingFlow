@echo off
setlocal
chcp 65001 >nul
pushd "%~dp0"
set "WEDDING_PY="
for %%V in (3.11 3.12) do (
  py -%%V -c "import sys; assert sys.maxsize > 2**32" >nul 2>&1
  if not errorlevel 1 (
    set "WEDDING_PY=py -%%V"
    goto found_python
  )
)
python -c "import sys; assert sys.version_info[:2] in [(3,11),(3,12)] and sys.maxsize > 2**32" >nul 2>&1
if not errorlevel 1 set "WEDDING_PY=python"
if not defined WEDDING_PY (
  echo Install Python 3.11 or 3.12 Windows 64-bit from https://www.python.org/downloads/windows/
  echo Include the Python launcher during installation, then run this file again.
  popd
  exit /b 1
)
:found_python
%WEDDING_PY% "%~dp0windows_tools.py" %1
set "WEDDING_EXIT=%ERRORLEVEL%"
popd
exit /b %WEDDING_EXIT%
