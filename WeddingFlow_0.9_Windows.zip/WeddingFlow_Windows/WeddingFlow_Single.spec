# Run on Windows: python -m PyInstaller --clean --noconfirm WeddingFlow.spec
from pathlib import Path
import sys
from PyInstaller.utils.hooks import collect_all,collect_submodules,collect_data_files,copy_metadata,get_package_paths
if sys.platform!='win32':raise RuntimeError('Build the Windows executable on Windows.')
root=Path(SPECPATH)
datas=[(str(root/'fonts'),'fonts'),(str(root/'artwork'),'artwork')]
for name in ['README_VI.txt','GOOGLE_DRIVE_SETUP_VI.txt','WINDOWS_VI.txt','app_icon.ico']:
 datas.append((str(root/name),'.'))
oc_data,oc_bins,oc_hidden=collect_all('open_clip')
datas+=oc_data+collect_data_files('timm')
_,tv_dir=get_package_paths('torchvision')
tv_extensions=[p for p in Path(tv_dir).iterdir() if p.is_file() and p.suffix.lower() in ('.pyd','.dll')]
if not any(p.name.startswith('_C') for p in tv_extensions):raise RuntimeError('Missing torchvision native extension')
oc_bins += [(str(p),'torchvision') for p in tv_extensions]
for distribution in ['open_clip_torch','timm','torch','torchvision','keyring','gdown']:
 datas+=copy_metadata(distribution)
hidden=oc_hidden+collect_submodules('timm.models')+['torchvision._C','torchvision.ops','torchvision.io.image','ai_check','keyring.backends.Windows','packaged_smoke','extra_art','public_drive','drive_source','more_templates','photo_effects','reference_layouts','crop_editor','editorial_layouts','editable_text','text_editor','calendar_typo','identity','latest_layouts','cv2','torchvision.models.detection']
a=Analysis([str(root/'app.py')],pathex=[str(root)],binaries=oc_bins,datas=datas,hiddenimports=hidden,hookspath=[],runtime_hooks=[str(root/'runtime_windows.py')],excludes=['PyQt5','PyQt6','PySide2','tkinter','matplotlib','IPython','jupyter','pytest','torchaudio','tensorflow'],noarchive=False)
pyz=PYZ(a.pure)
exe=EXE(pyz,a.scripts,a.binaries,a.datas,[],name='WeddingFlow',icon=str(root/'app_icon.ico'),debug=False,bootloader_ignore_signals=False,strip=False,upx=False,console=False)
