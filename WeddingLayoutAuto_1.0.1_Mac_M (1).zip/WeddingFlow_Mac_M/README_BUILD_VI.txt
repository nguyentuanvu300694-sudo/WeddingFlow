WEDDING LAYOUT AUTO - by NTV MEDIA from TNDP with love
VERSION 1.0.1 — PLATFORM: Mac_M

Gói mã nguồn, chưa phải ứng dụng DMG/EXE đã build.
Tất cả bản dùng cùng giao diện 1.0.1: công cụ hai cột, kéo chữ trực tiếp
trên preview, bảng màu đầy đủ, mở ảnh nút đỏ và Drive nút xanh.
Giữ nhập ảnh dạng lưới, chọn nhiều ảnh, kéo thả ảnh/thư mục và 50 layout không chữ mẫu.

BUILD:
bash Build_Release_Mac.command → dist/*.dmg

GITHUB: upload nguyên cả ba ZIP 1.0.1 tại thư mục gốc repo.
Thay toàn bộ nội dung .github/workflows/build-windows.yml bằng GITHUB_BUILD_ALL_1.0.1.yml.
Mở Actions, chờ ba job thành công, tải DMG/EXE trong Artifacts.
Không chỉ tải một EXE trong thư mục onedir; dùng bản release standalone.

Kéo chữ: bấm vào chữ ngay preview rồi kéo. Nếu các lớp chồng nhau,
chọn lớp bằng danh sách trước. Khung chọn không xuất vào ảnh.
Màu: chọn lớp rồi mở bảng màu RGB/HEX. PNG được giữ màu gốc cho tới khi chọn tô màu.
