from pathlib import Path
import os,sys,platform
from PyInstaller.utils.hooks import collect_all,collect_submodules,collect_data_files,copy_metadata,get_package_paths
if sys.platform!='darwin' or platform.machine()!='arm64':raise RuntimeError('Build the Mac application on macOS.')
root=Path(SPECPATH)
datas=[(str(root/'fonts'),'fonts'),(str(root/'artwork'),'artwork')]
for name in ['README_VI.txt','GOOGLE_DRIVE_SETUP_VI.txt','RELEASE_BUILD_VI.txt','app_icon.ico']:
 datas.append((str(root/name),'.'))
oc_data,oc_bins,oc_hidden=collect_all('open_clip');datas+=oc_data+collect_data_files('timm')
# Native torchvision ops are loaded by filename, not by Python import.
# Include the extensions explicitly, in addition to the upstream hooks.
_,tv_dir=get_package_paths('torchvision')
tv_extensions=[p for p in Path(tv_dir).iterdir() if p.is_file() and p.suffix in ('.so','.dylib')]
if not any(p.name.startswith('_C') for p in tv_extensions):raise RuntimeError('torchvision native extension missing before packaging')
oc_bins += [(str(p),'torchvision') for p in tv_extensions]
for distribution in ['open_clip_torch','timm','torch','torchvision','keyring','gdown']:datas+=copy_metadata(distribution)
hidden=oc_hidden+collect_submodules('timm.models')+['torchvision._C','torchvision.ops','torchvision.io.image','ai_check','keyring.backends.macOS','packaged_smoke','extra_art','public_drive','drive_source','more_templates','photo_effects','reference_layouts','crop_editor','editorial_layouts','editable_text','text_editor','overlay_tools','calendar_typo','identity','latest_layouts','cv2','torchvision.models.detection']
a=Analysis([str(root/'app.py')],pathex=[str(root)],binaries=oc_bins,datas=datas,hiddenimports=hidden,hookspath=[],runtime_hooks=[str(root/'runtime_mac.py')],excludes=['PyQt5','PyQt6','PySide2','tkinter','matplotlib','IPython','jupyter','pytest','torchaudio','tensorflow'],noarchive=False)
pyz=PYZ(a.pure)
exe=EXE(pyz,a.scripts,[],exclude_binaries=True,name='WEDDING LAYOUT AUTO',debug=False,bootloader_ignore_signals=False,strip=False,upx=False,console=False,target_arch=platform.machine(),codesign_identity=os.environ.get('WEDDING_CODESIGN_IDENTITY'))
collect=COLLECT(exe,a.binaries,a.datas,strip=False,upx=False,name='WEDDING LAYOUT AUTO')
app=BUNDLE(collect,name='WEDDING LAYOUT AUTO - by NTV MEDIA from TNDP with love.app',icon=str(root/'app_icon.icns'),bundle_identifier='app.weddingflow.desktop',codesign_identity=os.environ.get('WEDDING_CODESIGN_IDENTITY'),info_plist={'CFBundleShortVersionString':'1.0.1','CFBundleVersion':'16','CFBundleDisplayName':'WEDDING LAYOUT AUTO - by NTV MEDIA from TNDP with love','CFBundleName':'WEDDING LAYOUT AUTO - by NTV MEDIA from TNDP with love','NSHighResolutionCapable':True,'LSMinimumSystemVersion':'14.0'})
